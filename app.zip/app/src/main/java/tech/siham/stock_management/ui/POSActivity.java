package tech.siham.stock_management.ui;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Html;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.ViewGroup;

import tech.siham.stock_management.Data.DBHelper;
import tech.siham.stock_management.Data.SharedPreferenceHelper;
import tech.siham.stock_management.Data.StaticConfig;
import tech.siham.stock_management.Model.Category;
import tech.siham.stock_management.Model.ListProducts;
import tech.siham.stock_management.Model.MyBasket;
import tech.siham.stock_management.Model.Order;
import tech.siham.stock_management.Model.User;
import tech.siham.stock_management.R;
import tech.siham.stock_management.view.ScannerActivity;

import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.yarolegovich.lovelydialog.LovelyProgressDialog;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Random;

import static tech.siham.stock_management.ui.orderProductsActivity.mySupplierData;

public class POSActivity extends AppCompatActivity  {

    View view;
    RecyclerView recyclerview, recyclerviewCategories, recyclerviewProducts;
    public static final List<MyBasket> scannedListProducts = new ArrayList<>();
    recyclerViewAdapter recycler;
    final static int requestCode1 = 5;
    //database reference
    private DatabaseReference mDatabase;
    private List<Category> categoriesList = new ArrayList<>();
    private ProgressDialog progressDialog;

    String mySupplierID = "";
    String currency = "$";

    TextView DetailsSubTotalPrice ;
    Button ConfirmOrder, CancelOrder ;
    TextView describeTxt;
    Order myOrder = new Order();
    Dialog dialog = null;
    DBHelper db;
    SharedPreferenceHelper sharedPreference;
    User userData = new User();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_point_of_sell);

        if(StaticConfig.UID == null){
            msg("try again something is wrong\nsupplier id is null");
            return;
        }

        /*
        # show categories list
        # show products in category
        # show status bar for total

        # show recycle review for scanned items
            > item details:
               > image, name, barcode, number of unities at one packet, describe, price, unities,
               > Edit/ Delete scanned unities
               > Fast cash / Check Out
               > print receipt
               > set history for sold items

        # show scan btn
        # show total
        */

        // getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        // getSupportActionBar().setTitle("Point Of Sell");
        // provide compatibility to all the versions
        // LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false);

        mDatabase = FirebaseDatabase.getInstance().getReference();
        sharedPreference = SharedPreferenceHelper.getInstance(this);
        userData = sharedPreference.getUserInfo();

        db = new DBHelper(this);

        progressDialog = new ProgressDialog(this);
        //displaying progress dialog while fetching images
        progressDialog.setMessage("Please wait...");
        progressDialog.show();
        // mDatabase = FirebaseDatabase.getInstance().getReference();

        DetailsSubTotalPrice = (TextView) findViewById(R.id.detailsSubTotalPrice);

        ConfirmOrder = (Button) findViewById(R.id.confirmOrder);
        CancelOrder = (Button)  findViewById(R.id.cancelOrder);

        dialog = new Dialog(this);
        View viewInflater = LayoutInflater.from(this).inflate(R.layout.confirm_order_dialog, null, false);
        Button confirmBtn = (Button) viewInflater.findViewById(R.id.confirm);
        Button cancelBtn = (Button) viewInflater.findViewById(R.id.cancel);
        describeTxt = (TextView) viewInflater.findViewById(R.id.describe);
        dialog.setContentView(viewInflater);

        ConfirmOrder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.show();
                // if user wanna add new order in same range time
                // go to old order between range time 7 days
                // edit order add products
            }
        });

        confirmBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setOrder();
            }
        });
        cancelBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });

        CancelOrder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // clear basket
                // refresh page
                // categories.clear();
                dialog.dismiss();
                db.deleteTable();
                // SetDetailsToolBar();
                // fetchDataByCategories();
            }
        });


        // end lst code
        recyclerview = (RecyclerView) findViewById(R.id.recycleView);
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(this);
        recyclerview.setLayoutManager(layoutManager);
        recyclerview.setItemAnimator(new DefaultItemAnimator());

        recyclerviewCategories = (RecyclerView) findViewById(R.id.recycleView_categories);
        recyclerviewCategories.setLayoutManager(new LinearLayoutManager(this));
        recyclerviewCategories.setItemAnimator(new DefaultItemAnimator());

        recyclerviewProducts = (RecyclerView) findViewById(R.id.recycleView_products);
        recyclerviewProducts.setLayoutManager(new GridLayoutManager(this, 3));
        recyclerviewProducts.setItemAnimator(new DefaultItemAnimator());

        //adding an event listener to fetch values
        mDatabase.child("Categories").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                //dismissing the progress dialog
                progressDialog.dismiss();
                categoriesList.clear();
                if(snapshot.exists()){
                    //iterating through all the values in database
                    for (DataSnapshot postSnapshot : snapshot.getChildren()) {
                        Category upload = postSnapshot.getValue(Category.class);
                        if(upload.adminID.equals(StaticConfig.UID)){
                            upload.itemsNumber = postSnapshot.child("Products").getChildrenCount();
                            categoriesList.add(upload);
                        }
                    }
                    //creating adapter
                    MyAdapterCategories adapterCategories = new MyAdapterCategories(getApplicationContext(), categoriesList);
                    adapterCategories.notifyDataSetChanged();
                    recyclerviewCategories.setAdapter(adapterCategories);
                }
            }
            @Override
            public void onCancelled(DatabaseError databaseError) {
                progressDialog.dismiss();
            }
        });

        try{
            recycler = new recyclerViewAdapter(POSActivity.this, scannedListProducts);
            recyclerview.setAdapter(recycler);
            recycler.notifyDataSetChanged();
        }catch (Exception e){
            msg("error  in recycle View :  "+e);
        }

        ((ImageView) findViewById(R.id.scan_item)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // open scanner to update data from db
                Intent intent = new Intent(POSActivity.this, ScannerActivity.class);
                // startActivity(intent);
                StaticConfig.intentMode = "db_check";
                startActivityForResult(intent, requestCode1);
            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == android.R.id.home) {
            onBackPressed();
            // overridePendingTransition(R.anim.slide_from_left, R.anim.slide_to_right);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }


    public void SetDetailsToolBar(){
        // get basket get total price and number of items
        int unities = 0;
        int packets = 0;
        double SubTotal = 0;
        for(MyBasket my_Basket : db.getAllBaskets()){
            unities += (my_Basket.unities * my_Basket.packets);
            packets += my_Basket.packets;
            SubTotal += my_Basket.total;
        }
        boolean confirm = false;
        if(SubTotal >= StaticConfig.StartPrice){
            confirm = true;
            ConfirmOrder.setVisibility(View.VISIBLE);
            CancelOrder.setVisibility(View.VISIBLE);
        }else {
            ConfirmOrder.setVisibility(View.GONE);
            CancelOrder.setVisibility(View.GONE);
        }
        // updateAlertIcon(packets, confirm);
        ConfirmOrder.setText("Check Out\t"+String.format("%.2f", SubTotal)+ currency +"\t\t");
        DetailsSubTotalPrice.setText(
                "Packets : "+packets+
                        " QTY\t\t" +unities+
                        " Unities\t\tTotal Price : "+String.format("%.2f", SubTotal)+ currency);

        describeTxt.setText(Html.fromHtml("<h1>Confirm your Order</h1>" +
                "<h2>Total Price "+ String.format("%.2f", SubTotal)+" "+currency +
                "</h2><h3>Delivery Day is "+StaticConfig.DayToDelivery+"</h3>"
        ));
    }

    private void setOrder(){
        Date date = new Date();
        DateFormat sdf_us = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
        DateFormat sdf_uk = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");

        // Order myOrder = new Order();
        // IDs Order

        myOrder.adminID = mySupplierID;
        myOrder.fullName = userData.fullName;
        myOrder.storeAddress = userData.address;
        myOrder.storeName = userData.storeName;
        myOrder.userID = StaticConfig.UID;
        myOrder.orderID = mDatabase.push().getKey();

        // set random track number
        // create instance of Random class
        Random rand = new Random();
        // Generate random integers in range 0 to 999
        // ThreadLocalRandom.current().nextInt();
        myOrder.trackNumber = rand.nextInt(10000);
        // date time to delivery order
        // day at week work
        myOrder.DayToDeliveryOrder = StaticConfig.DayToDelivery;
        myOrder.dateTimeToPostOrder = sdf_uk.format(date);
        myOrder.status = "pending";
        myOrder.description = "";
        myOrder.orderFrom = "Stock";

        int unities = 0;
        int packets = 0;
        double Total = 0;

        for(MyBasket my_Basket : db.getAllBaskets()){
            unities += (my_Basket.unities * my_Basket.packets);
            packets += my_Basket.packets;
            Total += my_Basket.total;
        }
        myOrder.packets = packets;
        myOrder.totalPrice = Total;
        // myOrder.myBasket = db.getAllBaskets();
        /*
        mDatabase.child("Orders").child(myOrder.orderID).setValue(myOrder).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if(task.isSuccessful()){
                    for(MyBasket my_basket : db.getAllBaskets()){
                        mDatabase.child("Orders").child(myOrder.orderID).child("myBasket").child(my_basket.basketID).setValue(my_basket);
                    }
                    msg("Successful");
                    db.deleteTable();
                    SetDetailsToolBar();
                    dialog.dismiss();

                    ConfirmOrder.setVisibility(View.GONE);
                    CancelOrder.setVisibility(View.GONE);

                    // go to histories order
                }else{
                    msg("try again data not saved!!!");
                }
            }
        });
        */
    }



    // Call Back method  to get the Message form other Activity
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        // check if the request code is same as what is passed  here it is 2
        if(requestCode == requestCode1) {
            // scannedListProducts.add();
            recycler = new recyclerViewAdapter(this, scannedListProducts);
            recyclerview.setAdapter(recycler);
            recycler.notifyDataSetChanged();
        }
    }


    /*
              String message=editText1.getText().toString();
                    Intent intent=new Intent();
                    intent.putExtra("MESSAGE",message);
                    setResult(2,intent);
                    finish();//finishing activity
     */


    public void msg(String text){
        //Snackbar.make(view, text, Snackbar.LENGTH_LONG).setAction("Action", null).show();
        Toast.makeText(this, text, Toast.LENGTH_SHORT).show();
    }

    // AdapterView scanned items
    private class recyclerViewAdapter extends RecyclerView.Adapter<recyclerViewAdapter.MyHolder> {
        private Context context;
        List<MyBasket> myBaskets;

        public recyclerViewAdapter(Context context, List<MyBasket> myBaskets) {
            this.myBaskets = myBaskets;
            this.context = context;
        }

        @Override
        public MyHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_items_pos, parent, false);
            MyHolder myHolder = new MyHolder(view);
            return myHolder;
        }

        public void onBindViewHolder(MyHolder holder, int position) {
            MyBasket data = myBaskets.get(position);
            Glide.with(context).load(data.imagePath).into(holder.ProductImage);
            //  image, name, barcode, number of unities at one packet, describe, price, unities, Edit scanned unities

            /*
            Item Name : CocaCola
Category name : Drinks
Describe : text text  ... read more
BarCode : 1234567890
ItemID : 871231293
Expire at : 11/11/2011 11:11:11"
             */
        //double totalPriceAtStock = (data.packets * data.unities * data.priceAtStock);
        holder.ItemDetails.setText(
                data.productName+"\n"+
                        // data.description+"\n"+
                        data.barCode+"\n"+
                        data.unities +"\n"+
                        data.price);

    }

    @Override
    public int getItemCount() {
        return myBaskets.size();
    }


    class MyHolder extends RecyclerView.ViewHolder {
            ImageView ProductImage, EditProduct, DeleteProduct;
        TextView ItemDetails;
        private final Context context;
        public MyHolder(final View itemView) {
            super(itemView);
            context = itemView.getContext();

            final Intent[] intent = new Intent[1];
            ProductImage = (ImageView) itemView.findViewById(R.id.productImage);
            EditProduct = (ImageView) itemView.findViewById(R.id.editProduct);
            DeleteProduct = (ImageView) itemView.findViewById(R.id.deleteProduct);

            ItemDetails = (TextView) itemView.findViewById(R.id.itemDetails);
            EditProduct.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) { }
            });

            DeleteProduct.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    final String ProductKey = myBaskets.get(getAdapterPosition()).productID;
                    String ProductName = myBaskets.get(getAdapterPosition()).productName;

                    new android.app.AlertDialog.Builder(POSActivity.this)
                            .setTitle("Delete Product")
                            .setMessage("Are you sure do you want to delete " + ProductName + " ?")
                            .setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialogInterface, int i) {
                                    dialogInterface.dismiss();

                                }
                            })
                            .setNegativeButton(android.R.string.cancel, new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialogInterface, int i) {
                                    dialogInterface.dismiss();
                                }
                            }).show();
                }
            });


            itemView.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View v) {
                    /*
                    final String productID = listProducts.get(getAdapterPosition()).productID;
                    String productName = listProducts.get(getAdapterPosition()).productName;
                    String categoryName = listProducts.get(getAdapterPosition()).categoryName;

                    new AlertDialog.Builder(context)
                            .setTitle("Delete Product "+productName)
                            .setMessage("Are you sure want to delete " + productName +" From "+ categoryName + " ?")
                            .setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialogInterface, int i) {
                                    dialogInterface.dismiss();
                                    FirebaseDatabase.getInstance().getReference().child("Products").child(productID).removeValue();
                                }})
                            .setNegativeButton(android.R.string.cancel, new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialogInterface, int i) {
                                    dialogInterface.dismiss();
                                }
                            }).show();
                    */
                    return false;
                }
            });
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    //   view full item details

                }
            });
        }
        }
    }



    private class MyAdapterCategories extends RecyclerView.Adapter<MyAdapterCategories.ViewHolder> {
        private Context context;
        private List<Category> categories;
        public MyAdapterCategories(Context context, List<Category> categories) {
            this.categories = categories;
            this.context = context;
        }
        @Override
        public MyAdapterCategories.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_categories_pos, parent, false);
            MyAdapterCategories.ViewHolder viewHolder = new MyAdapterCategories.ViewHolder(v);
            return viewHolder;
        }

        @Override
        public void onBindViewHolder(MyAdapterCategories.ViewHolder holder, final int position) {
            Category category = categories.get(position);
            holder.DataDetails.setText(category.categoryName);
            try {
                Long items = category.itemsNumber;
                String product = " Product";
                if(items > 1){
                    product += "s";
                }
                holder.itemNumber.setText(String.valueOf(items)+ product);
            }catch (Exception e){ msg("enable to set item number in string\nerror 33 :"+e);}
            Glide.with(context).load(category.imagePath).into(holder.imageViewCategory);
        }

        @Override
        public int getItemCount() { return categories.size(); }
        class ViewHolder extends RecyclerView.ViewHolder {
            public TextView DataDetails, itemNumber;
            public ImageView imageViewCategory;
            public FrameLayout rootView;

            private final Context context;
            public ViewHolder(View itemView) {
                super(itemView);
                context = itemView.getContext();
                final Intent[] intent = new Intent[1];
                rootView = (FrameLayout) itemView.findViewById(R.id.rootView);
                itemNumber = (TextView) itemView.findViewById(R.id.itemsNumber);
                DataDetails = (TextView) itemView.findViewById(R.id.dataDetails);
                imageViewCategory = (ImageView) itemView.findViewById(R.id.imageViewCategory);

                itemView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        fetchDataByCategories(categories.get(getAdapterPosition()).categoryID);
                        // rootView.setBackground(getResources().getDrawable(R.drawable.bt_shape_green));
                    }
                });
            }
        }
    }

    public void fetchDataByCategories(String categoryID){
        mDatabase.child("Categories").child(categoryID).child("Products").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                try {
                    // dismissing the progress dialog
                    // progressDialog.dismiss();
                    if(dataSnapshot.exists()) {
                        List<ListProducts> MyListProducts = new ArrayList<>();
                        MyListProducts.clear();
                        for (DataSnapshot postSnapshot1 : dataSnapshot.getChildren()) {
                            ListProducts listProducts = postSnapshot1.getValue(ListProducts.class);
                            MyListProducts.add(listProducts);
                        }
                        recyclerviewProducts.setAdapter(new ProductsViewAdapter(POSActivity.this, MyListProducts));
                    }
                }catch (Exception e){msg("Error in fetch data by categories : "+e);}
            }
            @Override
            public void onCancelled(DatabaseError databaseError){}
        });
    }

    public class ProductsViewAdapter extends RecyclerView.Adapter<ProductsViewAdapter.MyHolder> {
        private Context context;
        List<ListProducts> listProducts;
        public ProductsViewAdapter(Context context, List<ListProducts> listProducts) {
            this.listProducts = listProducts;
            this.context = context;
        }
        @Override
        public ProductsViewAdapter.MyHolder onCreateViewHolder(ViewGroup parent, int viewType){
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_basket_product_pos, parent, false);
            ProductsViewAdapter.MyHolder myHolder = new ProductsViewAdapter.MyHolder(view);
            return myHolder;
        }
        public void onBindViewHolder(ProductsViewAdapter.MyHolder holder, int position) {
            ListProducts data = listProducts.get(position);

            Glide.with(context).load(data.imagePath).into(holder.ProductImage);
            double[] Prices = {data.sellPriceStock,
                    data.sellPriceStore,
                    data.sellPriceDeliverer,
                    data.sellPriceCustomer};

            holder.ItemName.setText(data.productName);
            //holder.NormalPrice.setText(Html.fromHtml("<strike>"+data.discountPrice+"</strike> "+ currency));
            holder.PriceTV.setText(Prices[3]+ currency); //"€"

               /*
            for(MyBasket my_basket : db.getAllBaskets()) {
                if (my_basket.productID.equals(data.productID)) {
                    if (my_basket.packets == 0) {
                        // show dialog
                        holder.RemoveItem.setVisibility(View.GONE);
                        holder.CartProductDetails.setVisibility(View.GONE);
                        holder.ItemsNumber.setVisibility(View.GONE);
                    } else {
                        holder.RemoveItem.setVisibility(View.VISIBLE);
                        holder.CartProductDetails.setVisibility(View.VISIBLE);
                        holder.ItemsNumber.setVisibility(View.VISIBLE);
                    }

                    // SetDetailsToolBar();
                    // holder.ItemsNumber.setText(Integer.toString(my_basket.packets * my_basket.unities));
                    //SetDetailsCart(Unities, Packets, Price);
                    // holder.CartProductDetails.setText(my_basket.packets + "x" + my_basket.unities + "x" +
                    //        my_basket.price + "=" + String.format("%.2f", (my_basket.packets * my_basket.unities * my_basket.price)) + currency);
                }
            }
            */
        }

        @Override
        public int getItemCount() {
            return listProducts.size();
        }

        class MyHolder extends RecyclerView.ViewHolder {
            private Context context;

            ImageView ProductImage, RemoveItem;
            TextView  ItemName, ItemsNumber, CartProductDetails, PriceTV;
            LinearLayout rootView;

            void SetDetailsCart(int unities,int packets, double price){
                CartProductDetails.setText(packets +"x"+unities +"x"+
                        price+"="+ String.format("%.2f", (packets * unities * price))+currency);
            }
            public MyHolder(final View itemView){
                super(itemView);
                context = itemView.getContext();
                final Intent[] intent = new Intent[1];

                ProductImage = (ImageView) itemView.findViewById(R.id.productImage);
                RemoveItem = (ImageView) itemView.findViewById(R.id.remove_item);
                ItemName = (TextView) itemView.findViewById(R.id.itemName);
                ItemsNumber = (TextView) itemView.findViewById(R.id.itemsNumber);
                rootView = (LinearLayout) itemView.findViewById(R.id.rootView);

                CartProductDetails = (TextView) itemView.findViewById(R.id.cartProductDetails);
                PriceTV = (TextView) itemView.findViewById(R.id.Price);
            }
        }


/*
            void setCart(String type){
                try {
                    int packets = 0;
                    int unities = 0;
                    double price = 0.00;
                    switch (type){
                        case "new":
                            //add barCode
                            CartProductDetails.setVisibility(View.VISIBLE);
                            // add one item to my basket
                            // get basket position add one
                            MyBasket myCart = new MyBasket();
                            // myCart.listProducts = listProducts.get(getAdapterPosition());
                            double[] Prices = {
                                    listProducts.get(getAdapterPosition()).sellPriceStock,
                                    listProducts.get(getAdapterPosition()).sellPriceStore,
                                    listProducts.get(getAdapterPosition()).sellPriceDeliverer,
                                    listProducts.get(getAdapterPosition()).sellPriceCustomer};
                            int i = 0;
                            switch (userData.orderFrom){
                                case "Stock":
                                    i = 0;
                                case "Store":
                                    i = 1;
                                    break;
                                case "Deliver":
                                    i = 2;
                                    break;
                                case "Customer":
                                    i = 3;
                                    break;
                            }

                            myCart.price = Prices[i];
                            price = myCart.price;
                            myCart.unities = listProducts.get(getAdapterPosition()).unities;
                            myCart.imagePath = listProducts.get(getAdapterPosition()).imagePath;
                            myCart.productName = listProducts.get(getAdapterPosition()).productName;
                            myCart.productID = listProducts.get(getAdapterPosition()).productID;
                            myCart.describe = listProducts.get(getAdapterPosition()).description;
                            myCart.categoryID = listProducts.get(getAdapterPosition()).categoryID;
                            myCart.barCode = listProducts.get(getAdapterPosition()).barCode;
                            myCart.status = "pending";
                            myCart.position = 0;

                            myCart.packets = 1;
                            packets = myCart.packets;
                            unities = myCart.unities;

                            myCart.basketID = mDatabase.push().getKey();
                            myCart.total = (myCart.packets * myCart.unities * myCart.price);
                            db.insertBasket(myCart);
                            //myBasket.add(myCart.position, myCart);
                            //myBasket.add(myCart);

                            break;
                        case "add":
                            for(MyBasket myBasketID : db.getAllBaskets()){
                                String productID = myBasketID.productID;
                                if(productID.equals(listProducts.get(getAdapterPosition()).productID)){
                                    packets = myBasketID.packets + 1;
                                    unities = myBasketID.unities;
                                    price = myBasketID.price;
                                    double total = (packets * myBasketID.unities * myBasketID.price);
                                    db.updateBasket(productID, packets, total);
                                }
                            }
                            break;
                        case "sub":
                            for(MyBasket myBasketID : db.getAllBaskets()){
                                String productID = myBasketID.productID;
                                if(productID.equals(listProducts.get(getAdapterPosition()).productID)){
                                    packets = myBasketID.packets - 1;
                                    unities = myBasketID.unities;
                                    price = myBasketID.price;
                                    double total = (packets * myBasketID.unities * myBasketID.price);
                                    if (packets == 0) {
                                        // show dialog
                                        AddToCart.setVisibility(View.VISIBLE);
                                        AddToCartDialog.setVisibility(View.GONE);
                                        CartProductDetails.setVisibility(View.GONE);
                                        db.deleteBasket(productID);
                                    }else {
                                        db.updateBasket(productID, packets, total);
                                    }
                                }
                            }
                            break;
                    }

                    if(packets < 2) {
                        // change subtraction icon to ( x )
                        SubtractItem.setImageDrawable(getResources().getDrawable(R.drawable.delete_item));
                    } else {
                        // change subtraction icon to ( - )
                        SubtractItem.setImageDrawable(getResources().getDrawable(R.drawable.subtract_item));
                    }
                    ItemsNumber.setText(Integer.toString(packets * unities));
                    //Toast.makeText(context, "position : " + myCart.position, Toast.LENGTH_SHORT).show();
                    SetDetailsCart(unities, packets, price);
                    SetDetailsToolBar();
                }catch (Exception e){
                    Toast.makeText(context, "error in "+type+" :\n" + e, Toast.LENGTH_LONG).show();
                }
            }
*/
    }
}

