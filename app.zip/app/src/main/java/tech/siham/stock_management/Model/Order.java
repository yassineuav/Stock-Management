package tech.siham.stock_management.Model;

public class Order {

    //public List<MyBasket> myBasket ;
    // order details
    public String userID;
    public String adminID;
    public String orderID;
    public int trackNumber; // generate barcode and set it on pdf and save id in db for history

    public int packets;

    public double totalPrice;

    public String dateTimeToPostOrder; // for post order
    public String DayToDeliveryOrder; // datetime to delivery customer order, set by admin

    // show at admin
    public String description; // if item not found send description with price to Admin

    public String orderFrom; // order from : [store | stock | home | business| other > set name]

    public String status;
    /*
     Status : [sent, received, ready, not ready, pending, date to delivery, scheduled, refused, update, date changed
     */
    // note : if quantity at store less than quantity  at cart then send notification to Admin
    // note : if item no found at store, Client could add item with description and price
    public Order(){
        //myBasket = new MyBasket();
        // myBasket = new ArrayList<>();
    }
    public String fullName;
    public String storeAddress;
    public String storeName;


}
