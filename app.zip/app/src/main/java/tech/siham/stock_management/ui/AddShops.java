package tech.siham.stock_management.ui;

import android.app.Dialog;
import android.content.Intent;
import android.support.design.widget.CoordinatorLayout;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import java.util.Random;

import tech.siham.stock_management.Data.SharedPreferenceHelper;
import tech.siham.stock_management.Data.StaticConfig;
import tech.siham.stock_management.Fragments.FragmentList;
import tech.siham.stock_management.Fragments.FragmentMap;
import tech.siham.stock_management.Model.SharedCode;
import tech.siham.stock_management.R;

public class AddShops extends AppCompatActivity {

    FloatingActionButton ShareCodeBtn;
    private DatabaseReference mDatabase;
    CoordinatorLayout coordinatorLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_shops);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle("Manage Shops");

        // current supplier | add new supplier
        // search on user by name | address | rate

        // - recycleReview for users details :
        // - image, full name, Address, distance, rate
        // - button : send request: invite | pending | accept
        // - long click : delete dialog > cancel | delete
        // - onItemsClick : show profile information

        coordinatorLayout = (CoordinatorLayout) findViewById(R.id.coordinatorLayout);
        ShareCodeBtn = (FloatingActionButton) findViewById(R.id.share_code);

        mDatabase = FirebaseDatabase.getInstance().getReference();
        ShareCodeBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

        /*
        data set in db for one time
        share data from db to users
         */

        // add new user by clicking on + button
        /*
        click on + button
        add new url link
        add data to database link/shared_code
        click on link open package name
        if app exist on device open activity > profile for invitor
        else go to play store to download app :
            if stock user invitor : open store user app name
            else if store user invitor : open stock user app name
         */

                mDatabase.child("SharedCode").child("invitorFromStock").child(StaticConfig.UID).addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        SharedCode sharedCode = new SharedCode();

                        String invitorID = StaticConfig.UID;
                        //String currentDateTime = (new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(new Date()));
                        String codeTxt = String.format("%04d", new Random().nextInt(10000));
                        //String codeTxt = String.valueOf((int)(Math.random()*(9000))+1000);
                        String textMessage = "";
                        String linkURL = "tech.shayma.stock_management/?app=shop&code=";

                        if (dataSnapshot.exists()) {
                            SharedCode dataSharedCode = dataSnapshot.getValue(SharedCode.class);
                            codeTxt = dataSharedCode.code;
                            linkURL = linkURL + codeTxt;

                        } else {

                            sharedCode.code = codeTxt;
                            sharedCode.invitorID = invitorID;
                            sharedCode.url = linkURL + codeTxt;

                            mDatabase.child("SharedCode").child("invitorFromStock").child(invitorID).setValue(sharedCode);
                        }


                        if (invitorID.isEmpty() && linkURL.isEmpty() && codeTxt.isEmpty()) {
                            textMessage = "Ops ... something wrong try again";

                        } else {

                            Intent sharingIntent = new Intent(android.content.Intent.ACTION_SEND);
                            sharingIntent.setType("text/plain");
                            String shareBodyText =
                                    "To Add Supplier " + (SharedPreferenceHelper.getInstance(AddShops.this).getUserInfo().fullName) + " for making orders easy click on  " + linkURL
                                            + "\nor Enter this code " + codeTxt
                                            + "\nWhere I can enter the code >>> open shop app > menu > my suppliers > click on (+) button in bottom on left " +
                                            "then set the code " + codeTxt + " then add supplier button";
                            sharingIntent.putExtra(android.content.Intent.EXTRA_SUBJECT, "Subject here");
                            sharingIntent.putExtra(android.content.Intent.EXTRA_TEXT, shareBodyText);
                            startActivity(Intent.createChooser(sharingIntent, "Shearing Option"));
                            textMessage = "Your Code Generated successfully";

                        }
                        Snackbar snackbar = Snackbar.make(coordinatorLayout, textMessage, Snackbar.LENGTH_LONG);
                        snackbar.show();
                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {
                    }
                });
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.action_menu_add_code, menu);
        return true;
    }

    private void loadFragment(Fragment fragment) {
        android.support.v4.app.FragmentManager fm = getSupportFragmentManager();
        android.support.v4.app.FragmentTransaction fragmentTransaction = fm.beginTransaction();
        fragmentTransaction.replace(R.id.frameLayout, fragment);
        fragmentTransaction.commit();
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case android.R.id.home :
                onBackPressed();
                return true;
                // display map
            case R.id.display_map:
                // startActivity(new Intent(AddShops.this, MapsActivity.class));
                loadFragment(new FragmentMap());
                break;
                // display list
            case R.id.display_list:
                loadFragment(new FragmentList());
                break;
            case R.id.add_code:
                // show dialog
                // show textView + editText
                // if code exist in db then add successfully
                // else : try again the code is wrong
                final Dialog dialog = new Dialog(AddShops.this);
                dialog.setContentView(R.layout.custom_add_user);
                final EditText referenceCode = (EditText) dialog.findViewById(R.id.referenceCode);
                Button dialogButtonAdd = (Button) dialog.findViewById(R.id.add_user);
                Button dialogButtonCancel = (Button) dialog.findViewById(R.id.cancel_dialog);

                dialogButtonAdd.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String sharedCode = referenceCode.getText().toString().trim();
                        if (sharedCode.isEmpty()) {
                            referenceCode.setError("please set your reference code");
                            return;
                        }

                        Query query = mDatabase.child("SharedCode").child("invitorFromStock").orderByChild("code").equalTo(sharedCode);
                        query.addValueEventListener(new ValueEventListener() {
                            @Override
                            public void onDataChange(DataSnapshot dataSnapshot) {
                                if (dataSnapshot.exists()) {
                                    SharedCode sharedCode = dataSnapshot.child(dataSnapshot.getChildren().iterator().next().getKey()).getValue(SharedCode.class);
                                    Toast.makeText(AddShops.this, "Code exist" +
                                            "\nid invitor : " + sharedCode.invitorID +
                                            "\ncode : " + sharedCode.code +
                                            "\nurl : " + sharedCode.url, Toast.LENGTH_SHORT).show();
                                    dialog.dismiss();
                                    // open profile of new user
                                } else {
                                    Toast.makeText(AddShops.this, "Code doesn't exist", Toast.LENGTH_SHORT).show();
                                    referenceCode.setError("this code doesn't exist \ntry with correct code!");
                                }
                            }
                            @Override
                            public void onCancelled(DatabaseError databaseError) { }
                        });

                    }
                });
                dialogButtonCancel.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) { dialog.dismiss(); }
                });
                dialog.show();

                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
        return super.onOptionsItemSelected(item);
    }
}
