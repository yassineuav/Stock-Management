package tech.siham.stock_management;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.util.Base64;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import tech.siham.stock_management.Auth.LoginActivity;
import tech.siham.stock_management.Data.SharedPreferenceHelper;
import tech.siham.stock_management.Model.User;
import tech.siham.stock_management.ui.AddShops;
import tech.siham.stock_management.ui.CategoryActivity;
import tech.siham.stock_management.ui.MapsActivity;
import tech.siham.stock_management.ui.OrdersActivity;
import tech.siham.stock_management.ui.POSActivity;
import tech.siham.stock_management.ui.SettingsActivity;
import tech.siham.stock_management.ui.ShopsAccounts;
import tech.siham.stock_management.ui.UserProfile;
import tech.siham.stock_management.ui.orderProductsActivity;
import tech.siham.stock_management.ui.setProfile;
import tech.siham.stock_management.utils.ImageUtils;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;


import de.hdodenhof.circleimageview.CircleImageView;
import tech.siham.stock_management.Data.StaticConfig;

import static android.Manifest.permission.CAMERA;
import static android.Manifest.permission.READ_EXTERNAL_STORAGE;
import static android.Manifest.permission.WRITE_EXTERNAL_STORAGE;


public class MainActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {

    public static final int RequestPermissionCode = 1;

    private FirebaseAuth mAuth;
    private FirebaseAuth.AuthStateListener mAuthListener;
    private FirebaseUser user;

    LinearLayout Categories, Orders;

    private DatabaseReference mDatabase;
    View navigation_view;
    CheckConnection checkConnection;
    User DataUser;
    SharedPreferenceHelper sharedPreference;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        // setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);

        if(Build.VERSION.SDK_INT >= 23) {
            if (checkPermission()) {
                //     Toast.makeText(MainActivity.this, "All Permissions Granted Successfully", Toast.LENGTH_LONG).show();
            } else {
                requestPermission();
            }
        }

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        checkConnection = new CheckConnection(this);
        sharedPreference = SharedPreferenceHelper.getInstance(this);


        DataUser = new User();
        DataUser = sharedPreference.getUserInfo();

        StaticConfig.UID = sharedPreference.getUID();

        //UID = mAuth.getCurrentUser().getUid();

        mDatabase = FirebaseDatabase.getInstance().getReference("Stock");

        Categories = (LinearLayout) findViewById(R.id.categories);
        Orders = (LinearLayout) findViewById(R.id.orders);

        /*
        if(!checkConnection.isInternetAvaliable()){
            msg("Please check your Connecting");
            switch (DataUser.accountStatus){
                case "pending" :
                    msg("Pending :: >> \n"+DataUser.accountStatus);
                    // startActivity(new Intent(MainActivity.this, setProfile.class));
                    // finish();
                    break;
            }
        }
        */
        Categories.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, CategoryActivity.class));
            }
        });
        Orders.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, OrdersActivity.class));
            }
        });
        ((LinearLayout) findViewById(R.id.pos)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, POSActivity.class));
            }
        });
        ((LinearLayout) findViewById(R.id.order_products)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, orderProductsActivity.class));
            }
        });
        ((LinearLayout) findViewById(R.id.settings)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, SettingsActivity.class));
            }
        });

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG).setAction("Action", null).show();
                // startActivity(new Intent(MainActivity.this, MapsActivity.class));

                Intent intent = new Intent(MainActivity.this, MapsActivity.class);
                // intent.putExtra("orderID", "-M4a4HxfUoqOYzDYKcn3");
                startActivity(intent);

            }
        });

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
        navigation_view = navigationView.getHeaderView(0);
        ((LinearLayout) navigation_view.findViewById(R.id.profileData)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, UserProfile.class));
            }
        });

        mAuth = FirebaseAuth.getInstance();

        mAuthListener = new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                user = firebaseAuth.getCurrentUser();
                firebaseAuth.addIdTokenListener(new FirebaseAuth.IdTokenListener() {
                    @Override
                    public void onIdTokenChanged(@NonNull FirebaseAuth firebaseAuth) { }
                });

                if (user == null) {
                    startActivity(new Intent(MainActivity.this, LoginActivity.class));
                    finish();
                } else {

                    StaticConfig.UID = user.getUid();
                    // check if email verify or not
                    // if (user.isEmailVerified() == true) {
                        mDatabase.child(StaticConfig.UID).addValueEventListener(new ValueEventListener() {
                            @Override
                            public void onDataChange(DataSnapshot dataSnapshot) {
                                try {
                                    DataUser = dataSnapshot.getValue(User.class);
                                    if (dataSnapshot.exists()) {

                                        if (DataUser.accountStatus == null || DataUser.accountStatus.equals("new")) {
                                            startActivity(new Intent(MainActivity.this, setProfile.class));
                                            finish();
                                        } else {
                                            sharedPreference.saveUserInfo(DataUser);
                                            setImageAvatar(DataUser.avatar);
                                            ((TextView) navigation_view.findViewById(R.id.profileDetails)).setText(
                                                    "Full Name: " + DataUser.fullName +
                                                            "\n"+DataUser.orderFrom+" Name: " + DataUser.storeName +
                                                            "\nEmail: " + DataUser.email +
                                                            "\nPhone: " + DataUser.phoneNumber +
                                                            "\nAddress: " + DataUser.address +
                                                            "\nAccount Status: " + DataUser.accountStatus);
                                        }
                                        // user.accountStatus.equals("pending")
                                        // account Status : pending / accepted /refused
                                    } else {
                                        startActivity(new Intent(MainActivity.this, setProfile.class));
                                        finish();
                                    }
                                }catch (Exception e){
                                    Toast.makeText(MainActivity.this,"error : "+e, Toast.LENGTH_LONG).show();
                                }
                            }
                            @Override
                            public void onCancelled(DatabaseError databaseError) { }
                        });
                }
            }};


    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();
        if (id == R.id.nav_share) {
            startActivity(new Intent(this, ShopsAccounts.class));
        } else if (id == R.id.nav_settings) {
            startActivity(new Intent(this, SettingsActivity.class));
        } else if (id == R.id.nav_shops_accounts) {
            startActivity(new Intent(this, AddShops.class));
        } else if (id == R.id.nav_share) {

        } else if (id == R.id.nav_sing_out) {
            mAuth.signOut();
            startActivity(new Intent(this, LoginActivity.class));
            finish();
        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    void setImageAvatar(String imgBase64){
        try {
            Resources res = getResources();
            Bitmap src;
            if (imgBase64.equals("default")) {
                src = BitmapFactory.decodeResource(res, R.drawable.default_avata);
            } else {
                byte[] decodedString = Base64.decode(imgBase64, Base64.DEFAULT);
                src = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
            }

            ((CircleImageView) navigation_view.findViewById(R.id.imageProfile)).setImageDrawable(ImageUtils.roundedImage(MainActivity.this, src));
        }catch (Exception e){ }
    }

    void msg(String txt){
        Toast.makeText(this, txt, Toast.LENGTH_LONG).show();
    }


    @Override
    protected void onStart() {
        super.onStart();
        mAuth.addAuthStateListener(mAuthListener);
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (mAuthListener != null) {
            mAuth.removeAuthStateListener(mAuthListener);
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    private void requestPermission() {
        ActivityCompat.requestPermissions(this, new String[]{
                WRITE_EXTERNAL_STORAGE,
                READ_EXTERNAL_STORAGE,
                CAMERA,
        }, RequestPermissionCode);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        switch (requestCode) {
            case RequestPermissionCode:
                if (grantResults.length > 0) {
                    boolean WriteDataPermission = grantResults[0] == PackageManager.PERMISSION_GRANTED;
                    boolean ReadDataPermission = grantResults[1] == PackageManager.PERMISSION_GRANTED;
                    boolean CameraPermission = grantResults[2] == PackageManager.PERMISSION_GRANTED;

                    if (WriteDataPermission && ReadDataPermission && CameraPermission ) {
                        Toast.makeText(this, "Permission Granted", Toast.LENGTH_LONG).show();
                    } else {
                                Toast.makeText(this,"Permission Denied",Toast.LENGTH_LONG).show();
                    }
                }
                break;
        }
    }

    public boolean checkPermission() {
        int FirstPermissionResult = ContextCompat.checkSelfPermission(getApplicationContext(), READ_EXTERNAL_STORAGE);
        int SecondPermissionResult = ContextCompat.checkSelfPermission(getApplicationContext(), WRITE_EXTERNAL_STORAGE);
        int ThirdPermissionResult = ContextCompat.checkSelfPermission(getApplicationContext(), CAMERA);
        return FirstPermissionResult == PackageManager.PERMISSION_GRANTED &&
                SecondPermissionResult == PackageManager.PERMISSION_GRANTED &&
                ThirdPermissionResult == PackageManager.PERMISSION_GRANTED  ;
    }
}

                        /*
                    } else {
                        // show dialog to verification email
                        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                        builder.setMessage(" verify your email to get start "+user.getEmail());
                        builder.setTitle("Verify your email");
                        builder.setCancelable(false);
                        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                                            @Override
                                            public void onClick(final DialogInterface dialog, int which){


                                                // Send verification email
                                                // [START send_email_verification]
                                                user.sendEmailVerification()
                                                        .addOnCompleteListener(MainActivity.this, new OnCompleteListener<Void>() {
                                                            @Override
                                                            public void onComplete(@NonNull Task<Void> task) {
                                                                // [START_EXCLUDE]
                                                                if (task.isSuccessful()) {
                                                                    Toast.makeText(MainActivity.this,
                                                                            "Verification email sent to " + user.getEmail(),
                                                                            Toast.LENGTH_SHORT).show();
                                                                    dialog.cancel();

                                                                } else {
                                                                    Toast.makeText(MainActivity.this,
                                                                            "Failed to send verification email.",
                                                                            Toast.LENGTH_SHORT).show();
                                                                }
                                                                // [END_EXCLUDE]
                                                            }
                                                        });
                                                // [END send_email_verification]

                                            }
                                        });
                        // Create the Alert dialog
                        AlertDialog alertDialog = builder.create();
                        // Show the Alert Dialog box
                        alertDialog.show();
                    }
                    */