package tech.siham.stock_management.FragmentsSettings;


import android.app.Dialog;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import tech.siham.stock_management.Data.SharedPreferenceHelper;
import tech.siham.stock_management.R;

public class BluetoothBarcodeScanner extends Fragment {


    public BluetoothBarcodeScanner() { }

    private RadioGroup radioGroup;
    SharedPreferenceHelper sharedPreference;
    View root;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        root = inflater.inflate(R.layout.fragment_bluetooth_barcode_scanner, container, false);

        radioGroup = (RadioGroup) root.findViewById(R.id.radioGroup);

        sharedPreference = SharedPreferenceHelper.getInstance(getContext());

        checkStatus();

        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                RadioButton rb = (RadioButton) group.findViewById(checkedId);
                if (null != rb){
                    if(checkedId == R.id.cameraScanner) {
                        sharedPreference.useCamera(true);
                    }else if(checkedId == R.id.gunScanner) {
                        // show dialog to connect bluetooth
                        final Dialog dialog = new Dialog(getContext());
                        dialog.setContentView(R.layout.dialog_scanner_connect);
                        Button btnCancel = (Button) dialog.findViewById(R.id.cancel);
                        Button btnConnecting = (Button) dialog.findViewById(R.id.connecting);
                        dialog.show();
                        btnConnecting.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                sharedPreference.useCamera(false);
                                dialog.dismiss();
                            }
                        });
                        btnCancel.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                dialog.dismiss();
                            }
                        });
                    }
                    checkStatus();
                }

            }
        });

        return root;
    }

    private void checkStatus(){
        RadioButton rbCam = (RadioButton) root.findViewById(R.id.cameraScanner);
        RadioButton rbGun = (RadioButton) root.findViewById(R.id.gunScanner);

        TextView GunStatus = (TextView) root.findViewById(R.id.GunStatus);
        if(sharedPreference.useCamera()){
            rbCam.setChecked(true);
            rbGun.setChecked(false);
            GunStatus.setVisibility(View.GONE);
        }else{
            rbCam.setChecked(false);
            rbGun.setChecked(true);
            GunStatus.setVisibility(View.VISIBLE);
        }
        Toast.makeText(getContext(), "status > "+sharedPreference.useCamera(), Toast.LENGTH_SHORT).show();

    }

}
