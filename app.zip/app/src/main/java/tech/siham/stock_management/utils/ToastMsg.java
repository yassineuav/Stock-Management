package tech.siham.stock_management.utils;

import android.content.Context;
import android.widget.Toast;

public class ToastMsg {
    public ToastMsg(Context context,String text){
        Toast.makeText(context, text, Toast.LENGTH_LONG).show();
    }
}
