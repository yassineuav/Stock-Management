package tech.siham.stock_management.ui;

import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.app.TimePickerDialog;
import android.content.ContentResolver;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.annotation.RequiresApi;
import android.support.v4.content.FileProvider;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.Html;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.webkit.MimeTypeMap;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import tech.siham.stock_management.Data.StaticConfig;
import tech.siham.stock_management.Model.Category;
import tech.siham.stock_management.Model.ListProducts;
import tech.siham.stock_management.R;
import tech.siham.stock_management.view.ScannerActivity;

import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class AddNewProduct extends AppCompatActivity implements AdapterView.OnItemSelectedListener, View.OnClickListener {

    //constant to track image chooser intent
    private static final int PICK_IMAGE_REQUEST = 2340;
    static final int REQUEST_PICTURE_CAPTURE = 1829;
    static final int REQUEST_BARCODE_SCANNER = 2;

    private String pictureFilePath;

    //uri to store file
    private Uri filePath;
    public String ImageName = "";
    public String expiryDate="", expiryTime="";

    //firebase objects
    private StorageReference storageReference;
    private DatabaseReference mDatabase;
    private DatabaseReference mDatabaseCategory;

    FrameLayout addImageProduct;
    ImageView imageProduct;
    LinearLayout DialogSelectImage;

    int[] idArrayEditText = {
            R.id.productName,
            R.id.buyPrice,
            R.id.sellPriceStock,
            R.id.sellPriceStore,
            R.id.sellPriceDeliverer,
            R.id.sellPriceCustomer,
            R.id.discountPrice,
            R.id.unities,
            R.id.packets,
            R.id.location,
            R.id.description,
            R.id.barCodeID
    };

    private int mYear, mMonth, mDay, mHour, mMinute;
    Button ExpiryDate, ExpiryTime, BarCodeScanner;

    List<Category> categoryList = new ArrayList<>();
    public EditText[] EditTEXT = new EditText[idArrayEditText.length];
    int CategoryItemPosition = 0;

    Spinner spinnerCategories, spinnerProductType; // R.id.unityType
    String CategoryID = "", ProductID = "", CategoryName = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_new_product);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle("Add New Product");

        Button captureButton = findViewById(R.id.capture);
        captureButton.setOnClickListener(capture);

        Button GalleryButton = findViewById(R.id.gallery);
        GalleryButton.setOnClickListener(gallery);

        Intent intent = getIntent();
        CategoryID = intent.getStringExtra("categoryID");
        ProductID = intent.getStringExtra("productID");
        CategoryName = intent.getStringExtra("categoryName");

        DialogSelectImage = (LinearLayout) findViewById(R.id.dialog_select_image);

        mDatabase = FirebaseDatabase.getInstance().getReference("Categories");
        mDatabaseCategory = FirebaseDatabase.getInstance().getReference("Categories");
        storageReference = FirebaseStorage.getInstance().getReference("Products");

        imageProduct = (ImageView) findViewById(R.id.imageProduct);
        addImageProduct = (FrameLayout) findViewById(R.id.addImage);

        addImageProduct.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(DialogSelectImage.getVisibility() == View.VISIBLE){
                    DialogSelectImage.setVisibility(View.GONE);
                }else{
                    DialogSelectImage.setVisibility(View.VISIBLE);
                }
            }
        });

        ExpiryDate = (Button) findViewById(R.id.expiryDate);
        ExpiryTime = (Button) findViewById(R.id.expiryTime);

        BarCodeScanner = (Button) findViewById(R.id.barcodeScanner);
        BarCodeScanner.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // open barcode scanner
                Intent intent = new Intent(AddNewProduct.this, ScannerActivity.class);
                StaticConfig.intentMode = "barcodeScanner";
                startActivityForResult(intent, REQUEST_BARCODE_SCANNER);
            }
        });
        spinnerCategories = (Spinner) findViewById(R.id.spinnerCategories);
        // Spinner click listener
        spinnerCategories.setOnItemSelectedListener(this);
        //List<String> categories = new ArrayList<String>();

        /*
        categories.clear();
        categories.add(CategoryName);

        // Creating adapter for spinner
        final ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(AddNewProduct.this, android.R.layout.simple_spinner_item, categories);
        // Drop down layout style - list view with radio button
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        // attaching data adapter to spinner
        spinnerCategories.setAdapter(dataAdapter);
        */

        mDatabaseCategory.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    categoryList.clear();
                    // Spinner Drop down elements
                    List<String> categories = new ArrayList<String>();
                    categories.clear();
                    //iterating through all the values in database
                    for (DataSnapshot postSnapshot : dataSnapshot.getChildren()) {
                        Category data = postSnapshot.getValue(Category.class);
                        if(data.adminID.equals(StaticConfig.UID)){
                            categoryList.add(data);
                            categories.add(data.categoryName);
                        }else{
                            // categoryList.set(0,CategoryName);
                            categories.add(data.categoryName);
                        }
                    }
                    // Creating adapter for spinner
                    ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(AddNewProduct.this, android.R.layout.simple_spinner_item, categories);
                    // Drop down layout style - list view with radio button
                    dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                    // attaching data adapter to spinner
                    spinnerCategories.setAdapter(dataAdapter);

                } else {
                    Toast.makeText(AddNewProduct.this, "No Category exist \nError at Code 1010123", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {}
        });

        try {
            for (int i = 0; i < idArrayEditText.length; i++) {
                final int b = i;
                EditTEXT[b] = (EditText) findViewById(idArrayEditText[b]); // Fetch the view id from array
                EditTEXT[b].addTextChangedListener(new TextWatcher() {
                    @Override
                    public void beforeTextChanged(CharSequence s, int start, int count, int after){}
                    @Override
                    public void onTextChanged(CharSequence s, int start, int before, int count) {
                        String text = EditTEXT[b].getText().toString().trim();
                        if (text.length() == 0) {
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
                                EditTEXT[b].setBackground(getResources().getDrawable(R.drawable.bt_shape_red));
                            }
                        } else {
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
                                EditTEXT[b].setBackground(getResources().getDrawable(R.drawable.bt_shape_green));
                            }
                        }
                    }
                    @Override
                    public void afterTextChanged(Editable s) { }
                });

                if (CategoryID != null && ProductID != null) {

                    EditTEXT[b].setFocusableInTouchMode(false);
                    EditTEXT[b].setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                        final Dialog dialog = new Dialog(AddNewProduct.this);
                        dialog.setContentView(R.layout.custom_edit_product);
                        Button dialogButtonAdd = (Button) dialog.findViewById(R.id.save);
                        Button dialogButtonCancel = (Button) dialog.findViewById(R.id.cancel_dialog);
                        final EditText edit_product = (EditText) dialog.findViewById(R.id.edit_text);
                        edit_product.setText(EditTEXT[b].getText().toString().trim());
                        dialog.show();
                        dialogButtonCancel.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) { dialog.dismiss();
                            }
                        });

                        final String[] target = {
                                "productName",
                                "buyPrice",
                                "sellPriceStock",
                                "sellPriceStore",
                                "sellPriceDeliverer",
                                "sellPriceCustomer",
                                "discountPrice",
                                "unities",
                                "availablePackets",
                                "location",
                                "description",
                                "barCode"
                        };

                        ((TextView) dialog.findViewById(R.id.product_name)).setText("Edit " + target[b]);

                        dialogButtonAdd.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {

                                if (!edit_product.getText().toString().equals(EditTEXT[b].getText().toString().trim())) {
                                    if (b == 1 || b == 2 || b == 3|| b == 4 || b == 5|| b == 6 ) {
                                        try {
                                            double text = Double.parseDouble(edit_product.getText().toString().trim());
                                            mDatabase.child(CategoryID).child("Products").child(ProductID).child(target[b]).setValue(text);
                                        } catch (Exception e){}
                                    } else if (b == 7 || b == 8) {
                                        try {
                                            int text = Integer.parseInt(edit_product.getText().toString().trim());
                                            mDatabase.child(CategoryID).child("Products").child(ProductID).child(target[b]).setValue(text);
                                        } catch (Exception e){}
                                    } else {
                                        String text = edit_product.getText().toString().trim();
                                        mDatabase.child(CategoryID).child("Products").child(ProductID).child(target[b]).setValue(text);
                                    }
                                }
                                dialog.dismiss();
                            }
                        });
                        }
                });
                }
            }

            //EditTEXT[6].setHint(Html.fromHtml("Old or Discount price (<strike style=\"color:red;\">-10.00</strike>$)"));

        } catch(Exception e) {}

        ExpiryDate.setOnClickListener(this);
        ExpiryTime.setOnClickListener(this);

        if(CategoryName != null && ProductID != null && CategoryID != null) {
            getSupportActionBar().setTitle("Edit Product");
            mDatabase.child(CategoryID).child("Products").child(ProductID).addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {
                    if (dataSnapshot.exists()) {

                        ListProducts listProducts = dataSnapshot.getValue(ListProducts.class);
                        ExpiryDate.setText(listProducts.expiryDate);
                        ExpiryTime.setText(listProducts.expiryTime);

                        EditTEXT[0].setText(listProducts.productName);
                        EditTEXT[1].setText(String.valueOf(listProducts.buyPrice));
                        EditTEXT[2].setText(String.valueOf(listProducts.sellPriceStock));
                        EditTEXT[3].setText(String.valueOf(listProducts.sellPriceStore));
                        EditTEXT[4].setText(String.valueOf(listProducts.sellPriceDeliverer));
                        EditTEXT[5].setText(String.valueOf(listProducts.sellPriceCustomer));
                        EditTEXT[6].setText(String.valueOf(listProducts.discountPrice));
                        EditTEXT[7].setText(String.valueOf(listProducts.unities));
                        EditTEXT[8].setText(String.valueOf(listProducts.availablePackets));
                        EditTEXT[9].setText(listProducts.location);
                        EditTEXT[10].setText(listProducts.description);
                        EditTEXT[11].setText(listProducts.barCode);

                        Glide.with(AddNewProduct.this).load(listProducts.imagePath).into(imageProduct);

                    } else {

                    }
                }

                @Override
                public void onCancelled(DatabaseError databaseError) { }
            });
        }
    }

    private View.OnClickListener capture = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            if(getPackageManager().hasSystemFeature(PackageManager.FEATURE_CAMERA)){
                sendTakePictureIntent();
            }
        }
    };

    @Override
    public void onClick(View v) {
        if (v == ExpiryDate) {
            // Get Current Date
            final Calendar c = Calendar.getInstance();
            mYear = c.get(Calendar.YEAR);
            mMonth = c.get(Calendar.MONTH);
            mDay = c.get(Calendar.DAY_OF_MONTH);
            DatePickerDialog datePickerDialog = new DatePickerDialog(this,
                    new DatePickerDialog.OnDateSetListener() {
                        @Override
                        public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                            expiryDate =  (monthOfYear + 1) + "/" +dayOfMonth + "/" + year;
                            ExpiryDate.setText(expiryDate);
                            if(ProductID != null){
                                mDatabase.child(CategoryID).child("Products").child(ProductID).child("expiryDate").setValue(expiryDate);
                            }
                        }}, mYear, mMonth, mDay);
            datePickerDialog.show(); }
        if (v == ExpiryTime ) {
            // Get Current Time
            final Calendar c = Calendar.getInstance();
            mHour = c.get(Calendar.HOUR_OF_DAY);
            mMinute = c.get(Calendar.MINUTE);
            // Launch Time Picker Dialog
            TimePickerDialog timePickerDialog = new TimePickerDialog(this, new TimePickerDialog.OnTimeSetListener() {
                @Override
                public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                    expiryTime = hourOfDay + ":" + minute;
                    ExpiryTime.setText(expiryTime);
                    if(ProductID != null){
                        mDatabase.child(CategoryID).child("Products").child(ProductID).child("expiryTime").setValue(expiryTime);
                    }
                }}, mHour, mMinute, false);
            timePickerDialog.show();
        }
    }

    private View.OnClickListener gallery = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            showGallery();
        }
    };

    private void sendTakePictureIntent(){
        Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        cameraIntent.putExtra( MediaStore.EXTRA_FINISH_ON_COMPLETION, true);
        if (cameraIntent.resolveActivity(getPackageManager()) != null) {
            startActivityForResult(cameraIntent, REQUEST_PICTURE_CAPTURE);
            File pictureFile = null;
            try {
                pictureFile = getPictureFile();
            } catch (IOException ex) {
                Toast.makeText(this, "Photo file can't be created, please try again", Toast.LENGTH_SHORT).show();
                return;
            }
            if (pictureFile != null) {
                Uri photoURI = FileProvider.getUriForFile(this, "tech.siham.stock_management", pictureFile);
                cameraIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);
                startActivityForResult(cameraIntent, REQUEST_PICTURE_CAPTURE);
            }
        }
    }

    private File getPictureFile() throws IOException {
        String timeStamp = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
        String pictureFile = "PRODUCT_" + timeStamp;
        File storageDir = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        File image = File.createTempFile(pictureFile,  ".jpg", storageDir);
        pictureFilePath = image.getAbsolutePath();
        return image;
    }

    void msg(String text){
        Toast.makeText(this, text, Toast.LENGTH_SHORT).show();
    }

    private void showGallery() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(intent, "Select Picture"), PICK_IMAGE_REQUEST);
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        // On selecting a spinner item
        String item = parent.getItemAtPosition(position).toString();
        //CategoryItemPosition = position;
        // Showing selected spinner item
        //Toast.makeText(parent.getContext(), "Selected: " + item, Toast.LENGTH_LONG).show();
        }

    public void onNothingSelected(AdapterView<?> arg0) { }

    /*
    getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    getSupportActionBar().setTitle("Add new Adoption");
     */

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_add_category, menu);
        //this.invalidateOptionsMenu();
        if(CategoryID != null && ProductID != null){
            menu.findItem(R.id.save_category).setVisible(false);
        }
        return true;
    }


    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == android.R.id.home){
            onBackPressed();
            // overridePendingTransition(R.anim.slide_from_left, R.anim.slide_to_right);
            return true;
        } else if (id == R.id.save_category) {

            boolean ExpiryDateTime1 = false, EditTextNotEmpty = true;
            if(expiryDate.equals("Expiry Date") ){
                ExpiryDateTime1 = false;
                ExpiryDate.setBackground(getResources().getDrawable(R.drawable.bt_shape_red));
            }else{
                ExpiryDateTime1 = true;
                // ExpiryDate.setBackground(getResources().getDrawable(R.drawable.bt_shape_green));
            }

            /*
            if(expiryTime.equals("Expiry Time") ){
                ExpiryDateTime2 = false;
                ExpiryTime.setBackground(getResources().getDrawable(R.drawable.bt_shape_red));
            }else{
                ExpiryDateTime2 = true;
             //  ExpiryTime.setBackground(getResources().getDrawable(R.drawable.bt_shape_green));
            }
            */

            boolean EditTextData[] = new boolean[idArrayEditText.length];
            for (int i = 0; i < idArrayEditText.length; i++) {
                if(TextUtils.isEmpty(EditTEXT[i].getText().toString())){
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
                        EditTEXT[i].setBackground(getResources().getDrawable(R.drawable.bt_shape_red));
                    }
                    EditTextNotEmpty = false;
                    EditTextData[i] = false;
                }else{
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
                        EditTEXT[i].setBackground(getResources().getDrawable(R.drawable.bt_shape_green));
                    }
                    EditTextData[i] = true;
                }
            }
            if(ExpiryDateTime1 && EditTextNotEmpty)
                uploadFile();

            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_PICTURE_CAPTURE && resultCode == RESULT_OK) {
            File imgFile = new  File(pictureFilePath);
            filePath = Uri.fromFile(imgFile);
            if(imgFile.exists()){
                imageProduct.setImageURI(filePath);
            }
            addImageProduct.setBackground(getResources().getDrawable(R.drawable.bt_shape_green));
        }else if(requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK){
            try {
                filePath = data.getData();
                Bitmap bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), filePath);
                imageProduct.setImageBitmap(bitmap);
                addImageProduct.setBackground(getResources().getDrawable(R.drawable.bt_shape_green));
            } catch (IOException e) { msg("ERROR (get image from sd): " + e); }
        }else if(requestCode == REQUEST_BARCODE_SCANNER ){
            EditTEXT[8].setText(data.getStringExtra("barcode"));
        }

        if (filePath != null && (CategoryName != null && ProductID != null && CategoryID != null)) {
            ImageName = "Product" + System.currentTimeMillis() + "." + getFileExtension(filePath);
            //getting the storage reference
            storageReference.child(ImageName).putFile(filePath).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                @Override
                public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                    Toast.makeText(getApplicationContext(), "new Image Uploaded Successfully", Toast.LENGTH_LONG).show();
                    mDatabase.child(CategoryID).child("Products").child(ProductID).child("imagePath").setValue(taskSnapshot.getDownloadUrl().toString());
                    mDatabase.child(CategoryID).child("Products").child(ProductID).child("imageName").setValue(ImageName);

                }
            }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception exception) {
                    Toast.makeText(getApplicationContext(), exception.getMessage(), Toast.LENGTH_LONG).show();
                }
            });
        }

        DialogSelectImage.setVisibility(View.GONE);
    }

    public String getFileExtension(Uri uri) {
        ContentResolver cR = getContentResolver();
        MimeTypeMap mime = MimeTypeMap.getSingleton();
        return mime.getExtensionFromMimeType(cR.getType(uri));
    }

    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
    private void uploadFile() {
        // checking if file is available
        if (filePath != null) {
            //displaying progress dialog while image is uploading
            final ProgressDialog progressDialog = new ProgressDialog(this);
            progressDialog.setTitle("Uploading ...");
            progressDialog.show();
            //ImageName = "Categories" + System.currentTimeMillis() + "." + getFileExtension(filePath);
            String SuffixFileExtension = "";
            if(getFileExtension(filePath) != null){
                SuffixFileExtension =  getFileExtension(filePath);
            }else{
                SuffixFileExtension = "jpg";
            }
            ImageName = "Product" + System.currentTimeMillis() + "." + SuffixFileExtension;
            //getting the storage reference
            final StorageReference sRef = storageReference.child(ImageName);
            //adding the file to reference
            sRef.putFile(filePath).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                            // dismissing the progress dialog
                            // displaying success toast
                            // Toast.makeText(getApplicationContext(), "File Uploaded ", Toast.LENGTH_LONG).show();

                                Date dNow = new Date();
                                SimpleDateFormat format = new SimpleDateFormat("dd-MM-yyyy HH:mm");
                                String current_datetime = format.format(dNow);
                                //adding an upload to firebase database
                                String uploadId = mDatabase.push().getKey();
                                //creating the upload Category object to store uploaded image details
                                final ListProducts listProducts = new ListProducts();//Upload(editTextName.getText().toString().trim(), taskSnapshot.getDownloadUrl().toString());
                                listProducts.productID = uploadId;
                                listProducts.adminID = StaticConfig.UID;
                                listProducts.imageName = ImageName;
                                listProducts.categoryName = CategoryName;
                                listProducts.categoryID = CategoryID;
                                listProducts.imagePath = taskSnapshot.getDownloadUrl().toString();
                                listProducts.postDate = current_datetime;
                                listProducts.expiryDate = expiryDate;
                                listProducts.expiryTime = expiryTime;
                                listProducts.unities = Integer.parseInt(EditTEXT[7].getText().toString().trim());
                                listProducts.availablePackets = Integer.parseInt(EditTEXT[8].getText().toString().trim());
                                listProducts.buyPrice = Double.parseDouble(EditTEXT[1].getText().toString().trim());
                                listProducts.sellPriceStock = Double.parseDouble(EditTEXT[2].getText().toString().trim());
                                listProducts.sellPriceStore = Double.parseDouble(EditTEXT[3].getText().toString().trim());
                                listProducts.sellPriceDeliverer = Double.parseDouble(EditTEXT[4].getText().toString().trim());
                                listProducts.sellPriceCustomer = Double.parseDouble(EditTEXT[5].getText().toString().trim());
                                listProducts.discountPrice = Double.parseDouble(EditTEXT[6].getText().toString().trim());
                                listProducts.barCode = EditTEXT[11].getText().toString().trim();
                                listProducts.description = EditTEXT[10].getText().toString().trim();
                                listProducts.productName = EditTEXT[0].getText().toString().trim();
                                listProducts.location = EditTEXT[10].getText().toString().trim();

                            try{

                            mDatabase.child(CategoryID).child("Products").child(uploadId).setValue(listProducts).addOnCompleteListener(new OnCompleteListener<Void>() {
                                    @Override
                                    public void onComplete(@NonNull Task<Void> task) {
                                        if (task.isSuccessful()) {
                                            msg("Product " + listProducts.productName + " Added Successfully");
                                            finish();
                                        } else {
                                            msg("Product " + listProducts.productName + " not added \nTry Again !!!");
                                        }
                                    }
                                });
                            }catch (Exception e){
                                msg("Error 1223: "+ e);
                            }

                            progressDialog.dismiss();
                        }
                    }).addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception exception) {
                            progressDialog.dismiss();
                            Toast.makeText(getApplicationContext(), exception.getMessage(), Toast.LENGTH_LONG).show();
                        }
                    })
                    .addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onProgress(UploadTask.TaskSnapshot taskSnapshot) {
                            //displaying the upload progress
                            double progress = (100.0 * taskSnapshot.getBytesTransferred()) / taskSnapshot.getTotalByteCount();
                            progressDialog.setMessage("Uploaded " + ((int) progress) + "%...");
                        }
                    });
        } else {
            //display an error if no file is selected
            msg("Please select Image !");
            addImageProduct.setBackground(getResources().getDrawable(R.drawable.bt_shape_red));
        }
    }
}