package tech.siham.stock_management.Model;

public class SharedCode {

    public String invitorID;
    public String code;
    public String url;
    public SharedCode(){}
}
