package tech.siham.stock_management.Model;

public class Currency {
    public Currency(){};

    public String currencyName;
    public String currencySymbol;
    public String currencyCode;
}
