package tech.siham.stock_management.utils;

import android.content.Context;
import android.graphics.Bitmap;
import android.net.Uri;
import android.provider.MediaStore;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;

public class Utils {
  public static void myToast(Context mContext, String msg) {
    Toast.makeText(mContext, msg, Toast.LENGTH_LONG).show();
  }

  public static Uri getImageUri(Context inContext, Bitmap inImage) {
    ByteArrayOutputStream bytes = new ByteArrayOutputStream();
    //   inImage.compress(Bitmap.CompressFormat.JPEG,100, bytes);
    String path = MediaStore.Images.Media.insertImage(inContext.getContentResolver(), inImage, "Title", null);
    return Uri.parse(path);
  }
  static String getJsonFromAssets(Context context, String fileName) {
    String jsonString;
    try {
      InputStream is = context.getAssets().open(fileName);

      int size = is.available();
      byte[] buffer = new byte[size];
      is.read(buffer);
      is.close();

      jsonString = new String(buffer, "UTF-8");
    } catch (IOException e) {
      e.printStackTrace();
      return null;
    }

    return jsonString;
  }
}
