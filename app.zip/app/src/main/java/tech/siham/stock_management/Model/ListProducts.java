package tech.siham.stock_management.Model;
import com.google.firebase.database.IgnoreExtraProperties;
@IgnoreExtraProperties
public class ListProducts {

    public String categoryName;
    public String productName;
    public String categoryID;
    public String productID;
    public String adminID;
    public String imagePath;
    public String imageName;
    public String barCode;

    // if it needed and generate barcode
    public int imageNumber;
    public String barcodeImagePath;
    public String barcodeImageName;

    // status of product [quantity shortage | ... ]
    public String status;
    public int shortageQuantity;
    // price and quantity
    public int unities;  // available unities at one packet /> number of bottles/packs/cases
    public String type; // kg lb number of packet, L or Kg in unity (bottles/packs/cases)

    public int boughtPackets;  // bought packets from stock
    public int availablePackets;  // available packets at stock
    public int soldPackets; // sold packets from stock

    public double buyPrice;
    public double sellPrice;
    public double sellPriceStock;
    public double sellPriceStore;
    public double sellPriceDeliverer;
    public double sellPriceCustomer;
    public double discountPrice;

    public String description;
    public String postDate;
    public String location;

    public String expiryDate;
    public String expiryTime;

    public ListProducts(){}

}
