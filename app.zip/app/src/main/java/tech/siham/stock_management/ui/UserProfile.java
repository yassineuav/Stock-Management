package tech.siham.stock_management.ui;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import tech.siham.stock_management.Data.SharedPreferenceHelper;
import tech.siham.stock_management.Data.StaticConfig;
import tech.siham.stock_management.Model.Configuration;
import tech.siham.stock_management.Model.User;
import tech.siham.stock_management.R;
import tech.siham.stock_management.utils.ImageUtils;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.yarolegovich.lovelydialog.LovelyInfoDialog;
import com.yarolegovich.lovelydialog.LovelyProgressDialog;

import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;


public class UserProfile extends AppCompatActivity {
  TextView tvUserName;
  ImageView avatar;

  private List<Configuration> listConfig = new ArrayList<>();
  private RecyclerView recyclerView;
  private UserInfoAdapter infoAdapter;

  private static final String USERNAME_LABEL = "User Full Name";
  private static final String EMAIL_LABEL = "Email";
  private static final String PHONE_LABEL = "Phone Number";
  private static final String STORE_NAME_LABEL = "Store Name";
  private static final String STORE_ADDRESS_LABEL = "Store Address";
  private static final String COORDINATES_LABEL = "Coordinates";
  private static final String SIGNOUT_LABEL = "Sign out";
  private static final String RESETPASS_LABEL = "Change Password";

  private static final int PICK_IMAGE = 1994;
  private LovelyProgressDialog waitingDialog;

  private DatabaseReference userDB;
  private FirebaseAuth mAuth;
  private User myAccount;



  private ValueEventListener userListener = new ValueEventListener() {
    @Override
    public void onDataChange(DataSnapshot dataSnapshot) {
      listConfig.clear();
      myAccount = dataSnapshot.getValue(User.class);

      setupArrayListInfo(myAccount);
      if(infoAdapter != null){
        infoAdapter.notifyDataSetChanged();
      }

      if(tvUserName != null){
        tvUserName.setText(myAccount.fullName);
      }

      setImageAvatar(myAccount.avatar);
      SharedPreferenceHelper preferenceHelper = SharedPreferenceHelper.getInstance(UserProfile.this);
      preferenceHelper.saveUserInfo(myAccount);
    }

    @Override
    public void onCancelled(DatabaseError databaseError) {
      Log.e(UserProfile.class.getName(), "loadPost:onCancelled", databaseError.toException());
    }
  };

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.user_profile_info);
    //getActionBar().setTitle("Categories");
    getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    getSupportActionBar().setTitle("My Profile");  // provide compatibility to all the versions

    userDB = FirebaseDatabase.getInstance().getReference().child("Stock").child(StaticConfig.UID);
    userDB.addListenerForSingleValueEvent(userListener);
    mAuth = FirebaseAuth.getInstance();

    avatar = (ImageView) findViewById(R.id.img_avatar);
    avatar.setOnClickListener(onAvatarClick);
    tvUserName = (TextView) findViewById(R.id.tv_username);

    SharedPreferenceHelper prefHelper = SharedPreferenceHelper.getInstance(UserProfile.this);
    myAccount = prefHelper.getUserInfo();
    setupArrayListInfo(myAccount);
    setImageAvatar(myAccount.avatar);
    tvUserName.setText(myAccount.fullName);

    recyclerView = (RecyclerView) findViewById(R.id.info_recycler_view);
    infoAdapter = new UserInfoAdapter(listConfig);
    RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(this);
    recyclerView.setLayoutManager(layoutManager);
    recyclerView.setItemAnimator(new DefaultItemAnimator());
    recyclerView.setAdapter(infoAdapter);

    waitingDialog = new LovelyProgressDialog(UserProfile.this);

  }

  private View.OnClickListener onAvatarClick = new View.OnClickListener() {
    @Override
    public void onClick(View view) {
      new AlertDialog.Builder(UserProfile.this)
              .setTitle("Avatar")
              .setMessage("Are you sure want to change avatar profile?")
              .setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                  Intent intent = new Intent();
                  intent.setType("image/*");
                  intent.setAction(Intent.ACTION_PICK);
                  startActivityForResult(Intent.createChooser(intent, "Select Picture"), PICK_IMAGE);
                  dialogInterface.dismiss();
                }
              })
              .setNegativeButton(android.R.string.cancel, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                  dialogInterface.dismiss();
                }
              }).show();
    }
  };


  /*
   getSupportActionBar().setDisplayHomeAsUpEnabled(true);
   getSupportActionBar().setTitle("Categories");  // provide compatibility to all the versions
   */

  @Override
  public boolean onOptionsItemSelected(MenuItem item) {
    int id = item.getItemId();
    if (id == android.R.id.home) {
      onBackPressed();
      // overridePendingTransition(R.anim.slide_from_left, R.anim.slide_to_right);
      return true;
    }
    return super.onOptionsItemSelected(item);
  }

  @Override
  public void onActivityResult(int requestCode, int resultCode, Intent data) {
    super.onActivityResult(requestCode, resultCode, data);
    if (requestCode == PICK_IMAGE && resultCode == Activity.RESULT_OK) {
      if (data == null) {
        Toast.makeText(UserProfile.this, "error : result code null", Toast.LENGTH_LONG).show();
        return;
      }
      try {
        InputStream inputStream = UserProfile.this.getContentResolver().openInputStream(data.getData());

        Bitmap imgBitmap = BitmapFactory.decodeStream(inputStream);
        imgBitmap = ImageUtils.cropToSquare(imgBitmap);
        InputStream is = ImageUtils.convertBitmapToInputStream(imgBitmap);
        final Bitmap liteImage = ImageUtils.makeImageLite(is,
                imgBitmap.getWidth(), imgBitmap.getHeight(),
                ImageUtils.AVATAR_WIDTH, ImageUtils.AVATAR_HEIGHT);

        String imageBase64 = ImageUtils.encodeBase64(liteImage);
        myAccount.avatar = imageBase64;

        waitingDialog.setCancelable(false)
                .setTitle("Avatar updating....")
                .setTopColorRes(R.color.colorPrimary)
                .show();

        userDB.child("avatar").setValue(imageBase64)
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                  @Override
                  public void onComplete(@NonNull Task<Void> task) {
                    if(task.isSuccessful()){

                      waitingDialog.dismiss();
                      SharedPreferenceHelper preferenceHelper = SharedPreferenceHelper.getInstance(UserProfile.this);
                      preferenceHelper.saveUserInfo(myAccount);
                      avatar.setImageDrawable(ImageUtils.roundedImage(UserProfile.this, liteImage));

                      new LovelyInfoDialog(UserProfile.this)
                              .setTopColorRes(R.color.colorPrimary)
                              .setTitle("Success")
                              .setMessage("Update avatar successfully!")
                              .show();
                    }
                  }
                })
                .addOnFailureListener(new OnFailureListener() {
                  @Override
                  public void onFailure(@NonNull Exception e) {
                    waitingDialog.dismiss();
                    Log.d("Update Avatar", "failed");
                    new LovelyInfoDialog(UserProfile.this)
                            .setTopColorRes(R.color.colorAccent)
                            .setTitle("False")
                            .setMessage("False to update avatar")
                            .show();
                  }
                });
      } catch (FileNotFoundException e) {
        e.printStackTrace();
      }
    }
  }

  /*
   * @param myAccount
   */

  public void setupArrayListInfo(User myAccount){
    listConfig.clear();
    Configuration userNameConfig = new Configuration(USERNAME_LABEL, myAccount.fullName, R.mipmap.ic_account_box);
    listConfig.add(userNameConfig);

    Configuration emailConfig = new Configuration(EMAIL_LABEL, myAccount.email, R.mipmap.ic_email);
    listConfig.add(emailConfig);

    Configuration numberPhone = new Configuration(PHONE_LABEL, myAccount.phoneNumber, R.mipmap.ic_mobile);
    listConfig.add(numberPhone);

    Configuration StoreNameConfig = new Configuration(PHONE_LABEL, myAccount.storeName, R.mipmap.ic_mobile);
    listConfig.add(StoreNameConfig);

    Configuration resetPass = new Configuration(RESETPASS_LABEL, "", R.mipmap.ic_restore);
    listConfig.add(resetPass);

    Configuration signout = new Configuration(SIGNOUT_LABEL, "", R.mipmap.ic_power_settings);
    listConfig.add(signout);
  }

  private void setImageAvatar(String imgBase64){
    try {
      Resources res = getResources();
      Bitmap src;
      if (imgBase64.equals("default")) {
        src = BitmapFactory.decodeResource(res, R.drawable.default_avata);
      } else {
        byte[] decodedString = Base64.decode(imgBase64, Base64.DEFAULT);
        src = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
      }

      avatar.setImageDrawable(ImageUtils.roundedImage(UserProfile.this, src));
    }catch (Exception e){
    }
  }

  public class UserInfoAdapter extends RecyclerView.Adapter<UserInfoAdapter.ViewHolder>{
    private List<Configuration> profileConfig;

    public UserInfoAdapter(List<Configuration> profileConfig){
      this.profileConfig = profileConfig;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
      View itemView = LayoutInflater.from(parent.getContext())
              .inflate(R.layout.list_info_item_layout, parent, false);
      return new ViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
      final Configuration config = profileConfig.get(position);
      holder.label.setText(config.getLabel());
      holder.value.setText(config.getValue());
      holder.icon.setImageResource(config.getIcon());
      ((RelativeLayout)holder.label.getParent()).setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View view) {
          if(config.getLabel().equals(SIGNOUT_LABEL)){
            FirebaseAuth.getInstance().signOut();
            finish();
          }

          View vewInflater = LayoutInflater.from(UserProfile.this).inflate(R.layout.dialog_edit_username, null, false);
          final EditText input = (EditText) vewInflater.findViewById(R.id.edit_username);

          if(config.getLabel().equals(USERNAME_LABEL)){
            input.setText(myAccount.fullName);

            new AlertDialog.Builder(UserProfile.this)
                    .setTitle("Edit username")
                    .setView(vewInflater)
                    .setPositiveButton("Save", new DialogInterface.OnClickListener() {
                      @Override
                      public void onClick(DialogInterface dialogInterface, int i) {
                        String newName = input.getText().toString();
                        if(!myAccount.fullName.equals(newName)){
                          changeUserName(newName);
                        }
                        dialogInterface.dismiss();
                      }
                    })
                    .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                      @Override
                      public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.dismiss();
                      }
                    }).show();

          }else if(config.getLabel().equals(PHONE_LABEL)){
            input.setText(myAccount.phoneNumber);

            new AlertDialog.Builder(UserProfile.this)
                    .setTitle("Edit phone number")
                    .setView(vewInflater)
                    .setPositiveButton("Save", new DialogInterface.OnClickListener() {
                      @Override
                      public void onClick(DialogInterface dialogInterface, int i) {
                        String newPhone = input.getText().toString();
                        if(!myAccount.phoneNumber.equals(newPhone)){
                          changePhoneNumber(newPhone);
                        }
                        dialogInterface.dismiss();
                      }
                    })
                    .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                      @Override
                      public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.dismiss();
                      }
                    }).show();
          }

          if(config.getLabel().equals(RESETPASS_LABEL)){
            new AlertDialog.Builder(UserProfile.this)
                    .setTitle("Password")
                    .setMessage("Are you sure want to reset password?")
                    .setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                      @Override
                      public void onClick(DialogInterface dialogInterface, int i) {
                        resetPassword(myAccount.email);
                        dialogInterface.dismiss();
                      }
                    })
                    .setNegativeButton(android.R.string.cancel, new DialogInterface.OnClickListener() {
                      @Override
                      public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.dismiss();
                      }
                    }).show();
          }
        }
      });
    }

    private void changeUserName(String newName){
      userDB.child("fullName").setValue(newName);
      myAccount.fullName = newName;
      SharedPreferenceHelper prefHelper = SharedPreferenceHelper.getInstance(UserProfile.this);
      prefHelper.saveUserInfo(myAccount);
      tvUserName.setText(newName);
      setupArrayListInfo(myAccount);
    }
    private void changePhoneNumber(String newPhone){
      userDB.child("phoneNumber").setValue(newPhone);
      myAccount.phoneNumber = newPhone;
      SharedPreferenceHelper prefHelper = SharedPreferenceHelper.getInstance(UserProfile.this);
      prefHelper.saveUserInfo(myAccount);
      setupArrayListInfo(myAccount);
    }

    void resetPassword(final String email) {
      mAuth.sendPasswordResetEmail(email)
              .addOnCompleteListener(new OnCompleteListener<Void>() {
                @Override
                public void onComplete(@NonNull Task<Void> task) {
                  new LovelyInfoDialog(UserProfile.this) {
                    @Override
                    public LovelyInfoDialog setConfirmButtonText(String text) {
                      findView(com.yarolegovich.lovelydialog.R.id.ld_btn_confirm).setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                          dismiss();
                        }
                      });
                      return super.setConfirmButtonText(text);
                    }
                  }
                          .setTopColorRes(R.color.colorPrimary)
                          .setIcon(R.drawable.ic_pass_reset)
                          .setTitle("Password Recovery")
                          .setMessage("Sent email to " + email)
                          .setConfirmButtonText("Ok")
                          .show();
                }
              })
              .addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {
                  new LovelyInfoDialog(UserProfile.this) {
                    @Override
                    public LovelyInfoDialog setConfirmButtonText(String text) {
                      findView(com.yarolegovich.lovelydialog.R.id.ld_btn_confirm).setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                          dismiss();
                        }
                      });
                      return super.setConfirmButtonText(text);
                    }
                  }
                          .setTopColorRes(R.color.colorAccent)
                          .setIcon(R.drawable.ic_pass_reset)
                          .setTitle("False")
                          .setMessage("False to sent email to " + email)
                          .setConfirmButtonText("Ok")
                          .show();
                }
              });
    }

    @Override
    public int getItemCount() {
      return profileConfig.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder {
      // each data item is just a string in this case
      public TextView label, value;
      public ImageView icon;
      public ViewHolder(View view) {
        super(view);
        label = (TextView)view.findViewById(R.id.tv_title);
        value = (TextView)view.findViewById(R.id.tv_detail);
        icon = (ImageView)view.findViewById(R.id.img_icon);
      }
    }
  }
}
