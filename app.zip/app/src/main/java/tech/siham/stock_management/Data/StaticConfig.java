package tech.siham.stock_management.Data;

import java.util.ArrayList;
import java.util.List;

import tech.siham.stock_management.Model.MyBasket;

public class StaticConfig {

  public static int REQUEST_CODE_REGISTER = 2000;
  public static String STR_EXTRA_ACTION = "action";
  public static String STR_EXTRA_USERNAME = "username";
  public static String STR_EXTRA_PASSWORD = "password";
  public static String STR_DEFAULT_BASE64 = "default";

  public static String intentMode = "";

  public static String UID = "";
  public static String AdminID = "";
  public static String UserName = "";
  public static String StoreName = "";
  public static String StoreAddress = "";
  public static String DayToDelivery = "";
  public static int Tariff ;
  public static double StartPrice = 200;

  public static List<MyBasket> myBasket = new ArrayList<>();


}
