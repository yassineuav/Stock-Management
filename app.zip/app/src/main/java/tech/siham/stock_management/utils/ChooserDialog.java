package tech.siham.stock_management.utils;

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;

import tech.siham.stock_management.R;


public class ChooserDialog {

  public static Button buttonCamera, buttonGallery;
  final Dialog dialog;
  Activity activity;

  public int Request_gallery = 1010;
  public int Request_camera = 1111;

  public ChooserDialog(final Activity activity) {
    this.activity = activity;
    dialog = new Dialog(activity);
    dialog.setContentView(R.layout.chooser);
    dialog.setTitle("Select");

    buttonCamera = (Button) dialog.findViewById(R.id.buttonCamera);
    buttonGallery = (Button) dialog.findViewById(R.id.buttonGallery);
    // if button is clicked, close the custom dialog


    buttonCamera.setOnClickListener(new View.OnClickListener() {
      @Override
      public void onClick(View view) {
        takePicture();
        dialog.dismiss();
      }
    });

    buttonGallery.setOnClickListener(new View.OnClickListener() {
      @Override
      public void onClick(View view) {
        choosePicfrom();
        dialog.dismiss();
      }
    });

  }

  public void showDialog() {
    dialog.show();
  }

  public void takePicture() {
    Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
    activity.startActivityForResult(cameraIntent, Request_camera);
  }

  private void choosePicfrom() {
    // Creating intent.
    Intent intent = new Intent();
    // Setting intent type as image to select image from phone storage.
    intent.setType("image/*");
    intent.setAction(Intent.ACTION_GET_CONTENT);
    activity.startActivityForResult(Intent.createChooser(intent, "Please Select Image"), Request_gallery);
  }

}
