package tech.siham.stock_management.ui;

import android.Manifest;
import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.location.Location;
import android.location.LocationManager;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.InputFilter;
import android.text.InputType;
import android.util.Base64;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.LocationListener;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.yarolegovich.lovelydialog.LovelyProgressDialog;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import tech.siham.stock_management.Data.SharedPreferenceHelper;
import tech.siham.stock_management.Data.StaticConfig;
import tech.siham.stock_management.Model.MySupplier;
import tech.siham.stock_management.Model.User;
import tech.siham.stock_management.R;
import tech.siham.stock_management.utils.CustomInfoWindowGoogleMap;
import tech.siham.stock_management.utils.ImageUtils;

import static android.Manifest.permission.ACCESS_COARSE_LOCATION;
import static android.Manifest.permission.ACCESS_FINE_LOCATION;

public class orderProductsActivity extends AppCompatActivity implements
        LocationListener,
        GoogleApiClient.ConnectionCallbacks,
        GoogleApiClient.OnConnectionFailedListener ,
        OnMapReadyCallback {

    public static User mySupplierData  = new User();

    FloatingActionButton addStockFab;

    Spinner StockType, AreaType;
    TextView TitleTV;
    ImageView goBack;

    String typeOfSelect = "mySupplier"; // Stock or mySupplier
    String userType = "Stock"; // Stock | Store | Deliver
    String userSortBy = "mySupplier"; // Stock or mySupplier

    int positionUserType = 0; // number
    int positionUserSortBy = 0; // number
    String searchUserStockName = "";

    EditText searchText;

    // list view
    RecyclerView recyclerview;
    List<MySupplier> mySuppliers; // = new ArrayList<>();
    List<User> listUsers; // = new ArrayList<>();
    private RecyclerviewAdapter recycler;
    private DatabaseReference mDatabase;

    ValueEventListener VELfetchSuppliers = null;
    ValueEventListener checkIfSupplierExist = null;

    User myUserData = new User();
    // implement map

    LocationRequest mLocationRequest;
    GoogleApiClient mGoogleApiClient;

    GoogleMap mGoogleMap;
    SupportMapFragment mapFrag;

    ProgressDialog progressDialog;
    FloatingActionButton FAB;

    public double x = 0;
    public double y = 0;
    String myAddress = "";
    LocationManager locationManager;

    private final static int ALL_PERMISSIONS_RESULT = 101;
    private static final long INTERVAL = 1000 * 2;
    private static final long FASTEST_INTERVAL = 1000 * 1;

    private ArrayList<String> permissionsToRequest;
    private ArrayList<String> permissionsRejected = new ArrayList<>();
    private ArrayList<String> permissions = new ArrayList<>();

    void createLocationRequest() {
        mLocationRequest = new LocationRequest();
        mLocationRequest.setInterval(INTERVAL);
        mLocationRequest.setFastestInterval(FASTEST_INTERVAL);
        mLocationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_products);

        permissions.add(ACCESS_FINE_LOCATION);
        permissions.add(ACCESS_COARSE_LOCATION);

        permissionsToRequest = findUnAskedPermissions(permissions);
        //get the permissions we have asked for before but are not granted..
        //we will store this in a global list to access later.

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (permissionsToRequest.size() > 0)
                requestPermissions(permissionsToRequest.toArray(new String[permissionsToRequest.size()]), ALL_PERMISSIONS_RESULT);
        }

        listUsers = new ArrayList<>();
        mySuppliers = new ArrayList<>();
        myUserData = SharedPreferenceHelper.getInstance(this).getUserInfo();
        // list view
        recyclerview = (RecyclerView) findViewById(R.id.recycleListUsers);
        mDatabase = FirebaseDatabase.getInstance().getReference();
        recyclerview.setItemAnimator(new DefaultItemAnimator());
        recyclerview.setLayoutManager(new GridLayoutManager(this, 1));

        searchText = (EditText) findViewById(R.id.search_text);
        addStockFab = (FloatingActionButton) findViewById(R.id.add_stock);
        StockType = (Spinner) findViewById(R.id.stockType);
        AreaType = (Spinner) findViewById(R.id.areaType);
        TitleTV = (TextView) findViewById(R.id.title);
        goBack = (ImageView) findViewById(R.id.goBack);
        TitleTV.setText("My Suppliers");

        // Spinner Drop down elements
        final List<String> userTypeList = new ArrayList<String>();
        userTypeList.add("All");
        userTypeList.add("Stock");
        userTypeList.add("Store");
        userTypeList.add("Deliver");

        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(orderProductsActivity.this, android.R.layout.simple_spinner_item, userTypeList);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        StockType.setAdapter(dataAdapter);

        final List<String> rangeTypeList = new ArrayList<String>();
        rangeTypeList.add("Range");
        rangeTypeList.add("Name");
        rangeTypeList.add("Zip Code");
        rangeTypeList.add("City"); // one my state or country

        ArrayAdapter<String> dataAdapter2 = new ArrayAdapter<String>(orderProductsActivity.this, android.R.layout.simple_spinner_dropdown_item, rangeTypeList);
        dataAdapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        AreaType.setAdapter(dataAdapter2);

        StockType.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                positionUserType = position;
                userType = userTypeList.get(position);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) { }
        });

        AreaType.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                positionUserSortBy = position;
                userSortBy = rangeTypeList.get(position);
                checkText(position);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) { }
        });

        ((ImageView) findViewById(R.id.btnSearch)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // check type of view [map | list]
                // check type of user
                // check address or range
                // check search in my suppliers or new suppliers
                // go to search
                checkText(positionUserSortBy);
                if (typeOfSelect == "Stock") {
                    fetchStockData();
                } else {
                    fetchMySuppliersData();
                }
            }
        });

        goBack.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("RestrictedApi")
            @Override
            public void onClick(View v) {
                if (typeOfSelect == "Stock") {
                    typeOfSelect = "mySupplier";
                    TitleTV.setText("My Suppliers");
                    addStockFab.setVisibility(View.VISIBLE);
                    fetchMySuppliersData();
                } else if (typeOfSelect == "mySupplier") {
                    finish();
                }
            }
        });

        addStockFab.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("RestrictedApi")
            @Override
            public void onClick(View v) {
                // hide fab Btn
                // change title to add new supplier
                // show list of suppliers close to me by distance or zip code or name
                // send intent to list or map
                typeOfSelect = "Stock";
                TitleTV.setText("Add New Supplier");
                addStockFab.setVisibility(View.GONE);
                fetchStockData();
            }
        });



        // set map
        try {
            mapFrag = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);
            mapFrag.getMapAsync(this);

            FAB = (FloatingActionButton) findViewById(R.id.my_location);
            //  Check gps
            // SetUsersOnMap();

            locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
            if (!locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                // showGPSDisabledAlertToUser();
                // showSettingsAlert();
                //FAB.setVisibility(View.GONE);
            } else {
                if (x == 0 && y == 0) {
                    progressDialog = new ProgressDialog(this);
                    progressDialog.setIndeterminate(true);
                    progressDialog.setCancelable(false);
                    progressDialog.setMessage("Getting Location...");
                    progressDialog.show();
                    GetLocation();
                } else {
                    getmylocation();
                }
            }

            FAB.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    // FAB.setEnabled(false);
                    // GetLocation();
                    LatLng latLng = new LatLng(x, y);
                    MarkerOptions markerOptions = new MarkerOptions();
                    markerOptions.position(latLng)
                            .snippet(myAddress)
                            .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_BLUE));
                    CameraUpdate cameraUpdate = CameraUpdateFactory.newLatLngZoom(latLng, 12);
                    mGoogleMap.animateCamera(cameraUpdate);
                    mGoogleMap.addMarker(markerOptions);

                }
            });
        } catch (Exception e) {
            msg("error to set map: " + e);
        }

        // check if coordination existed then
        fetchMySuppliersData();

    }
    /*
    private void loadFragment(Fragment fragment) {
        android.support.v4.app.FragmentManager fm = getSupportFragmentManager();
        android.support.v4.app.FragmentTransaction fragmentTransaction = fm.beginTransaction();
        fragmentTransaction.replace(R.id.frameLayout, fragment);
        fragmentTransaction.commit();
    } */

    private void checkText(int position){
        // if range view dialog and hide search text and view details text ('50Km') for range
        searchUserStockName = searchText.getText().toString().trim();
        switch (position){
            case 0 :
                searchUserStockName = "50"; // radius
                searchText.setText("50");
                searchText.setInputType(InputType.TYPE_CLASS_NUMBER);
                searchText.setFilters(new InputFilter[] {new InputFilter.LengthFilter(5)});
                if(searchUserStockName.isEmpty()){
                    searchText.setError("Please!\nEnter your range circle (e.i: 50Km)");
                    return;
                }
                break;
            case 1:
                searchText.setInputType(InputType.TYPE_CLASS_TEXT);
                searchText.setFilters(new InputFilter[] {new InputFilter.LengthFilter(40)});
                if(searchUserStockName.isEmpty()){
                    searchText.setError("Please!\nEnter "+userType+" name");
                    return;
                }
                break;
            case 2:
                searchText.setText(myUserData.myAddress.zipCode);
                searchText.setInputType(InputType.TYPE_CLASS_NUMBER);
                searchText.setFilters(new InputFilter[] {new InputFilter.LengthFilter(5)});
                if(searchUserStockName.isEmpty()){
                    searchText.setError("Please!\nEnter Zip Code");
                    return;
                }
                break;
            case 3:
                searchText.setInputType(InputType.TYPE_CLASS_TEXT);
                searchText.setFilters(new InputFilter[] {new InputFilter.LengthFilter(40)});
                if(searchUserStockName.isEmpty()){
                    searchText.setError("Please!\nEnter a City name");
                    return;
                }
                break;
        }
    }
    // List View
    public void fetchStockData() {
        mDatabase.child("Stock").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                listUsers.clear();
                mySuppliers.clear();
                if (snapshot.exists()) {
                    // iterating through all the values in database
                    for (DataSnapshot postSnapshot : snapshot.getChildren()) {
                        User upload = postSnapshot.getValue(User.class);
                        try {
                            searchUserStockName = searchText.getText().toString().trim();
                            if (!upload.adminID.equals(StaticConfig.UID) &&
                                    (upload.orderFrom.equals(userType) || userType.equals("All"))){
                                switch (positionUserSortBy) {
                                    case 0:
                                        // distance <= x
                                        float distance = getDistance(upload.coordinates.latitude, upload.coordinates.longitude );
                                        if(distance <= Integer.parseInt(searchUserStockName)){
                                            upload.distance = distance;
                                            listUsers.add(upload); }
                                        break;
                                    case 1:
                                        if (upload.fullName == searchUserStockName ||
                                                upload.shopName == searchUserStockName ||
                                                upload.storeName == searchUserStockName) {
                                            listUsers.add(upload); }
                                        break;
                                    case 2:
                                        if (searchUserStockName.equals(upload.myAddress.zipCode)) {
                                            listUsers.add(upload); }
                                        break;
                                    case 3:
                                        if (searchUserStockName.equalsIgnoreCase(upload.myAddress.city)) {
                                            listUsers.add(upload); }
                                        break;
                                }
                            }
                        } catch (Exception e){ msg("Error in fetch stocks: "+e);}
                    }

                    if(listUsers.isEmpty()){ msg("Item not Found!!\ntry an other"); }
                } else { msg("No Stock exist!!\n >> add new suppliers"); }
                recycler = new RecyclerviewAdapter(orderProductsActivity.this, listUsers);
                recyclerview.setAdapter(recycler);
                recycler.notifyDataSetChanged();
                SetUsersOnMap();
            }
            @Override
            public void onCancelled(DatabaseError databaseError) { }
        });
    }

    public void fetchMySuppliersData() {

        VELfetchSuppliers = new  ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                try {
                    mySuppliers.clear();
                    listUsers.clear();
                    if (snapshot.exists()) {
                        // iterating through all the values in database
                        for ( DataSnapshot postSnapshot : snapshot.getChildren()) {
                            final MySupplier upload = postSnapshot.getValue(MySupplier.class);
                            if (upload.myID.equals(StaticConfig.UID)) {
                                mDatabase.child("Stock").child(upload.supplierID).addValueEventListener(new ValueEventListener() {
                                    @Override
                                    public void onDataChange(DataSnapshot snapshot2) {
                                        if (snapshot2.exists()) {
                                            User data = snapshot2.getValue(User.class);
                                            float distance = getDistance(data.coordinates.latitude, data.coordinates.longitude );
                                            data.distance = distance;
                                            listUsers.add(data);
                                            mySuppliers.add(upload);
                                        } else {
                                            msg("Error to get a supplier");
                                        }
                                    }
                                    @Override
                                    public void onCancelled(DatabaseError databaseError) { }
                                });
                            }
                        }
                    } else { msg("you don't have any supplier \nNo Stocks exist");}
                    recycler = new RecyclerviewAdapter(orderProductsActivity.this, listUsers);
                    recyclerview.setAdapter(recycler);
                    recycler.notifyDataSetChanged();
                    SetUsersOnMap();
                } catch (Exception e) { msg("Error 234 :" + e); }
                mDatabase.removeEventListener(VELfetchSuppliers);
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                mDatabase.removeEventListener(VELfetchSuppliers);
            }
        };
        mDatabase.child("mySupplier").addListenerForSingleValueEvent(VELfetchSuppliers);
    }

    void msg(String txt){
        Toast.makeText(orderProductsActivity.this, txt, Toast.LENGTH_SHORT).show();
    }

    private float getDistance(double lat, double lon) {
        float[] distance = new float[2];
        Location.distanceBetween(lat, lon,
                myUserData.coordinates.latitude,
                myUserData.coordinates.longitude, distance);
        return distance[0] / 1000;
    }


    private class RecyclerviewAdapter extends RecyclerView.Adapter<RecyclerviewAdapter.MyHolder> {

        private Context context;
        List<User> listUsers;
        LovelyProgressDialog dialogWaitDeleting;

        public RecyclerviewAdapter(Context context, List<User> listUsers) {
            this.listUsers = listUsers;
            this.context = context;
            dialogWaitDeleting = new LovelyProgressDialog(context);
        }

        @Override
        public RecyclerviewAdapter.MyHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_users_details, parent, false);
            RecyclerviewAdapter.MyHolder myHolder = new RecyclerviewAdapter.MyHolder(view);
            return myHolder;
        }

        public void onBindViewHolder(final RecyclerviewAdapter.MyHolder holder, int position) {
            final User data = listUsers.get(position);
            final int p = position;


            // change distance
            String fromat = "Km";
            String distance  = new DecimalFormat("###.##").format(data.distance);

            try {
                if(data.format.equals("US")){
                    fromat = "mil";
                    double distance_convert = Float.parseFloat(distance) * 0.621371;
                    distance = new DecimalFormat("###.##").format(distance_convert);
                }
                // Html.fromHtml();
            }catch (Exception e){
                Toast.makeText(context, "error 306: "+e, Toast.LENGTH_LONG).show();}
            String userInfo = data.fullName+
                    "\n"+data.orderFrom+ " Name: "+data.storeName+
                    "\nDistance: "+ distance +" "+ fromat+
                    "\t\tType: "+ data.orderFrom ;
            holder.userInfo.setText(userInfo);
            if(data.availableForOrders == "off"){
                // holder.checkStatus.setVisibility(View.GONE);
            }

                if(typeOfSelect.equals("mySupplier")){
                    holder.checkStatus.setImageDrawable(getResources().getDrawable(R.drawable.ic_delete_supplier));
                } else {
                    holder.checkStatus.setImageDrawable(getResources().getDrawable(R.drawable.ic_add_supplier));
                }

                holder.checkStatus.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (typeOfSelect.equals("Stock")) {
                            final MySupplier mySupplier = new MySupplier();
                            mySupplier.myID = StaticConfig.UID;
                            mySupplier.id = mDatabase.push().getKey();
                            mySupplier.ordersDone = 0;
                            mySupplier.ordersPending = 0;
                            mySupplier.timestamp = (new Date()).getTime();
                            mySupplier.supplierID = data.adminID;

                            if (data.availableForOrders.equals("on")) {
                                mySupplier.status = "accept";
                            } else {
                                // show in notification
                                mySupplier.status = "pending";
                            }
                            // check if supplier already existed
                            checkIfSupplierExist = new ValueEventListener() {
                                @Override
                                public void onDataChange(DataSnapshot dataSnapshot) {
                                    boolean isExist = false;
                                    if (dataSnapshot.exists()) {
                                        for (DataSnapshot postSnapshot : dataSnapshot.getChildren()) {
                                            MySupplier supplier = postSnapshot.getValue(MySupplier.class);
                                            if (supplier.myID.equals(StaticConfig.UID) &&
                                                    supplier.supplierID.equals(data.adminID)) {
                                                isExist = true;
                                            }
                                        }
                                    }

                                    if (isExist) {
                                        Toast.makeText(context, "The Supplier Already Exist!!", Toast.LENGTH_SHORT).show();
                                        holder.checkStatus.setVisibility(View.GONE);
                                    } else {
                                        mDatabase.child("mySupplier").child(mySupplier.id).setValue(mySupplier);
                                    }
                                    mDatabase.child("mySupplier").removeEventListener(checkIfSupplierExist);
                                }

                                @Override
                                public void onCancelled(DatabaseError databaseError) {
                                }
                            };
                            mDatabase.child("mySupplier").addListenerForSingleValueEvent(checkIfSupplierExist);

                        } else {
                            // holder.checkStatus.setText("delete");
                            new AlertDialog.Builder(context)
                                    .setTitle("Delete Supplier")
                                    .setMessage("Are you sure want to Delete Supplier " + data.fullName + "?")
                                    .setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialogInterface, int i) {
                                            try{
                                                mDatabase.child("mySupplier").child(mySuppliers.get(p).id).removeValue();
                                            }catch (Exception e){ msg("Error to delete item: "+e);}
                                            dialogInterface.dismiss();
                                        }
                                    })
                                    .setNegativeButton(android.R.string.cancel, new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialogInterface, int i) {
                                            dialogInterface.dismiss();
                                        }
                                    }).show();
                        }
                    }
                });

                try {
                    Resources res = getResources();
                    Bitmap src;
                    if (data.avatar.equals("default")) {
                        src = BitmapFactory.decodeResource(res, R.drawable.default_avata);
                    } else {
                        byte[] decodedString = Base64.decode(data.avatar, Base64.DEFAULT);
                        src = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
                    }
                    holder.Avatar.setImageDrawable(ImageUtils.roundedImage(context, src));
                } catch (Exception e) { }
        }

        @Override
        public int getItemCount() { return listUsers.size(); }

        class MyHolder extends RecyclerView.ViewHolder {
            ImageView Avatar, checkStatus;
            TextView userInfo;

            public MyHolder(final View itemView) {
                super(itemView);
                context = itemView.getContext();
                Avatar = (ImageView) itemView.findViewById(R.id.icon_avatar);
                userInfo = (TextView) itemView.findViewById(R.id.user_info);
                checkStatus = (ImageView) itemView.findViewById(R.id.check_status_button);

                ((ImageView) itemView.findViewById(R.id.full_info)).setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        // show user info dialog
                        showUserInfo(listUsers.get(getAdapterPosition()));
                    }
                });
                itemView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (typeOfSelect.equals("mySupplier")) {
                            // add to card
                            mySupplierData = listUsers.get(getAdapterPosition());
                            Intent intent = new Intent(context, addToCardActivity.class);
                            intent.putExtra("supplierID", listUsers.get(getAdapterPosition()).adminID);
                            startActivity(intent);
                        }
                    }
                });
            }
        }
    }

    public void showUserInfo(User data){
        // start
        // dialog full details
        final Dialog dialog = new Dialog(orderProductsActivity.this);
        dialog.setContentView(R.layout.dialog_user_details);
        ImageView imageView = (ImageView) dialog.findViewById(R.id.imageView);
        TextView textView = (TextView) dialog.findViewById(R.id.textView);
        ImageView cancelDialogBtn = (ImageView) dialog.findViewById(R.id.cancel_dialog);

        String details =
                "Full Name: "+data.fullName+
                        "\n"+data.orderFrom+ " Name: "+data.storeName+
                        "\nEmail: "+data.email+
                        "\nPhone: "+data.phoneNumber+
                        "\nAddress: "+data.address+
                        "\nStatus: "+data.availableForOrders+
                        "\nCurrency: "+data.currency+
                        "\t\tType: "+data.orderFrom ;

        textView.setText(details);
        cancelDialogBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });

        try {
            Resources res = getResources();
            Bitmap src;
            if (data.avatar.equals("default")) {
                src = BitmapFactory.decodeResource(res, R.drawable.default_avata);
            } else {
                byte[] decodedString = Base64.decode(data.avatar, Base64.DEFAULT);
                src = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
            }
            imageView.setImageDrawable(ImageUtils.roundedImage(this, src));
            } catch (Exception e) { }
            dialog.show();
            // end
        }

        @Override
        public void onConnected(Bundle bundle) {
            try {
                LocationServices.FusedLocationApi.requestLocationUpdates(mGoogleApiClient, mLocationRequest, this);
            } catch (SecurityException e) {}
        }
        protected void stopLocationUpdates() {
            LocationServices.FusedLocationApi.removeLocationUpdates(mGoogleApiClient, this);
        }

        @Override
        public void onConnectionSuspended(int i) {}

        @Override
        public void onLocationChanged(Location location) {
            // StopTime = System.currentTimeMillis();
            //  long diff = StopTime - StartTime;
            // diff = TimeUnit.MILLISECONDS.toSeconds(diff);
            // msg("delay Time : " + diff + " seconds");
            x = location.getLatitude();
            y = location.getLongitude();
            progressDialog.dismiss();
            stopLocationUpdates();
            getmylocation();
            FAB.setEnabled(true);
            if (mGoogleApiClient.isConnected())
                mGoogleApiClient.disconnect();
        }

        @Override
        public void onConnectionFailed(ConnectionResult connectionResult) {}

        void GetLocation() {
            try {
                createLocationRequest();
                mGoogleApiClient = new GoogleApiClient.Builder(this)
                        .addApi(LocationServices.API)
                        .addConnectionCallbacks(this)
                        .addOnConnectionFailedListener(this)
                        .build();
                mGoogleApiClient.connect();
            }catch(Exception e){}
        }


        private float getDistance(double lat1, double lon1, double lat2, double lon2) {
            float[] distance = new float[2];
            Location.distanceBetween(lat1, lon1, lat2, lon2, distance);
            return distance[0] / 1000;
        }

        void getmylocation(){
            LatLng latLng = new LatLng(x, y);
            MarkerOptions markerOptions = new MarkerOptions();
            markerOptions.position(latLng)
                    .snippet(myAddress)
                    .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_BLUE));
            // .icon(BitmapDescriptorFactory.fromResource(R.drawable.edit_icon));
            SetUsersOnMap();
            CameraUpdate cameraUpdate = CameraUpdateFactory.newLatLngZoom(latLng, 12);
            mGoogleMap.animateCamera(cameraUpdate);
            mGoogleMap.addMarker(markerOptions);
        }

        @Override
        public void onMapReady(GoogleMap googleMap) {
            mGoogleMap = googleMap;
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                return;
            }

            mGoogleMap.setOnInfoWindowClickListener(new GoogleMap.OnInfoWindowClickListener(){
                @Override
                public void onInfoWindowClick(Marker marker) {
                    int i = Integer.parseInt(marker.getSnippet());
                    if (typeOfSelect.equals("mySupplier")) {
                        mySupplierData = listUsers.get(i);
                        Intent intent = new Intent(orderProductsActivity.this, addToCardActivity.class);
                        intent.putExtra("supplierID", listUsers.get(i).adminID);
                        startActivity(intent);
                    }else {
                        showUserInfo(listUsers.get(i));
                    }
                        try {

                        // show details on dialog
                        // invite button if available
                    /*

                    final int i = Integer.parseInt(marker.getSnippet());
                    startActivity(new Intent(getContext(), ShowDetails.class)
                            .putExtra("distance", new DecimalFormat("###.#").format(pets.get(i).distance))
                            .putExtra("iduser",pets.get(i).adminID)
                            .putExtra("idpost",pets.get(i).userID));
                    */
                    }catch(Exception e){}
                }
            });
        }

        void SetUsersOnMap() {
            if (!listUsers.isEmpty()){
                try {
                    MarkerOptions markerOptions = new MarkerOptions();
                    int i = 0;
                    for (User user_data : listUsers) {
                        LatLng latLng = new LatLng(user_data.coordinates.latitude, user_data.coordinates.longitude);
                        markerOptions
                                .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_BLUE))
                                .position(latLng)
                                .snippet(String.valueOf(i));
                        Marker m = mGoogleMap.addMarker(markerOptions);
                        CameraUpdate cameraUpdate = CameraUpdateFactory.newLatLngZoom(latLng, 16);
                        mGoogleMap.animateCamera(cameraUpdate);
                        //listUsers.get(i).distance = getDistance(user_data.coordinates.latitude, user_data.coordinates.longitude, x, y);
                        m.showInfoWindow();
                    }

                    CustomInfoWindowGoogleMap customInfoWindow = new CustomInfoWindowGoogleMap(orderProductsActivity.this, listUsers);
                    mGoogleMap.setInfoWindowAdapter(customInfoWindow);
                    i++;
                }catch (Exception e){msg("Error to set users mark on map  : "+e); }
            } else {msg("no items found");}
    }

    ArrayList<String> findUnAskedPermissions (ArrayList < String > wanted) {
        ArrayList<String> result = new ArrayList<String>();
        for (String perm : wanted) {
            if (!hasPermission(perm)) {
                result.add(perm);
            }
        }
        return result;
    }

    private boolean hasPermission (String permission){
        if (canMakeSmores()) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                return (checkSelfPermission(permission) == PackageManager.PERMISSION_GRANTED);
            }
        }
        return true;
    }
    private boolean canMakeSmores () {
        return (Build.VERSION.SDK_INT > Build.VERSION_CODES.LOLLIPOP_MR1);
    }


    @TargetApi(Build.VERSION_CODES.M)
    @Override
    public void onRequestPermissionsResult ( int requestCode, String[] permissions,
                                             int[] grantResults){
        switch (requestCode) {
            case ALL_PERMISSIONS_RESULT:
                for (String perms : permissionsToRequest) {
                    if (!hasPermission(perms)) {
                        permissionsRejected.add(perms);
                    }
                }
                if (permissionsRejected.size() > 0) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        if (shouldShowRequestPermissionRationale(permissionsRejected.get(0))) {
                            showMessageOKCancel("These permissions are mandatory for the application. Please allow access.",
                                    new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialog, int which) {
                                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                                                requestPermissions(permissionsRejected.toArray(new String[permissionsRejected.size()]), ALL_PERMISSIONS_RESULT);
                                            }
                                        }
                                    });
                            return;
                        }
                    }
                }
                break;
        }
    }

    private void showMessageOKCancel (String message, DialogInterface.OnClickListener okListener) {
        new AlertDialog.Builder(orderProductsActivity.this)
                .setMessage(message)
                .setPositiveButton("OK", okListener)
                .setNegativeButton("Cancel", null)
                .create()
                .show();
    }
}



 /*
 searchText.setFocusableInTouchMode(false);
 searchText.setOnClickListener(new View.OnClickListener() {
     @Override
     public void onClick(View v) {
         final Dialog dialog = new Dialog(orderProductsActivity.this);
         dialog.setContentView(R.layout.custom_edit_product);
         dialog.show();
         ((Button) dialog.findViewById(R.id.save)).setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View v) {
                 dialog.dismiss();
             }
         });

     }
 });
 */