package tech.siham.stock_management.Fragments;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import tech.siham.stock_management.R;

public class FragmentList extends Fragment {

    public FragmentList() {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View rootView = inflater.inflate(R.layout.fragment_list, container, false);

        return rootView;
    }
}

/*
    RecyclerView recyclerview;
    List<User> listUsers = new ArrayList<>();
    private RecyclerviewAdapter recycler;
    SharedPreferenceHelper SHHelper;
    private DatabaseReference mDatabase;
    Context context;

    ValueEventListener VELfetchSuppliers = null;
    ValueEventListener checkIfSupplierExist = null;

    List<MySupplier> mySuppliers = new ArrayList<>();
    String typeOfSelect = "";

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View rootView = inflater.inflate(R.layout.fragment_list, container, false);

        context = this.getContext();
        recyclerview = (RecyclerView) rootView.findViewById(R.id.recycleListUsers);
        SHHelper = SharedPreferenceHelper.getInstance(context);
        mDatabase = FirebaseDatabase.getInstance().getReference();
        recyclerview.setItemAnimator(new DefaultItemAnimator());
        recyclerview.setLayoutManager(new GridLayoutManager(context, 2));

        if (typeOfSelect == "Stock") {
            fetchStockData();
        } else {
            fetchMySuppliersData();
        }

        return rootView;
    }

    public void fetchStockData() {
        mDatabase.child("Stock").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    listUsers.clear();
                    // iterating through all the values in database
                    for (DataSnapshot postSnapshot : snapshot.getChildren()) {
                        User upload = postSnapshot.getValue(User.class);
                        try {
                            if (!upload.userID.equals(StaticConfig.UID) &&
                                    (upload.orderFrom.equals(userType) || userType.equals("All")) ) {
                                switch (positionUserSortBy) {
                                    case 0:
                                        // distance <= x
                                        float distance = getDistance(upload.coordinates.latitude, upload.coordinates.longitude );
                                        if(distance <= Integer.parseInt(searchUserStockName)){
                                            upload.distance = distance;
                                            listUsers.add(upload); }
                                        break;
                                    case 1:
                                        if (upload.fullName == searchUserStockName ||
                                                upload.shopName == searchUserStockName ||
                                                upload.storeName == searchUserStockName) {
                                            listUsers.add(upload);
                                        }
                                        break;
                                    case 2:
                                        if (searchUserStockName.equals(upload.myAddress.zipCode)) {
                                            listUsers.add(upload);
                                        }
                                        break;
                                    case 3:
                                        if (searchUserStockName.equalsIgnoreCase(upload.myAddress.city)) {
                                            listUsers.add(upload);
                                        }
                                        break;
                                }
                            }
                        }catch (Exception e){Toast.makeText(context,"Error in fetch stocks: "+e, Toast.LENGTH_LONG).show();}
                    }

                    if(listUsers.isEmpty()){
                        Toast.makeText(context, "Item not Found!!\ntry an other", Toast.LENGTH_LONG).show();
                    }
                    recycler = new RecyclerviewAdapter(context, listUsers);
                    recyclerview.setAdapter(recycler);
                    recycler.notifyDataSetChanged();

                } else {
                    Toast.makeText(context, "No Stock exist!!\n >> add new suppliers", Toast.LENGTH_SHORT).show();
                }
            }
            @Override
            public void onCancelled(DatabaseError databaseError) { }
        });
    }

    public void fetchMySuppliersData() {

        VELfetchSuppliers = new  ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                try {
                    if (snapshot.exists()) {

                        mySuppliers.clear();
                        listUsers.clear();
                        //iterating through all the values in database
                        for (DataSnapshot postSnapshot : snapshot.getChildren()) {
                            final MySupplier upload = postSnapshot.getValue(MySupplier.class);
                            if (upload.myID.equals(StaticConfig.UID)) {
                                mDatabase.child("Stock").child(upload.supplierID).addValueEventListener(new ValueEventListener() {
                                    @Override
                                    public void onDataChange(DataSnapshot snapshot2) {
                                        if (snapshot2.exists()) {
                                            User data = snapshot2.getValue(User.class);
                                            float distance = getDistance(data.coordinates.latitude, data.coordinates.longitude );
                                            data.distance = distance;
                                            listUsers.add(data);
                                            mySuppliers.add(upload);
                                        } else {
                                            Toast.makeText(context, "Error to get a supplier", Toast.LENGTH_SHORT).show();
                                        }
                                    }
                                    @Override
                                    public void onCancelled(DatabaseError databaseError) { }
                                });
                            }
                        }
                        recycler = new RecyclerviewAdapter(context, listUsers);
                        recyclerview.setAdapter(recycler);
                        recycler.notifyDataSetChanged();
                    } else {
                        Toast.makeText(context, "you don't have any supplier \nNo Stocks exist", Toast.LENGTH_SHORT).show();
                    }
                } catch (Exception e) {
                    Toast.makeText(context, "Error 234 :" + e, Toast.LENGTH_SHORT).show();
                }
                mDatabase.removeEventListener(VELfetchSuppliers);
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                mDatabase.removeEventListener(VELfetchSuppliers);
            }
        };
        mDatabase.child("mySupplier").addValueEventListener(VELfetchSuppliers);
    }


    private float getDistance(double lat, double lon) {
        float[] distance = new float[2];
        Location.distanceBetween(lat, lon,
                SHHelper.getUserInfo().coordinates.latitude,
                SHHelper.getUserInfo().coordinates.longitude, distance);
        return distance[0] / 1000;
    }


    private class RecyclerviewAdapter extends RecyclerView.Adapter<RecyclerviewAdapter.MyHolder> {

        private Context context;
        List<User> listUsers;
        LovelyProgressDialog dialogWaitDeleting;

        public RecyclerviewAdapter(Context context, List<User> listUsers) {
            this.listUsers = listUsers;
            this.context = context;
            dialogWaitDeleting = new LovelyProgressDialog(context);
        }

        @Override
        public RecyclerviewAdapter.MyHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_users_details, parent, false);
            RecyclerviewAdapter.MyHolder myHolder = new RecyclerviewAdapter.MyHolder(view);
            return myHolder;
        }

        public void onBindViewHolder(final RecyclerviewAdapter.MyHolder holder, final int position) {

            final User data = listUsers.get(position);

            try {

            String distance = new DecimalFormat("###.#").format(data.distance);
            String fromat = "Km";
            if(data.format.equals("US")){
                fromat = "mil";
                double distance_convert = Float.parseFloat(distance) * 0.621371;
                distance = new DecimalFormat("###.#").format(distance_convert);
            }
            String userInfo =
                    "Full Name: "+data.fullName+
                    "\nStore Name: "+data.storeName+
                    "\nEmail: "+data.email+
                    "\nPhone: "+data.phoneNumber+
                    "\nAddress: "+data.address+
                    "\nStatus: "+data.availableForOrders+
                    "\nDistance: "+distance+" "+fromat+
                    "\nUser Type: "+data.orderFrom ;
            // Html.fromHtml();
            holder.userInfo.setText(userInfo);

                if(data.availableForOrders.equals("on")){
                    holder.checkStatus.setText("Add To List");
                }else{
                    holder.checkStatus.setText("send an invitation");
                }

                if(typeOfSelect.equals("mySupplier")){
                    holder.checkStatus.setText("delete");
                }

                holder.checkStatus.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        if (typeOfSelect.equals("Stock")) {

                            final MySupplier mySupplier = new MySupplier();
                            mySupplier.myID = StaticConfig.UID;
                            mySupplier.id = mDatabase.push().getKey();
                            mySupplier.ordersDone = 0;
                            mySupplier.ordersPending = 0;
                            mySupplier.timestamp = (new Date()).getTime();
                            mySupplier.supplierID = data.adminID;

                            if (data.availableForOrders.equals("on")) {
                                mySupplier.status = "accept";
                            } else {
                                // show in notification
                                mySupplier.status = "pending";
                            }
                            // check if supplier already existed
                            checkIfSupplierExist = new ValueEventListener() {
                                @Override
                                public void onDataChange(DataSnapshot dataSnapshot) {
                                    boolean isExist = false;
                                    if (dataSnapshot.exists()) {
                                        for (DataSnapshot postSnapshot : dataSnapshot.getChildren()) {
                                            MySupplier supplier = postSnapshot.getValue(MySupplier.class);
                                            if (supplier.myID.equals(StaticConfig.UID) &&
                                                    supplier.supplierID.equals(data.adminID)) {
                                                isExist = true;
                                            }
                                        }
                                    }

                                    if (isExist) {
                                        Toast.makeText(context, "The Supplier Already Exist!!", Toast.LENGTH_SHORT).show();
                                        holder.checkStatus.setVisibility(View.GONE);
                                    } else {
                                        mDatabase.child("mySupplier").child(mySupplier.id).setValue(mySupplier);
                                    }

                                    mDatabase.removeEventListener(checkIfSupplierExist);

                                }

                                @Override
                                public void onCancelled(DatabaseError databaseError) {
                                }
                            };
                            mDatabase.child("mySupplier").addListenerForSingleValueEvent(checkIfSupplierExist);

                        } else {
                            // holder.checkStatus.setText("delete");
                            new AlertDialog.Builder(context)
                                            .setTitle("Delete Supplier")
                                            .setMessage("Are you sure want to Delete Supplier " + data.fullName + "?")
                                            .setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                                                @Override
                                                public void onClick(DialogInterface dialogInterface, int i) {
                                                    mDatabase.child("mySupplier").child(mySuppliers.get(position).id).removeValue();
                                                    dialogInterface.dismiss();
                                                }
                                            })
                                            .setNegativeButton(android.R.string.cancel, new DialogInterface.OnClickListener() {
                                                @Override
                                                public void onClick(DialogInterface dialogInterface, int i) {
                                                    dialogInterface.dismiss();
                                                }
                                            }).show();
                        }
                    }
                });

            if (typeOfSelect.equals("mySupplier")) {
                holder.itemView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        // add to card
                        Intent intent = new Intent(context, addToCardActivity.class);
                        intent.putExtra("supplierID", data.adminID);
                        startActivity(intent);
                    }
                });
            }

            try {
                Resources res = getResources();
                Bitmap src;
                if (data.avatar.equals("default")) {
                    src = BitmapFactory.decodeResource(res, R.drawable.default_avata);
                } else {
                    byte[] decodedString = Base64.decode(data.avatar, Base64.DEFAULT);
                    src = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
                }
                holder.Avatar.setImageDrawable(ImageUtils.roundedImage(context, src));
            } catch (Exception e) { }
            }catch (Exception e){Toast.makeText(context, "error 30: "+e, Toast.LENGTH_LONG).show();}
        }

        @Override
        public int getItemCount() { return listUsers.size(); }

        class MyHolder extends RecyclerView.ViewHolder {
            ImageView Avatar, checkStatus;
            TextView userInfo;

            public MyHolder(final View itemView) {
                super(itemView);
                context = itemView.getContext();
                Avatar = (ImageView) itemView.findViewById(R.id.icon_avatar);
                userInfo = (TextView) itemView.findViewById(R.id.user_info);
                checkStatus = (ImageView) itemView.findViewById(R.id.check_status_button);
            }
        }
    }

}
*/
