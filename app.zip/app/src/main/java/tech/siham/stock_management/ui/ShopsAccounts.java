package tech.siham.stock_management.ui;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Build;
import android.support.annotation.NonNull;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Base64;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import tech.siham.stock_management.Data.SharedPreferenceHelper;
import tech.siham.stock_management.Model.User;
import tech.siham.stock_management.R;
import tech.siham.stock_management.utils.ImageUtils;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.yarolegovich.lovelydialog.LovelyProgressDialog;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class ShopsAccounts extends AppCompatActivity  implements SwipeRefreshLayout.OnRefreshListener {

    private RecyclerView recyclerview;
    List<User> listUsers = new ArrayList<>();
    RecyclerviewAdapter recycler;
    private SwipeRefreshLayout mSwipeRefreshLayout;
    SharedPreferenceHelper SHHelper ;
    //database reference
    private DatabaseReference mDatabase;
    private DatabaseReference mDatabaseAdmin;
    //progress dialog
    private ProgressDialog progressDialog;
    //list to hold all the uploaded images
    double StartOrderPrice = 0.00;

    Dialog d = null;

    String[] SelectDayOfWeek = {
            "Monday",
            "Tuesday",
            "Wednesday",
            "Thursday",
            "Friday",
            "Saturday",
            "Sunday"};

    int[] idArrayEditText = {
            R.id.Monday,
            R.id.Tuesday,
            R.id.Wednesday,
            R.id.Thursday,
            R.id.Friday,
            R.id.Saturday,
            R.id.Sunday
    };

    public EditText[] EditTEXT = new EditText[idArrayEditText.length];

    List<Double> ordersPriceStartsAt = new ArrayList<>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shops_accounts);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        recyclerview = (RecyclerView) findViewById(R.id.recycleListUsers);
        mSwipeRefreshLayout = (SwipeRefreshLayout) findViewById(R.id.swipeRefreshLayout);
        mSwipeRefreshLayout.setOnRefreshListener(this);

        SHHelper = SharedPreferenceHelper.getInstance(this);

        // ListProducts from firebase
        // List list.add(new ListProducts(324,23423,234);

        progressDialog = new ProgressDialog(this);
        // displaying progress dialog while fetching images
        progressDialog.setMessage(" Please wait ...");
        progressDialog.show();
        mDatabase = FirebaseDatabase.getInstance().getReference("Users");
        mDatabaseAdmin = FirebaseDatabase.getInstance().getReference("Stock");

        RecyclerView.LayoutManager layoutmanager = new LinearLayoutManager(ShopsAccounts.this);
        recyclerview.setLayoutManager(layoutmanager);
        recyclerview.setItemAnimator(new DefaultItemAnimator());
        //recyclerview.setAdapter(recycler);

        fetchData();
        //adding an event listener to fetch values
                try {
                //d.setTitle("Add price for Zone ... by day of week ");
                d = new Dialog(ShopsAccounts.this);
                View viewInflater = LayoutInflater.from(ShopsAccounts.this).inflate(R.layout.dialog_confirm_order_price, null, false);

                    for(int i = 0; i < idArrayEditText.length; i++){
                        final int b = i;
                        EditTEXT[b] = (EditText) viewInflater.findViewById(idArrayEditText[b]); // Fetch the view id from array
                        EditTEXT[b].addTextChangedListener(new TextWatcher() {
                            @Override
                            public void beforeTextChanged(CharSequence s, int start, int count, int after) { }

                            @Override
                            public void onTextChanged(CharSequence s, int start, int before, int count) {
                                String text = EditTEXT[b].getText().toString().trim();
                                if (text.length() == 0 || text.equals("0.00") || text.equals("0")) {
                                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
                                        EditTEXT[b].setBackground(getResources().getDrawable(R.drawable.bt_shape_red));
                                    }
                                } else {
                                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
                                        EditTEXT[b].setBackground(getResources().getDrawable(R.drawable.bt_shape_green));
                                    }
                                    mDatabaseAdmin.child(SHHelper.getUID()).child("priceStart").child(SelectDayOfWeek[b]).setValue(Double.valueOf(EditTEXT[b].getText().toString()));
                                }
                            }
                            @Override
                            public void afterTextChanged(Editable s) { }
                        });
                    }

                Button saveBtn = (Button) viewInflater.findViewById(R.id.save);
                Button cancelBtn = (Button) viewInflater.findViewById(R.id.cancel);

                d.setContentView(viewInflater);
                //d.show();
                ordersPriceStartsAt.clear();
                ordersPriceStartsAt.add(100.00);
                ordersPriceStartsAt.add(100.00);
                ordersPriceStartsAt.add(100.00);
                ordersPriceStartsAt.add(100.00);
                ordersPriceStartsAt.add(100.00);
                ordersPriceStartsAt.add(100.00);
                ordersPriceStartsAt.add(100.00);


                    mDatabaseAdmin.child(SHHelper.getUID()).child("priceStart").addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(DataSnapshot dataSnapshot) {
                            //OrdersPriceStart ordersPriceStart = dataSnapshot.getValue(OrdersPriceStart.class);
                            HashMap hashUser = (HashMap) dataSnapshot.getValue();
                            if (dataSnapshot.exists()) {
                                ordersPriceStartsAt.clear();
                                try {
                                    for(int i = 0;i < SelectDayOfWeek.length; i++){
                                        String price = hashUser.get(SelectDayOfWeek[i]).toString();
                                        EditTEXT[i].setText(price);
                                        // Toast.makeText(ShopsAccounts.this, "data "+ SelectDayOfWeek[i] +" : "+ price, Toast.LENGTH_LONG).show();
                                        ordersPriceStartsAt.add(Double.parseDouble(price));
                                    }

                                    } catch (Exception e) {
                                    Toast.makeText(ShopsAccounts.this, " > error : " + e, Toast.LENGTH_LONG).show();
                                }
                                // for (int i = 0; i < idArrayEditText.length; i++) {
                                //    EditTEXT[i].setText(ordersPriceStartsAt.get(i).toString());
                                // }
                            }else{
                                // show dialog put prices to confirm ordrs by admin
                                d.show();
                            }
                            //for(int i = 0; i < ordersPriceStartsAt.size(); i++){
                            //    EditTEXT[i].setText(String.valueOf(ordersPriceStartsAt.get(i).Price));
                            //}
                        }

                        @Override
                        public void onCancelled(DatabaseError databaseError) {
                        }

                    });


                    saveBtn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        /*
                        if price <= 00.00 :
                             msg error
                             text error please set price for zone
                        else :
                             send data to db
                        */

                        d.dismiss();
                    }
                });
                cancelBtn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        d.dismiss();
                    }
                });

                } catch (Exception e) {
                    Toast.makeText(ShopsAccounts.this, "Error : "+e, Toast.LENGTH_LONG).show();
                }


        ((FloatingActionButton) findViewById(R.id.fab)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                // startActivity(new Intent(getActivity(), AddProduct.class));
                // show dialog orders will Confirm when total price great than SelectedPrice
                // set data in firebase
            }

        });

        // get date from firebase and set it in list
    }


    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == android.R.id.home) {
            onBackPressed();
            // overridePendingTransition(R.anim.slide_from_left, R.anim.slide_to_right);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }


    @Override
    public void onRefresh() {
        fetchData();
    }

    public void fetchData(){

        mDatabase.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                //dismissing the progress dialog
                progressDialog.dismiss();
                if (snapshot.exists()) {
                    listUsers.clear();
                    //iterating through all the values in database
                    for (DataSnapshot postSnapshot : snapshot.getChildren()) {
                        User upload = postSnapshot.getValue(User.class);
                        // if(upload.idAdmin.equals())
                            listUsers.add(upload);
                    }

                    recycler = new RecyclerviewAdapter(ShopsAccounts.this, listUsers);
                    recyclerview.setAdapter(recycler);
                    recycler.notifyDataSetChanged();
                    mSwipeRefreshLayout.setRefreshing(false);
                    if(listUsers.size() == 1 && ordersPriceStartsAt.isEmpty()){
                        d.show();
                    }

                } else {
                    Toast.makeText(ShopsAccounts.this, "No Users exist", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                progressDialog.dismiss();
            }
        });
    }


    class RecyclerviewAdapter extends RecyclerView.Adapter<RecyclerviewAdapter.MyHolder> {

        private Context context;
        List<User> listUsers;
        LovelyProgressDialog dialogWaitDeleting;

        public RecyclerviewAdapter(Context context, List<User> listUsers) {
            this.listUsers = listUsers;
            this.context = context;
            dialogWaitDeleting = new LovelyProgressDialog(context);
        }

        @Override
        public MyHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_users, parent, false);
            MyHolder myHolder = new MyHolder(view);
            return myHolder;
        }

        public void onBindViewHolder(MyHolder holder, int position) {
            User data = listUsers.get(position);
            //Glide.with(context).load(data.avatar).into(holder.ContentProduct);
            holder.FullName.setText("Full Name : " + data.fullName + "\nID : " + data.userID);
            holder.Email.setText("Email : " + data.email);
            holder.Address.setText("Address : " + data.address);
            holder.PhoneNumber.setText("Phone Number : " + data.phoneNumber);
            holder.AccountStatus.setText("Account Status : " + data.accountStatus);

            try {
                Resources res = getResources();
                Bitmap src;
                if (data.avatar.equals("default")) {
                    src = BitmapFactory.decodeResource(res, R.drawable.default_avata);
                } else {
                    byte[] decodedString = Base64.decode(data.avatar, Base64.DEFAULT);
                    src = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
                }
                holder.Avatar.setImageDrawable(ImageUtils.roundedImage(ShopsAccounts.this, src));
            }catch (Exception e){
            }
        }

        @Override
        public int getItemCount() {
            return listUsers.size();
        }

        class MyHolder extends RecyclerView.ViewHolder {
            ImageView Accept, Refuse, Edit;
            ImageView Avatar;
            TextView FullName, Email, Address, PhoneNumber, AccountStatus, TextDetails;
            private final Context context;
            Spinner dayOfWeek;
            EditText OrderStartWithPrice;
            String dayOfWeekSelected;
            private RadioGroup radioGroup;
            int Tariff = 1;
            Button Save, Cancel;

            private void ShowDialog(){

                View viewInflater = LayoutInflater.from(ShopsAccounts.this).inflate(R.layout.dialog_set_fee, null, false);
                dayOfWeek = (Spinner) viewInflater.findViewById(R.id.spinner);
                OrderStartWithPrice = (EditText) viewInflater.findViewById(R.id.orderStartWithPrice);
                radioGroup = (RadioGroup) viewInflater.findViewById(R.id.radioGroup);
                int checkedRadioButton[] = {
                        R.id.radioButton1,
                        R.id.radioButton2,
                        R.id.radioButton3
                };

                try {
                    //radioGroup.check(checkedRadioButton[listUsers.get(getAdapterPosition()).tariff]);
                }catch (Exception e){}

                radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
                    @Override
                    public void onCheckedChanged(RadioGroup group, int checkedId) {
                        RadioButton rb = (RadioButton) group.findViewById(checkedId);
                        Tariff = Character.getNumericValue(rb.getText().toString().trim().charAt(0));
                    }
                });

                Save = (Button) viewInflater.findViewById(R.id.save);
                Cancel = (Button) viewInflater.findViewById(R.id.cancel);

                // Spinner Drop down elements
                List<String> categories = new ArrayList<String>();
                // categories.add(listUsers.get(getAdapterPosition()).dayOfWeek);
                categories.add("Monday");
                categories.add("Tuesday");
                categories.add("Wednesday");
                categories.add("Thursday");
                categories.add("Friday");
                categories.add("Saturday");
                categories.add("Sunday");

                // Creating adapter for spinner
                ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(context, android.R.layout.simple_spinner_item, categories);
                // Drop down layout style - list view with radio button
                dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                // attaching data adapter to spinner
                dayOfWeek.setAdapter(dataAdapter);

                /*
                int position = 0;
                for(int i=0;i<SelectDayOfWeek.length; i++){

                    if(listUsers.get(getAdapterPosition()).dayOfWeek.equals(SelectDayOfWeek[i])){
                        position = i;
                        StartOrderPrice = ordersPriceStartsAt.get(position);
                        OrderStartWithPrice.setText(String.valueOf(StartOrderPrice));
                    }else{

                    }

                }

                dayOfWeek.setSelection(position);
                */
                dayOfWeek.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                    @Override
                    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                        dayOfWeekSelected = parent.getItemAtPosition(position).toString();
                        StartOrderPrice = ordersPriceStartsAt.get(position) ;
                        OrderStartWithPrice.setText(String.valueOf(StartOrderPrice));
                    }
                    @Override
                    public void onNothingSelected(AdapterView<?> parent) { }
                });


                final Dialog dialog = new Dialog(ShopsAccounts.this);
                dialog.setContentView(viewInflater);
                dialog.show();

                Save.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        final String UserID = listUsers.get(getAdapterPosition()).userID;
                        DatabaseReference  mDataBase =  FirebaseDatabase.getInstance().getReference().child("Users").child(UserID);
                        mDataBase.child("dayOfWeek").setValue(dayOfWeekSelected);
                        mDataBase.child("startPrice").setValue(StartOrderPrice);
                        mDataBase.child("tariff").setValue(Tariff);
                        mDataBase.child("accountStatus").setValue("accept");
                        mDataBase.child("adminID").setValue(SHHelper.getUID()).addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {
                                if (task.isSuccessful()) {
                                    // show dialog for set tax, fee and transport price
                                    dialog.dismiss();
                                    Toast.makeText(ShopsAccounts.this, "User accepted Successfully", Toast.LENGTH_LONG).show();
                                    // ShopsAccounts.this.finish();
                                }else {
                                    dialog.dismiss();
                                    Toast.makeText(ShopsAccounts.this, "Failed to accept "+listUsers.get(getAdapterPosition()).fullName +"\nPlease try again", Toast.LENGTH_LONG).show();
                                }
                            }
                        });
                    }
                });

                Cancel.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        dialog.dismiss();
                    }
                });

            }

            public MyHolder(final View itemView) {
                super(itemView);
                context = itemView.getContext();
                final Intent[] intent = new Intent[1];

                Accept = (ImageView) itemView.findViewById(R.id.accept);
                Edit = (ImageView) itemView.findViewById(R.id.edit);
                Refuse = (ImageView) itemView.findViewById(R.id.refuse);

                Avatar = (ImageView) itemView.findViewById(R.id.icon_avatar);
                FullName = (TextView) itemView.findViewById(R.id.txtFullName);
                Email = (TextView) itemView.findViewById(R.id.txtEmail);
                Address = (TextView) itemView.findViewById(R.id.txtAddress);
                PhoneNumber = (TextView) itemView.findViewById(R.id.txtPhoneNumber);
                AccountStatus = (TextView) itemView.findViewById(R.id.txtAccount);
                TextDetails = (TextView) itemView.findViewById(R.id.text_details);

                // View content of dialog (set fee price)
                Accept.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        switch (listUsers.get(getAdapterPosition()).accountStatus){
                            case "new":
                                Toast.makeText(context, "User should set his profile first", Toast.LENGTH_LONG).show();
                                break;
                            case "accept":
                                Toast.makeText(context, "User Already Accept", Toast.LENGTH_LONG).show();
                                break;
                            case "pending":
                                ShowDialog();
                                break;
                        }
                    }
                });

                Edit.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        ShowDialog();
                    }
                });

                Refuse.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        switch (listUsers.get(getAdapterPosition()).accountStatus){
                            case "new":
                                Toast.makeText(context, "User should set his profile first", Toast.LENGTH_LONG).show();
                                break;
                            case "accept":
                                // show dialog ok
                                new AlertDialog.Builder(ShopsAccounts.this)
                                        .setTitle("FREEZING USER!!!")
                                        .setMessage("Are You Sure!\nTo set user "
                                                +listUsers.get(getAdapterPosition()).fullName
                                                +" on Pending Status?")
                                        .setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                                            @Override
                                            public void onClick(DialogInterface dialogInterface, int i) {
                                                FirebaseDatabase.getInstance().getReference().child("Users").child(listUsers.get(getAdapterPosition()).userID).child("accountStatus").setValue("pending");
                                                dialogInterface.dismiss();
                                            }
                                        })
                                        .setNegativeButton(android.R.string.cancel, new DialogInterface.OnClickListener() {
                                            @Override
                                            public void onClick(DialogInterface dialogInterface, int i) {
                                                dialogInterface.dismiss();
                                            }
                                        }).show();
                                break;
                            case "pending":
                                Toast.makeText(context, "User Already Pending !", Toast.LENGTH_LONG).show();
                                break;
                        }
                    }
                });

            /*

            itemView.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View v) {
                    //String productkey = listProducts.get(getAdapterPosition()).getPushkey();
                   // String producttitle = listProducts.get(getAdapterPosition()).getTitle();
                    new AlertDialog.Builder(context)
                            .setTitle("Delete Product ")
                            .setMessage("Are you sure want to delete ... ?")
                            .setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialogInterface, int i) {
                                    dialogInterface.dismiss();
                                    FirebaseDatabase.getInstance().getReference().child("Products").child(productkey).removeValue();
                                }
                            })
                            .setNegativeButton(android.R.string.cancel, new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialogInterface, int i) {
                                    dialogInterface.dismiss();
                                }
                            }).show();
                    return false;
                }
            });
            */
                itemView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                    /*
                    String UserKey = listUsers.get(getAdapterPosition()).getPushkey();
                    intent[0] = new Intent(context, Profiles.class);
                    intent[0].putExtra("id",UserKey);
                    context.startActivity(intent[0]);
                    */

                    }
                });
            }
        }
    }
}