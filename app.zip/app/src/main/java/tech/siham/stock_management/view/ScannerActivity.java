package tech.siham.stock_management.view;

import android.Manifest;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.github.softotalss.barcodescanner.view.BarcodeScannerView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.zxing.Result;

import tech.siham.stock_management.Data.DBHelper;
import tech.siham.stock_management.Data.StaticConfig;
import tech.siham.stock_management.Model.ListProducts;
import tech.siham.stock_management.Model.MyBasket;
import tech.siham.stock_management.R;
import tech.siham.stock_management.utils.ActivityUtil;
import tech.siham.stock_management.utils.Constants;
import tech.siham.stock_management.utils.DialogFactory;

import static tech.siham.stock_management.ui.POSActivity.scannedListProducts;

public class ScannerActivity extends AppCompatActivity implements BarcodeScannerView.ActivityCallback {

    private static final String TAG = ScannerActivity.class.getSimpleName();

    private ViewGroup mContentFrame;
    private BarcodeScannerView mScannerView;

    ListProducts listProducts = new ListProducts();
    //database reference
    private DatabaseReference mDatabase;
    private int ScannedPackets = 1;

    DBHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Window window = getWindow();
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        db = new DBHelper(ScannerActivity.this);

        if (isLandscapeSimulated()) {
            setContentView(R.layout.activity_scanner_rotate);
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
            Toast.makeText(this, R.string.text_landscape_simulated, Toast.LENGTH_LONG).show();
        } else {
            setContentView(R.layout.activity_scanner);
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
            Toast.makeText(this, R.string.text_landscape, Toast.LENGTH_LONG).show();
        }
        setSupportActionBar((Toolbar) findViewById(R.id.toolbar));
        mDatabase = FirebaseDatabase.getInstance().getReference();
        initView();
    }

    @Override
    public void onResume() {
        super.onResume();
        startCamera();
    }

    @Override
    public void onPause() {
        stopCamera();
        super.onPause();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_scanner, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                break;
            case R.id.btn_flash:
                if(!mScannerView.isFlashOn()) {
                    item.setIcon(R.drawable.ic_flash_on);
                    item.setTitle(R.string.text_flash_on);
                } else {
                    item.setIcon(R.drawable.ic_flash_off);
                    item.setTitle(R.string.text_flash_off);
                }
                mScannerView.toggleFlash();
                return true;
            case R.id.btn_rotate:
                Intent intent = new Intent(this, ScannerActivity.class);
                intent.putExtra("landscapeSimulated", !isLandscapeSimulated());
                startActivity(intent);
                finish();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode) {
            case Constants.PERMISSION_CAMERA:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    initCamera();
                } else {
                    DialogInterface.OnClickListener ok = new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            finish();
                        }
                    };
                    DialogFactory.showNoCancelable(DialogFactory.createSimpleOkDialog(this, R.string.text_alert,
                            R.string.msg_camera_permission_denied, ok));
                }
                break;
        }
    }

    private void initView() {
        mContentFrame = findViewById(R.id.layout_content);
        if (ActivityUtil.solicitarPermisos(this, Manifest.permission.CAMERA,
                R.string.text_alert, R.string.msg_camera_permission,
                Constants.PERMISSION_CAMERA)) {
            initCamera();
        }
    }

    private void initCamera() {
        mScannerView = new BarcodeScannerView(this);
        mScannerView.setLandscapeSimulated(isLandscapeSimulated());
        mContentFrame.addView(mScannerView);
    }

    private void startCamera() {
        if (mScannerView != null) {
            mScannerView.setResultHandler(this);
            mScannerView.startCamera();
        }
    }

    private void stopCamera() {
        if (mScannerView != null) {
            mScannerView.stopCamera();
        }
    }

    private boolean isLandscapeSimulated() {
        return getIntent().getBooleanExtra("landscapeSimulated", false);
    }

    @Override
    public void onResult(final Result result) {
        Log.d(TAG, result.getText());
        final String barcode = result.getText();

        /*
        if intent data = db_check -> scan barcode and check db
        // see if barcode exist in db
        // yes get data data from db
        // add data to list
        // ok to confirm & scan again
        // add number of unites
        // cancel
        if intent data = scan barcode
        // scan Barcode
        // return data to add product
        // finish

        */

        if (StaticConfig.intentMode.equals("barcodeScanner")){

            final Dialog dialog = new Dialog(ScannerActivity.this);

            dialog.setContentView(R.layout.dialog_scan_item);

            final EditText barcodeScanned = (EditText) dialog.findViewById(R.id.barcode_et);
            Button dialogButtonConfirm = (Button) dialog.findViewById(R.id.confirm_btn);
            Button dialogButtonRescan = (Button) dialog.findViewById(R.id.rescan_btn);
            Button dialogButtonCancel = (Button) dialog.findViewById(R.id.cancel_btn);

            barcodeScanned.setText(barcode);
            final Intent intent = new Intent();

            dialogButtonRescan.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    mScannerView.restartCamera(); // Use it for read another barcode without close camera
                    dialog.dismiss();
                }
            });
            dialogButtonCancel.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    dialog.dismiss();
                    intent.putExtra("barcode", barcodeScanned.getText().toString());
                    setResult(2, intent);
                    finish();
                }
            });
            dialogButtonConfirm.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    dialog.dismiss();
                    intent.putExtra("barcode",  barcodeScanned.getText().toString());
                    setResult(2, intent);
                    finish();
                }
            });
            dialog.show();

        } else {

            final Dialog dialog = new Dialog(ScannerActivity.this);
            dialog.setContentView(R.layout.dialog_add_item);
            final EditText unitiesScanned = (EditText) dialog.findViewById(R.id.unities_et);
            ImageView addUnit = (ImageView) dialog.findViewById(R.id.addItem);
            final ImageView removeUnit = (ImageView) dialog.findViewById(R.id.subtractItem);
            final TextView productName = (TextView) dialog.findViewById(R.id.product_name);
            final TextView productInfo = (TextView) dialog.findViewById(R.id.detail_txt);
            Button dialogButtonConfirm = (Button) dialog.findViewById(R.id.confirm_btn);
            Button dialogButtonConfirmScan = (Button) dialog.findViewById(R.id.confirm_rescan_btn);
            Button dialogButtonCancel = (Button) dialog.findViewById(R.id.cancel_btn);

            final ImageView imageView = (ImageView) dialog.findViewById(R.id.imageView);

            addUnit.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    ScannedPackets += 1;
                    unitiesScanned.setText(String.valueOf(ScannedPackets));
                    // add units +1
                    if(ScannedPackets > 1){
                        removeUnit.setVisibility(View.VISIBLE);
                    }
                }
            });

            removeUnit.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    ScannedPackets -= 1;
                    unitiesScanned.setText(String.valueOf(ScannedPackets));
                    // sub units -1
                    if(ScannedPackets == 1){
                        removeUnit.setVisibility(View.GONE);
                    }
                }
            });

            dialogButtonConfirmScan.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    setCart(listProducts);
                    // scannedListProducts.add(listProducts);
                    // MyBasket myBasket = new MyBasket();
                    // myBasket = listProducts;
                    // db.insertBasket();
                    mScannerView.restartCamera(); // Use it for read another barcode without close camera
                    dialog.dismiss();
                }
            });
            dialogButtonConfirm.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    // scannedListProducts.add(listProducts);
                    setCart(listProducts);
                    dialog.dismiss();
                    Intent intent = new Intent();
                    setResult(5, intent);
                    finish();
                }
            });

            dialogButtonCancel.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    dialog.dismiss();
                    Intent intent = new Intent();
                    setResult(5, intent);
                    finish();
                }
            });

            mDatabase.child("Categories").addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot snapshot) {
                    if (snapshot.exists()) {
                        try {
                            boolean barcodeIsFound = false;
                            listProducts = null;
                            for (DataSnapshot postSnapshot : snapshot.getChildren()) {
                                if(postSnapshot.child("adminID").getValue().equals(StaticConfig.UID)) {
                                    for (DataSnapshot pos_Snapshot : postSnapshot.child("Products").getChildren()) {
                                        ListProducts upload = pos_Snapshot.getValue(ListProducts.class);

                                        if (upload.barCode.equals(barcode) && upload.adminID.equals(StaticConfig.UID)) {
                                            listProducts = upload;
                                            barcodeIsFound = true;
                                            String details = // "Product Name: "+listProducts.productName+
                                                    "\nbarCode: "+listProducts.barCode+
                                                            "\nCategory: "+listProducts.categoryName+
                                                            "\nBuy Price: "+listProducts.buyPrice+
                                                            "\nSell Price: "+listProducts.sellPrice+
                                                            // "\nDescribe: "+ listProducts.description+
                                                            "\nExpiry Date"+listProducts.expiryDate+" "+listProducts.expiryTime+
                                                            // "\nPost Date: "+ listProducts.postDate+
                                                            "\nPackets at Stock: "+listProducts.availablePackets+
                                                            "\nSold Packets: "+listProducts.soldPackets;
                                            productName.setText("Product Name: "+listProducts.productName);
                                            productInfo.setText(details);
                                            Glide.with(ScannerActivity.this).load(listProducts.imagePath).into(imageView);
                                            ScannedPackets += 1;
                                            unitiesScanned.setText(String.valueOf(ScannedPackets));
                                            dialog.show();
                                        }
                                    }
                                }
                            }

                            if (!barcodeIsFound) {
                                DialogFactory.showNoCancelable(DialogFactory.createSimpleOkDialog(ScannerActivity.this,
                                        "Product Not Found!!!", "Barcode " + barcode + " is not matched! \nto any barcode in DB",
                                        new DialogInterface.OnClickListener() {
                                            @Override
                                            public void onClick(DialogInterface dialog, int which) {
                                                mScannerView.restartCamera(); // Use it for read another barcode without close camera
                                            }
                                        }));
                            }
                        } catch (Exception e) {
                            msg("error 54:" + e);
                        }
                    } else {
                        msg("No Product Found!");
                    }
                }
                @Override
                public void onCancelled(DatabaseError databaseError) { }
            });

        }
    }

    private void setCart(ListProducts productDetail){
        boolean isBasketExist = false;
        int packets = 0;
        int unities = 0;
        double price = 0.00;

        for (MyBasket myBasketID : db.getAllBaskets()) {
            String productID = myBasketID.productID;
            if (productID.equals(productDetail.productID)) {
                packets = ScannedPackets;
                unities = myBasketID.unities;
                price = myBasketID.price;
                double total = (packets * myBasketID.unities * myBasketID.price);
                db.updateBasket(productID, packets, total);
                isBasketExist = true;
            }

        }

        if(!isBasketExist){
            //add barCode
            // add one item to my basket
            // get basket position add one
            MyBasket myCart = new MyBasket();
            // myCart.listProducts = listProducts.get(getAdapterPosition());
            myCart.price = productDetail.sellPrice;
            price = myCart.price;
            myCart.unities = productDetail.unities;
            myCart.imagePath = productDetail.imagePath;
            myCart.productName = productDetail.productName;
            myCart.productID = productDetail.productID;
            myCart.describe = productDetail.description;
            myCart.categoryID = productDetail.categoryID;
            myCart.barCode = productDetail.barCode;
            myCart.status = "pending";
            myCart.position = 0;
            myCart.packets = ScannedPackets;
            packets = myCart.packets;
            unities = myCart.unities;
            myCart.basketID = mDatabase.push().getKey();
            myCart.total = (myCart.packets * myCart.unities * myCart.price);
            db.insertBasket(myCart);
            // myBasket.add(myCart.position, myCart);
            // myBasket.add(myCart);
        }

    }


    void setCart(String type, ListProducts productDetail) {
        try {
            int packets = 0;
            int unities = 0;
            double price = 0.00;
            switch (type) {
                case "new":
                    //add barCode
                    // add one item to my basket
                    // get basket position add one
                    MyBasket myCart = new MyBasket();
                    // myCart.listProducts = listProducts.get(getAdapterPosition());
                    myCart.price = productDetail.sellPrice;
                    price = myCart.price;
                    myCart.unities = productDetail.unities;
                    myCart.imagePath = productDetail.imagePath;
                    myCart.productName = productDetail.productName;
                    myCart.productID = productDetail.productID;
                    myCart.describe = productDetail.description;
                    myCart.categoryID = productDetail.categoryID;
                    myCart.barCode = productDetail.barCode;
                    myCart.status = "pending";
                    myCart.position = 0;
                    myCart.packets = 1;
                    packets = myCart.packets;
                    unities = myCart.unities;
                    myCart.basketID = mDatabase.push().getKey();
                    myCart.total = (myCart.packets * myCart.unities * myCart.price);
                    db.insertBasket(myCart);
                    //myBasket.add(myCart.position, myCart);
                    //myBasket.add(myCart);
                    break;
                case "add":
                    for (MyBasket myBasketID : db.getAllBaskets()) {
                        String productID = myBasketID.productID;
                        if (productID.equals(productDetail.productID)) {
                            packets = myBasketID.packets + 1;
                            unities = myBasketID.unities;
                            price = myBasketID.price;
                            double total = (packets * myBasketID.unities * myBasketID.price);
                            db.updateBasket(productID, packets, total);
                        }
                    }
                    break;
                case "sub":
                    for (MyBasket myBasketID : db.getAllBaskets()) {
                        String productID = myBasketID.productID;
                        if (productID.equals(productDetail.productID)) {
                            packets = myBasketID.packets - 1;
                            unities = myBasketID.unities;
                            price = myBasketID.price;
                            double total = (packets * myBasketID.unities * myBasketID.price);
                            if (packets == 0) {
                                // show dialog
                                db.deleteBasket(productID);
                            } else {
                                db.updateBasket(productID, packets, total);
                            }
                        }
                    }
                    break;
            }
        }catch (Exception e){ msg("error in "+type+" :\n" + e); }
    }
    @Override
    public void onErrorExit(Exception e) {
        Log.d(TAG, "onErrorExit");
        DialogFactory.showNoCancelable(DialogFactory.createSimpleOkDialog(this,
                R.string.app_name, R.string.msg_camera_framework_bug,
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        finish();
                    }
                }));
    }

    public void msg(String text){
        Toast.makeText(ScannerActivity.this, text, Toast.LENGTH_SHORT).show();
    }
}
