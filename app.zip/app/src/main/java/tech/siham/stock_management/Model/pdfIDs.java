package tech.siham.stock_management.Model;

public class pdfIDs {
    public String ID_USER ;
    public String ID_ADMIN ;
    public String ID_ORDER ;

    public pdfIDs(){}
}
