package tech.siham.stock_management.FragmentsSettings;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.Switch;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import tech.siham.stock_management.Data.StaticConfig;
import tech.siham.stock_management.R;

public class availableForDelivery extends Fragment {


    public availableForDelivery() {
        // Required empty public constructor
    }

    private DatabaseReference mDatabase;
    Switch simpleSwitch;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View root = inflater.inflate(R.layout.fragment_available_for_delivery, container, false);

        // availableForDelivery

        simpleSwitch = (Switch) root.findViewById(R.id.delivery_switch);
        mDatabase = FirebaseDatabase.getInstance().getReference("Stock").child(StaticConfig.UID);
        mDatabase.keepSynced(false);

        simpleSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                String check = "off";
                if(isChecked){
                    check = "on";
                }
                mDatabase.child("availableForDelivery").setValue(check);
            }
        });

        mDatabase.child("availableForDelivery").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if(dataSnapshot.exists()){
                    if(dataSnapshot.getValue(String.class).equals("on")){
                        simpleSwitch.setChecked(true);
                    }else{
                        simpleSwitch.setChecked(false);
                    }
                }
            }
            @Override
            public void onCancelled(DatabaseError databaseError) { }
        });


        return root;
    }

}
