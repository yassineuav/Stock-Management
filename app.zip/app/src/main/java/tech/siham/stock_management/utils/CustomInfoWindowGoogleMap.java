package tech.siham.stock_management.utils;

import android.app.Activity;
import android.content.Context;
import android.view.View;
import android.widget.RatingBar;
import android.widget.TextView;

import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.model.Marker;

import java.text.DecimalFormat;
import java.util.List;

import tech.siham.stock_management.Model.User;
import tech.siham.stock_management.R;

public class CustomInfoWindowGoogleMap implements
        GoogleMap.InfoWindowAdapter {
    private Context context;

    List<User> user ;
    public CustomInfoWindowGoogleMap(Context ctx, List<User> user){
        context = ctx;
        this.user = user;
    }

    @Override
    public View getInfoWindow(Marker marker) {
        return null;
    }
    @Override
    public View getInfoContents(Marker marker) {
        View view = null;
        try {

            final int i = Integer.parseInt(marker.getSnippet());

            view = ((Activity) context).getLayoutInflater().inflate(R.layout.marker_view_details, null);

            TextView ShopName = (TextView) view.findViewById(R.id.shopTxt);
            TextView distance = (TextView) view.findViewById(R.id.distance);
            TextView textRating = (TextView) view.findViewById(R.id.textRating);
            TextView details = (TextView) view.findViewById(R.id.detailsTxt);
            TextView textOpenHours = (TextView) view.findViewById(R.id.textOpenHours);

            RatingBar ratingBar = (RatingBar) view.findViewById(R.id.rating_bar);
            ratingBar.setRating((float) user.get(i).star);

            ShopName.setText(user.get(i).storeName+"/"+user.get(i).shopName);

            distance.setText(new DecimalFormat("###.#").format((user.get(i).distance))+" Km");

            textRating.setText("Ratings -" + String.valueOf(user.get(i).star));
            details.setText("Name: " + user.get(i).fullName+
                    "\nType: " + user.get(i).orderFrom +
                    "\nPhone: " + user.get(i).phoneNumber +
                    "\nAddress: " + user.get(i).address +
                    "\nAvailable for Delivery: " + user.get(i).DeliveryAvailableArea +
                    "\nAvailable to get orders: " + user.get(i).ordersAvailableArea
            );
            // textOpenHours.setText("Open Hours - " + user.get(i).getOpenfrom() + " " + user.get(i).getOpento());

        } catch (Exception e) {
                view = ((Activity) context).getLayoutInflater().inflate(R.layout.markerme, null);
                ((TextView) view.findViewById(R.id.myAddress)).setText(marker.getSnippet());
        }

        return view;
    }
}

