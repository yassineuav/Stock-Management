package tech.siham.stock_management.ui;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import tech.siham.stock_management.Model.ListProducts;
import tech.siham.stock_management.R;

import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.yarolegovich.lovelydialog.LovelyProgressDialog;

import java.util.ArrayList;
import java.util.List;

public class ActivityItemsView extends AppCompatActivity implements SwipeRefreshLayout.OnRefreshListener {

    View view;
    RecyclerView recyclerview;
    List<ListProducts> listProducts = new ArrayList<>();
    RecyclerviewAdapter recycler;
    private SwipeRefreshLayout mSwipeRefreshLayout;

    //database reference
    private DatabaseReference mDatabase;
    //progress dialog
    private ProgressDialog progressDialog;
//list to hold all the uploaded images

    String CategoryID, CategoryName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_items_view);

        try {
        // getSupportActionBar().setTitle("My Products");
        // provide compatibility to all the versions
        // LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false);

        CategoryID = getIntent().getStringExtra("categoryID");
        CategoryName = getIntent().getStringExtra("categoryName");

        recyclerview = (RecyclerView) findViewById(R.id.recycleListProducts);
        mSwipeRefreshLayout = (SwipeRefreshLayout) findViewById(R.id.swipeRefreshLayout);
        mSwipeRefreshLayout.setOnRefreshListener(this);
        recyclerview.setItemAnimator(new DefaultItemAnimator());
        recyclerview.setLayoutManager(new GridLayoutManager(this, 2));

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.add_new_item);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ActivityItemsView.this, AddNewProduct.class);
                intent.putExtra("categoryID",CategoryID);
                intent.putExtra("categoryName",CategoryName);
                startActivity(intent);
            }
        });

            progressDialog = new ProgressDialog(this);
            // displaying progress dialog while fetching images
            progressDialog.setMessage(" Please wait ...");
            progressDialog.show();
            mDatabase = FirebaseDatabase.getInstance().getReference("Categories");
            fetchData();
            //adding an event listener to fetch values

        }catch (Exception e){
            Toast.makeText(ActivityItemsView.this, "error :  "+e, Toast.LENGTH_SHORT).show();
        }

        ((ImageView) findViewById(R.id.goBack)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        ((ImageView)findViewById(R.id.btnSearch)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText searchText = (EditText) findViewById(R.id.search_text);
                final String text = searchText.getText().toString().trim();
                if(text.isEmpty()){
                    searchText.setError("Please!\nType a product name");
                }else {
                    Query query = mDatabase.child(CategoryID).child("Products").orderByChild("productName").equalTo(text);
                    query.addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(DataSnapshot dataSnapshot) {
                            if (dataSnapshot.exists()) {
                                ListProducts upload = dataSnapshot.child(dataSnapshot.getChildren().iterator().next().getKey()).getValue(ListProducts.class);
                                listProducts.clear();
                                listProducts.add(upload);
                                recycler = new RecyclerviewAdapter(ActivityItemsView.this, listProducts);
                                recyclerview.setAdapter(recycler);
                                recycler.notifyDataSetChanged();
                                mSwipeRefreshLayout.setRefreshing(false);
                            } else {
                                msg(text + " not found!");
                            }
                        }

                        @Override
                        public void onCancelled(DatabaseError databaseError) {
                        }
                    });
                }
            }
        });
    }

    @Override
    public void onRefresh() {
        fetchData();
    }

    public void fetchData(){
        mDatabase.child(CategoryID).child("Products").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                //dismissing the progress dialog
                progressDialog.dismiss();

                TextView noProduct = (TextView) findViewById(R.id.noProductFound);

                listProducts.clear();

                if (snapshot.exists()) {
                    // iterating through all the values in database
                    for (DataSnapshot postSnapshot : snapshot.getChildren()) {
                        ListProducts upload = postSnapshot.getValue(ListProducts.class);
                        if(upload.categoryID.equals(CategoryID))
                            listProducts.add(upload);
                    }

                    if(listProducts.isEmpty()){
                        noProduct.setVisibility(View.VISIBLE);
                    }else{
                        noProduct.setVisibility(View.GONE);
                    }

                    recycler = new RecyclerviewAdapter(ActivityItemsView.this, listProducts);
                    recyclerview.setAdapter(recycler);
                    recycler.notifyDataSetChanged();
                    mSwipeRefreshLayout.setRefreshing(false);


                } else {
                    noProduct.setVisibility(View.VISIBLE);
                    msg("No Product Found!");
                    // display image at Layout
                }
            }
            @Override
            public void onCancelled(DatabaseError databaseError) {
                progressDialog.dismiss();
            }
        });

    }

    public void msg(String text){
        // Snackbar.make(view, text, Snackbar.LENGTH_LONG).setAction("Action", null).show();
        Toast.makeText(ActivityItemsView.this, text, Toast.LENGTH_SHORT).show();
    }

    // AdapterView
    class RecyclerviewAdapter extends RecyclerView.Adapter<RecyclerviewAdapter.MyHolder> {

        private Context context;
        List<ListProducts> listProducts;
        LovelyProgressDialog dialogWaitDeleting;

        public RecyclerviewAdapter(Context context, List<ListProducts> listProducts) {
            this.listProducts = listProducts;
            this.context = context;
            dialogWaitDeleting = new LovelyProgressDialog(context);
        }

        @Override
        public MyHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_items_product, parent, false);
            MyHolder myHolder = new MyHolder(view);
            return myHolder;
        }

        public void onBindViewHolder(MyHolder holder, int position) {
            ListProducts data = listProducts.get(position);
            Glide.with(context).load(data.imagePath).into(holder.ProductImage);
            /*
            Item Name : CocaCola
Category name : Drinks
Describe : text text  ... read more
BarCode : 1234567890
ItemID : 871231293
Expire at : 11/11/2011 11:11:11"
             */
            String describe = data.description.substring(0, 50) + " ...";
            holder.ItemDetails.setText(
                            data.productName+"\n"+
                            describe+"\n"+
                            data.barCode+"\n"+
                            data.expiryDate +"\n"+
                            data.buyPrice+"$");
        }

        @Override
        public int getItemCount() {
            return listProducts.size();
        }
        class MyHolder extends RecyclerView.ViewHolder {
            ImageView ProductImage, EditProduct, DeleteProduct;
            TextView ItemDetails;
            private final Context context;


            public MyHolder(final View itemView) {

                super(itemView);
                context = itemView.getContext();

                final Intent[] intent = new Intent[1];
                ProductImage = (ImageView) itemView.findViewById(R.id.productImage);
                EditProduct = (ImageView) itemView.findViewById(R.id.editProduct);
                DeleteProduct = (ImageView) itemView.findViewById(R.id.deleteProduct);

                ItemDetails = (TextView) itemView.findViewById(R.id.itemDetails);


                EditProduct.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        intent[0] = new Intent(context, AddNewProduct.class);
                        intent[0].putExtra("categoryName", listProducts.get(getAdapterPosition()).categoryName);
                        intent[0].putExtra("categoryID", listProducts.get(getAdapterPosition()).categoryID);
                        intent[0].putExtra("productID", listProducts.get(getAdapterPosition()).productID);
                        context.startActivity(intent[0]);
                    }
                });

                DeleteProduct.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        final String ProductKey = listProducts.get(getAdapterPosition()).productID;
                        final String ProductImageName = listProducts.get(getAdapterPosition()).imageName;
                        String ProductName = listProducts.get(getAdapterPosition()).productName;

                        new android.app.AlertDialog.Builder(ActivityItemsView.this)
                                .setTitle("Delete Product")
                                .setMessage("Are you sure do you want to delete "+ ProductName+" ?")
                                .setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialogInterface, int i) {
                                        dialogInterface.dismiss();
                                        // FirebaseDatabase.getInstance().getReference().child("Products").child(productkey).removeValue();
                                        try{
                                            FirebaseStorage.getInstance().getReference().child("Products").child(ProductImageName).delete().addOnSuccessListener(new OnSuccessListener<Void>() {
                                                @Override
                                                public void onSuccess(Void aVoid) {
                                                    // File deleted successfully
                                                    Toast.makeText(ActivityItemsView.this, "Successful item removed", Toast.LENGTH_SHORT).show();
                                                    mDatabase.child(ProductKey).removeValue();
                                                }
                                            }).addOnFailureListener(new OnFailureListener() {
                                                @Override
                                                public void onFailure(@NonNull Exception exception) {
                                                    // Uh-oh, an error occurred!
                                                    Toast.makeText(ActivityItemsView.this, "try again item not removed", Toast.LENGTH_SHORT).show();
                                                }
                                            });

                                        /*
                                        StorageReference storageReference = FirebaseStorage.getInstance().getReference("gs://mercado-fikri.appspot.com");
                                        //getting the storage reference
                                        StorageReference sRef = storageReference;
                                        sRef.delete().addOnCompleteListener(new OnCompleteListener<Void>() {
                                            @Override
                                            public void onComplete(@NonNull Task<Void> task) {
                                                if(task.isSuccessful()){
                                                    Toast.makeText(CategoryActivity.this, "Successful image removed", Toast.LENGTH_SHORT).show();
                                                    mDatabase.child(CategoryKey).removeValue();
                                                }else{
                                                    Toast.makeText(CategoryActivity.this, "try again image not removed", Toast.LENGTH_SHORT).show();
                                                }
                                            }
                                        });
                                        */
                                            // FirebaseStorage.getInstance().getReference("gs://mercado-fikri.appspot.com").child(CategoryImageName).delete();

                                        }catch (Exception e){
                                            Toast.makeText(ActivityItemsView.this, "Error :" + e, Toast.LENGTH_SHORT).show();
                                        }
                                    }
                                })
                                .setNegativeButton(android.R.string.cancel, new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialogInterface, int i) {
                                        dialogInterface.dismiss();
                                    }
                                }).show();
                    }
                });


                itemView.setOnLongClickListener(new View.OnLongClickListener() {
                    @Override
                    public boolean onLongClick(View v) {
                        final String productID = listProducts.get(getAdapterPosition()).productID;
                        String productName = listProducts.get(getAdapterPosition()).productName;
                        String categoryName = listProducts.get(getAdapterPosition()).categoryName;

                        new AlertDialog.Builder(context)
                                .setTitle("Delete Product "+productName)
                                .setMessage("Are you sure want to delete " + productName +" From "+ categoryName + " ?")
                                .setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialogInterface, int i) {
                                        dialogInterface.dismiss();
                                        FirebaseDatabase.getInstance().getReference().child("Products").child(productID).removeValue();
                                    }})
                                .setNegativeButton(android.R.string.cancel, new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialogInterface, int i) {
                                        dialogInterface.dismiss();
                                    }
                                }).show();
                        return false;
                    }
                });

                itemView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        // dialog full details
                        final Dialog dialog = new Dialog(ActivityItemsView.this);
                        dialog.setContentView(R.layout.dialog_product_details);
                        ListProducts productDetail  = listProducts.get(getAdapterPosition());
                        ImageView imageView = (ImageView) dialog.findViewById(R.id.imageView);
                        TextView textView = (TextView) dialog.findViewById(R.id.textView);
                        ImageView cancelDialogBtn = (ImageView) dialog.findViewById(R.id.cancel_dialog);

                        String details = "Product Name: "+productDetail.productName+
                                "\nbarCode: "+productDetail.barCode+
                                "\nCategory Name: "+productDetail.categoryName+
                                "\nBuy Price: "+productDetail.buyPrice+
                                "\nSell Price: "+productDetail.sellPrice+
                                "\nDescribe: "+productDetail.description+
                                "\nExpiry Date"+productDetail.expiryDate+" "+productDetail.expiryTime+
                                "\nPost Date: "+productDetail.postDate+
                                "\nPackets at Stock: "+productDetail.availablePackets+
                                "\nSold Packets: "+productDetail.soldPackets;

                        textView.setText(details);
                        cancelDialogBtn.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                dialog.dismiss();
                            }
                        });
                        Glide.with(context).load(productDetail.imagePath).into(imageView);
                        dialog.show();
                    }
                });
            }
        }
    }
}