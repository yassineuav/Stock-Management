package tech.siham.stock_management.FragmentsSettings;

import android.app.Activity;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v7.app.AlertDialog;
import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.yarolegovich.lovelydialog.LovelyInfoDialog;
import com.yarolegovich.lovelydialog.LovelyProgressDialog;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import tech.siham.stock_management.Data.StaticConfig;
import tech.siham.stock_management.Model.Currency;
import tech.siham.stock_management.R;
import tech.siham.stock_management.utils.ImageUtils;

public class invoiceSettings extends Fragment {


    public invoiceSettings() {}

    private DatabaseReference mDatabase;
    ImageView editLogo;

    private LovelyProgressDialog waitingDialog;
    Spinner spinner;
    Button myCurrentCurrency;

    List<Currency> myCurrency = new ArrayList<>();
    String myCurrencySet = "";

    RadioGroup radioGroup;
    RadioButton usFormatRB, ukFormatRB;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_invoice_settings, container, false);

        waitingDialog = new LovelyProgressDialog(getContext());
        editLogo = (ImageView) root.findViewById(R.id.my_logo);
        myCurrentCurrency = (Button) root.findViewById(R.id.myCurrency);

        radioGroup = (RadioGroup) root.findViewById(R.id.radioGroup);
        usFormatRB = (RadioButton) root.findViewById(R.id.us_system_rbt);
        ukFormatRB = (RadioButton) root.findViewById(R.id.uk_system_rbt);

        mDatabase = FirebaseDatabase.getInstance().getReference("Stock").child(StaticConfig.UID);

        mDatabase.child("logo").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if(dataSnapshot.exists())
                    setImageLogo(dataSnapshot.getValue(String.class));
            }
            @Override
            public void onCancelled(DatabaseError databaseError) { }
        });

        mDatabase.child("currency").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if(dataSnapshot.exists())
                    myCurrentCurrency.setText("Your Currency is "+dataSnapshot.getValue(String.class));
            }
            @Override
            public void onCancelled(DatabaseError databaseError) { }
        });

        mDatabase.child("dateFormat").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    String data = dataSnapshot.getValue(String.class);
                    if(data.equals("UK")){
                        usFormatRB.setChecked(false);
                        ukFormatRB.setChecked(true);
                    }else if(data.equals("US")){
                        usFormatRB.setChecked(true);
                        ukFormatRB.setChecked(false);
                    }
                }
            }
            @Override
            public void onCancelled(DatabaseError databaseError) { }
        });


        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                if(checkedId == R.id.us_system_rbt){
                    mDatabase.child("format").setValue("US");
                }else if(checkedId == R.id.uk_system_rbt){
                    mDatabase.child("format").setValue("UK");
                }
            }
        });

        editLogo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new AlertDialog.Builder(getContext())
                        .setTitle("My Logo")
                        .setMessage("Are you sure want to change Logo?")
                        .setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                Intent intent = new Intent();
                                intent.setType("image/*");
                                intent.setAction(Intent.ACTION_PICK);
                                startActivityForResult(Intent.createChooser(intent, "Select Picture"), 782);
                                dialogInterface.dismiss();
                            }
                        })
                        .setNegativeButton(android.R.string.cancel, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                dialogInterface.dismiss();
                            }
                        }).show();
            }
        });

        myCurrentCurrency.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // show dialog to connect bluetooth
                final Dialog dialog = new Dialog(getContext());
                dialog.setContentView(R.layout.dialog_edit_currency);
                Button btnCancel = (Button) dialog.findViewById(R.id.cancel_dialog);
                Button btnSave = (Button) dialog.findViewById(R.id.save);
                final EditText ETCurrency = (EditText) dialog.findViewById(R.id.edit_text);
                spinner = (Spinner) dialog.findViewById(R.id.spinner);

                // click button to
                // get currency from db if not exist set default most four;
                try {
                    JSONObject jsonObject = new JSONObject(loadJSONFromAsset());
                    Iterator<String> keys = jsonObject.keys();
                    while(keys.hasNext()) {
                        String key = keys.next();
                        Currency currency = new Currency();
                        // currency.currencyName = jsonObject.getJSONObject(key).getString("name_plural");
                        currency.currencyCode = jsonObject.getJSONObject(key).getString("code");
                        currency.currencySymbol = jsonObject.getJSONObject(key).getString("symbol_native");
                        myCurrency.add(currency);

                    }

                    CustomAdapter customAdapter=new CustomAdapter(myCurrency);
                    spinner.setAdapter(customAdapter);
                    spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                        @Override
                        public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                            myCurrencySet = myCurrency.get(position).currencySymbol;
                        }
                        @Override
                        public void onNothingSelected(AdapterView<?> parent) { }
                    });

                } catch (JSONException e) {
                    e.printStackTrace();
                }


                dialog.show();
                btnSave.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if(myCurrencySet.equals("one")) {
                            if (ETCurrency.getText().toString().trim().isEmpty()) {
                                ETCurrency.setError("Please type your currency\nor select one from drop spinner!\nLike $ or € ...");
                            }else{
                                myCurrencySet = ETCurrency.getText().toString().trim();
                                mDatabase.child("currency").setValue(myCurrencySet);
                                dialog.dismiss();
                            }
                        }else{
                            mDatabase.child("currency").setValue(myCurrencySet);
                            dialog.dismiss();
                        }
                    }
                });
                btnCancel.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        dialog.dismiss();
                    }
                });
            }
        });

        return root;
    }

    private void setImageLogo(String imgBase64){
        try {
            Resources res = getResources();
            Bitmap src;
            if (imgBase64.equals("default")) {
                src = BitmapFactory.decodeResource(res, R.drawable.logo_invoice);
            } else {
                byte[] decodedString = Base64.decode(imgBase64, Base64.DEFAULT);
                src = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
            }
            editLogo.setImageBitmap(src);
        }catch (Exception e){ }
    }


    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 782 && resultCode == Activity.RESULT_OK) {
            if (data == null) {
                Toast.makeText(getContext(), "error : result code null", Toast.LENGTH_LONG).show();
                return;
            }
            try {
                InputStream inputStream = getContext().getContentResolver().openInputStream(data.getData());
                Bitmap imgBitmap = BitmapFactory.decodeStream(inputStream);
                imgBitmap = ImageUtils.cropToSquare(imgBitmap);
                InputStream is = ImageUtils.convertBitmapToInputStream(imgBitmap);
                final Bitmap liteImage = ImageUtils.makeImageLite(is,
                        imgBitmap.getWidth(), imgBitmap.getHeight(),
                        ImageUtils.AVATAR_WIDTH_LOGO, ImageUtils.AVATAR_HEIGHT_LOGO);

                String imageBase64 = ImageUtils.encodeBase64(liteImage);
               // set change to sharedPreferance
                waitingDialog.setCancelable(false)
                        .setTitle("Avatar updating....")
                        .setTopColorRes(R.color.colorPrimary)
                        .show();

                mDatabase.child("logo").setValue(imageBase64)
                        .addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {
                                if(task.isSuccessful()){

                                    waitingDialog.dismiss();
                                    //editLogo.setImageDrawable(ImageUtils.roundedImage(getContext(), liteImage));

                                    new LovelyInfoDialog(getContext())
                                            .setTopColorRes(R.color.colorPrimary)
                                            .setTitle("Success")
                                            .setMessage("Update avatar successfully!")
                                            .show();
                                }
                            }
                        })
                        .addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                waitingDialog.dismiss();
                                Log.d("Update Avatar", "failed");
                                new LovelyInfoDialog(getContext())
                                        .setTopColorRes(R.color.colorAccent)
                                        .setTitle("False")
                                        .setMessage("False to update avatar")
                                        .show();
                            }
                        });
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
        }
    }
    class CustomAdapter extends BaseAdapter {
        List<Currency> myCurrency = new ArrayList<>();
        LayoutInflater inflter;

        public CustomAdapter(List<Currency> myCurrency) {
            this.myCurrency = myCurrency;
            inflter = (LayoutInflater.from(getContext()));
        }
        @Override
        public int getCount() {
            return myCurrency.size();
        }

        @Override
        public Object getItem(int i) {
            return null;
        }

        @Override
        public long getItemId(int i) {
            return 0;
        }

        @Override
        public View getView(int i, View view, ViewGroup viewGroup) {
            view = inflter.inflate(R.layout.spinner_currency_custom, null);
            TextView symbol = (TextView) view.findViewById(R.id.symbol);
            TextView name = (TextView) view.findViewById(R.id.name);
            TextView code = (TextView) view.findViewById(R.id.code);
            name.setText(myCurrency.get(i).currencyName);
            symbol.setText(myCurrency.get(i).currencySymbol);
            code.setText(myCurrency.get(i).currencyCode);
            return view;
        }
    }

    public String loadJSONFromAsset() {
        String json = null;
        try {
            InputStream is = getActivity().getAssets().open("Common-Currency.json");
            int size = is.available();
            byte[] buffer = new byte[size];
            is.read(buffer);
            is.close();
            json = new String(buffer, "UTF-8");
        } catch (IOException ex) {
            ex.printStackTrace();
            return null;
        }
        return json;
    }
}
