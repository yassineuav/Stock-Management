package tech.siham.stock_management.Model;

public class MyBasket {
  //public ListProducts listProducts;
  public String basketID;
  public String productID;
  public String categoryID;
  public String imagePath;
  public String productName;
  public String categoryName;
  public String describe;
  public double normalPrice;
  public int packets;
  public int unities;
  public int position;
  public String barCode;
  public double price;
  public double total;
  public String status;
  // scanned | error scan number not matched
  // | product not exist | product exist |
  // quantity shortage | done | pending | ...
  public MyBasket(){
    // listProducts = new ListProducts();
  }
}