package tech.siham.stock_management.utils;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Base64;

import tech.siham.stock_management.R;

public class setImageAvatar {
    public setImageAvatar(Context context, String imgBase64, int target){
        try {
            Resources res = context.getResources();
            Bitmap src;
            if (imgBase64.equals("default")) {
                src = BitmapFactory.decodeResource(res, R.drawable.default_avata);
            } else {
                byte[] decodedString = Base64.decode(imgBase64, Base64.DEFAULT);
                src = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
            }

            //((CircleImageView) ->findViewById(target)<- ).setImageDrawable(ImageUtils.roundedImage(context, src));

            //((CircleImageView) findViewById(R.id.imageProfile)).setImageDrawable(ImageUtils.roundedImage(context, src));
        }catch (Exception e){ }
    }
}
