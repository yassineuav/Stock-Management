package tech.siham.stock_management.FragmentsSettings;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import tech.siham.stock_management.Data.SharedPreferenceHelper;
import tech.siham.stock_management.Data.StaticConfig;
import tech.siham.stock_management.R;

public class LanguageFragment extends Fragment {


    public LanguageFragment() { }

    RadioButton rbEnglish, rbSpanish, rbFrance,  rbArabic;
    private DatabaseReference mDatabase;
    String myLanguage = "English";// English, Arabic, France, Spanish

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_language, container, false);

        SharedPreferenceHelper db = SharedPreferenceHelper.getInstance(getContext());

        myLanguage = db.getUserInfo().language;

        RadioGroup radioGroup = root.findViewById(R.id.radioGroup);
        rbEnglish = (RadioButton) root.findViewById(R.id.rb_English);
        rbSpanish = (RadioButton) root.findViewById(R.id.rb_Spanish);
        rbFrance = (RadioButton) root.findViewById(R.id.rb_France);
        rbArabic = (RadioButton) root.findViewById(R.id.rb_Arabic);

        checkRB();

        mDatabase = FirebaseDatabase.getInstance().getReference("Stock").child(StaticConfig.UID);

        mDatabase.child("language").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if(dataSnapshot.exists()){
                    myLanguage = dataSnapshot.getValue(String.class);
                }
            }
            @Override
            public void onCancelled(DatabaseError databaseError) { }
        });

        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {

                switch (checkedId){
                    case R.id.rb_English:
                        myLanguage = "English";
                        break;
                    case R.id.rb_Spanish:
                        myLanguage = "Spanish";
                        break;
                    case R.id.rb_France:
                        myLanguage = "France";
                        break;
                    case R.id.rb_Arabic:
                        myLanguage = "Arabic";
                        break;
                }
                mDatabase.child("language").setValue(myLanguage);
                checkRB();
            }
        });

        return root;
    }

    private void checkRB(){

        rbEnglish.setChecked(false);
        rbSpanish.setChecked(false);
        rbFrance.setChecked(false);
        rbArabic.setChecked(false);

        switch (myLanguage){
            case "English":
                rbEnglish.setChecked(true);
                break;
            case "Spanish":
                rbSpanish.setChecked(true);
                break;
            case "France":
                rbFrance.setChecked(true);
                break;
            case "Arabic":
                rbArabic.setChecked(true);
                break;
        }
    }

}
