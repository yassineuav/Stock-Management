package tech.siham.stock_management.ui;

import android.annotation.TargetApi;
import android.app.Activity;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.location.Address;
import android.location.Geocoder;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.TextInputLayout;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.util.Base64;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import tech.siham.stock_management.Data.SharedPreferenceHelper;
import tech.siham.stock_management.Data.StaticConfig;
import tech.siham.stock_management.MainActivity;
import tech.siham.stock_management.Model.User;
import tech.siham.stock_management.R;
import tech.siham.stock_management.services.LocationTrack;
import tech.siham.stock_management.utils.ImageUtils;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import de.hdodenhof.circleimageview.CircleImageView;

import static android.Manifest.permission.ACCESS_COARSE_LOCATION;
import static android.Manifest.permission.ACCESS_FINE_LOCATION;

public class setProfile extends AppCompatActivity {

    EditText FullName, EtAddress, EtName, PhoneNumber, EmailTxt;
    CircleImageView Avatar;
    private DatabaseReference mDatabase;

    SharedPreferenceHelper shR;

    User myAccount;
    Button coordinatesBtn;
    private static final int PICK_IMAGE = 1994;

    double latitude = 0.0;
    double longitude = 0.0;

    private ArrayList<String> permissionsToRequest;
    private ArrayList<String> permissionsRejected = new ArrayList<>();
    private ArrayList<String> permissions = new ArrayList<>();

    private final static int ALL_PERMISSIONS_RESULT = 101;
    LocationTrack locationTrack;

    private Spinner spinner;

    String orderFrom = "";
    Dialog dialog_location;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_set_profile);

        Avatar = (CircleImageView) findViewById(R.id.img_avatar);
        FullName = (EditText) findViewById(R.id.et_full_name);
        EtAddress = (EditText) findViewById(R.id.et_store_address);
        EtName = (EditText) findViewById(R.id.et_store_name);
        PhoneNumber = (EditText) findViewById(R.id.et_Phone_Number);
        EmailTxt = (EditText) findViewById(R.id.et_EmailTxt);
        coordinatesBtn = (Button) findViewById(R.id.coordinatesBtn);

        spinner = (Spinner) findViewById(R.id.spinner);
        final List<String> list = new ArrayList<String>();
        list.add("Stock");
        list.add("Store");
        list.add("Deliver");

        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, list);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(dataAdapter);
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                orderFrom = list.get(position);
                ((TextInputLayout) findViewById(R.id.store_address)).setHint(orderFrom + " Address");
                ((TextInputLayout) findViewById(R.id.store_name)).setHint(orderFrom + " Name");
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });

        shR = SharedPreferenceHelper.getInstance(this);
        myAccount = new User();
        myAccount = shR.getUserInfo();



        FullName.setText(myAccount.fullName);
        EtAddress.setText(myAccount.address);
        PhoneNumber.setText(myAccount.phoneNumber);
        EmailTxt.setText(myAccount.email);

        permissions.add(ACCESS_FINE_LOCATION);
        permissions.add(ACCESS_COARSE_LOCATION);

        permissionsToRequest = findUnAskedPermissions(permissions);
        //get the permissions we have asked for before but are not granted..
        //we will store this in a global list to access later.


        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (permissionsToRequest.size() > 0)
                requestPermissions(permissionsToRequest.toArray(new String[permissionsToRequest.size()]), ALL_PERMISSIONS_RESULT);
        }

        mDatabase = FirebaseDatabase.getInstance().getReference("Stock");
        mDatabase.child(myAccount.adminID).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    myAccount = dataSnapshot.getValue(User.class);
                    FullName.setText(myAccount.fullName);
                    EtAddress.setText(myAccount.address);
                    EtName.setText(myAccount.storeName);
                    PhoneNumber.setText(myAccount.phoneNumber);
                    EmailTxt.setText(myAccount.email);
                    setImageAvatar(myAccount.avatar);
                    latitude = myAccount.coordinates.latitude;
                    longitude = myAccount.coordinates.longitude;
                } else {
                    msg("no data exist!!!");
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) { }
        });

        Avatar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new AlertDialog.Builder(setProfile.this)
                        .setTitle("Avatar")
                        .setMessage("Are you sure want to change avatar profile?")
                        .setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {

                                Intent intent = new Intent();
                                intent.setType("image/*");
                                intent.setAction(Intent.ACTION_GET_CONTENT);
                                startActivityForResult(Intent.createChooser(intent, "Select Picture"), PICK_IMAGE);
                                dialogInterface.dismiss();
                            }
                        })
                        .setNegativeButton(android.R.string.cancel, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                dialogInterface.dismiss();
                            }
                        }).show();
            }
        });

        EtAddress.setFocusableInTouchMode(false);
        EtAddress.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                final Dialog dialog_address = new Dialog(setProfile.this);
                dialog_address.setContentView(R.layout.dialog_add_edit_address);
                Button dialogButtonDone = (Button) dialog_address.findViewById(R.id.done_dialog);
                Button dialogButtonCancel = (Button) dialog_address.findViewById(R.id.cancel_dialog);

                final EditText inputStreet = (EditText) dialog_address.findViewById(R.id.et_street);
                final EditText inputCity = (EditText) dialog_address.findViewById(R.id.et_city);
                final EditText inputState = (EditText) dialog_address.findViewById(R.id.et_state);
                final EditText inputZipCode = (EditText) dialog_address.findViewById(R.id.et_zip_code);

                inputStreet.setText(myAccount.myAddress.street);
                inputCity.setText(myAccount.myAddress.city);
                inputState.setText(myAccount.myAddress.state);
                inputZipCode.setText(myAccount.myAddress.zipCode);

                dialogButtonDone.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String newStreet = inputStreet.getText().toString();
                        String newCity = inputCity.getText().toString();
                        String newState = inputState.getText().toString();
                        String newZipCode = inputZipCode.getText().toString();

                        if (newStreet.isEmpty()) {
                            inputStreet.setError("set Street name");
                            inputStreet.setBackground(getResources().getDrawable(R.drawable.bt_shape_red));
                        } else if (newCity.isEmpty()) {
                            inputCity.setError("set City name");
                            inputCity.setBackground(getResources().getDrawable(R.drawable.bt_shape_red));
                        } else if (newState.isEmpty()) {
                            inputState.setError("set State name");
                            inputState.setBackground(getResources().getDrawable(R.drawable.bt_shape_red));
                        } else if (newZipCode.isEmpty()) {
                            inputZipCode.setError("set your zip code");
                            inputZipCode.setBackground(getResources().getDrawable(R.drawable.bt_shape_red));
                        } else {
                            myAccount.myAddress.street = newStreet;
                            myAccount.myAddress.city = newCity;
                            myAccount.myAddress.state = newState;
                            myAccount.myAddress.zipCode = newZipCode;
                            myAccount.address = newStreet + " ," + newCity + " ," + newState + " ," + newZipCode;
                            EtAddress.setText(myAccount.address);
                            dialog_address.dismiss();
                        }
                    }
                });
                dialogButtonCancel.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        dialog_address.dismiss();
                    }
                });
                dialog_address.show();
            }
        });

        coordinatesBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog_location.show();
            }
        });

        dialog_location = new Dialog(setProfile.this);
        dialog_location.setContentView(R.layout.dialog_set_location);
        Button dialogButtonGetCurrentLocation = (Button) dialog_location.findViewById(R.id.current_location);
        Button dialogButtonGetFromMap = (Button) dialog_location.findViewById(R.id.get_location_from_map);
        Button dialogButtonCancel = (Button) dialog_location.findViewById(R.id.cancel_dialog);

        dialogButtonGetCurrentLocation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    ProgressDialog progressDialog = new ProgressDialog(setProfile.this);
                    progressDialog.setIndeterminate(true);
                    progressDialog.setCancelable(false);
                    progressDialog.setMessage("Getting Location ...");
                    progressDialog.show();
                    locationTrack = new LocationTrack(setProfile.this);
                    if (locationTrack.canGetLocation()) {
                        longitude = locationTrack.getLongitude();
                        latitude = locationTrack.getLatitude();
                        //String storeAddress = getAddressByCoordinates(latitude, longitude);
                        //EtAddress.setText(storeAddress);
                        Toast.makeText(setProfile.this,
                                "Location set successfully ..."+
                                        "\nLongitude:" + Double.toString(longitude) +
                                        "\nLatitude:" + Double.toString(latitude),
                                Toast.LENGTH_SHORT).show();
                        progressDialog.dismiss();
                        dialog_location.dismiss();
                    } else {
                        dialog_location.dismiss();
                        progressDialog.dismiss();
                        locationTrack.showSettingsAlert();
                    }
                } catch (Exception e) {
                    Toast.makeText(setProfile.this, "Error : " + e, Toast.LENGTH_SHORT).show();
                }
            }
        });
        dialogButtonGetFromMap.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivityForResult(new Intent(setProfile.this, getLocationAndAddress.class), 2300);
            }
        });
        dialogButtonCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog_location.dismiss();
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_add, menu);
        return true;
    }

    void setImageAvatar(String imgBase64) {
        try {
            Resources res = getResources();
            Bitmap src;
            if (imgBase64.equals("default")) {
                src = BitmapFactory.decodeResource(res, R.drawable.default_avata);
            } else {
                byte[] decodedString = Base64.decode(imgBase64, Base64.DEFAULT);
                src = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
            }
            Avatar.setImageDrawable(ImageUtils.roundedImage(setProfile.this, src));
        } catch (Exception e) { }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_IMAGE && resultCode == Activity.RESULT_OK) {
            if (data == null) { return; }
            try {
                InputStream inputStream = getContentResolver().openInputStream(data.getData());
                Bitmap imgBitmap = BitmapFactory.decodeStream(inputStream);
                imgBitmap = ImageUtils.cropToSquare(imgBitmap);
                InputStream is = ImageUtils.convertBitmapToInputStream(imgBitmap);
                final Bitmap liteImage = ImageUtils.makeImageLite(is,
                        imgBitmap.getWidth(), imgBitmap.getHeight(),
                        ImageUtils.AVATAR_WIDTH, ImageUtils.AVATAR_HEIGHT);

                String imageBase64 = ImageUtils.encodeBase64(liteImage);
                myAccount.avatar = imageBase64;
                setImageAvatar(myAccount.avatar);
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
        } else if (requestCode == 2300 && resultCode == RESULT_OK) {
            latitude = data.getDoubleExtra("latitude", 0.0);
            longitude = data.getDoubleExtra("longitude", 0.0);
            //EtAddress.setText(data.getStringExtra("address"));
        }
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == android.R.id.home) {
            onBackPressed();
            return true;
        } else if (id == R.id.save) {

            // all field mandatory
            final User user = new User();
            // user.adminID = DistributorsList.get(positionList).adminID;
            user.adminID = StaticConfig.UID;
            user.avatar = myAccount.avatar;
            user.logo = myAccount.avatar;
            user.orderFrom = orderFrom;
            user.address = EtAddress.getText().toString().trim();

            user.myAddress.street = myAccount.myAddress.street;
            user.myAddress.city = myAccount.myAddress.city;
            user.myAddress.state = myAccount.myAddress.state;
            user.myAddress.zipCode = myAccount.myAddress.zipCode;

            user.storeName = EtName.getText().toString().trim();
            user.phoneNumber = PhoneNumber.getText().toString().trim();
            user.email = EmailTxt.getText().toString().trim();
            user.fullName = FullName.getText().toString().trim();
            user.accountStatus = "done";
            user.coordinates.longitude = longitude;
            user.coordinates.latitude = latitude;
            user.currency = "$";
            user.format = "US";
            user.orderPriceMin = 0;
            user.availableForOrders = "on";
            user.availableForDelivery = "on";
            user.ordersAvailableArea = 50;


            if (!TextUtils.isEmpty(user.fullName)) {
                FullName.setBackground(getResources().getDrawable(R.drawable.bt_shape_green));
            } else if (!TextUtils.isEmpty(user.email)) {
                EmailTxt.setBackground(getResources().getDrawable(R.drawable.bt_shape_green));
            } else if (!TextUtils.isEmpty(user.phoneNumber)) {
                PhoneNumber.setBackground(getResources().getDrawable(R.drawable.bt_shape_green));
            } else if (!TextUtils.isEmpty(user.address)) {
                PhoneNumber.setBackground(getResources().getDrawable(R.drawable.bt_shape_green));
            } else if (!TextUtils.isEmpty(user.storeName)) {
                EtName.setBackground(getResources().getDrawable(R.drawable.bt_shape_green));
            }

            if (TextUtils.isEmpty(user.fullName)) {
                FullName.setError("Please set your full name");
                FullName.setBackground(getResources().getDrawable(R.drawable.bt_shape_red));
            } else if (TextUtils.isEmpty(user.email)) {
                EmailTxt.setError("Please set your email");
                EmailTxt.setBackground(getResources().getDrawable(R.drawable.bt_shape_green));
            } else if (TextUtils.isEmpty(user.orderFrom)) {
                msg("please!!\nselect type of usage... Store, Stock, Deliver !");
                // spinner.setError("Please set your email");
            } else if (TextUtils.isEmpty(user.phoneNumber)){
                PhoneNumber.setBackground(getResources().getDrawable(R.drawable.bt_shape_red));
                PhoneNumber.setError("Please set your phone number");
            } else if (TextUtils.isEmpty(user.address)) {
                EtAddress.setBackground(getResources().getDrawable(R.drawable.bt_shape_red));
                EtAddress.setError("Please set your address");
            } else if (TextUtils.isEmpty(user.storeName)) {
                EtName.setBackground(getResources().getDrawable(R.drawable.bt_shape_red));
                EtName.setError("Please set your "+orderFrom+" name");
            }else if (latitude == 0.0 && longitude == 0.0) {
                //show dialog
                dialog_location.show();
                // msg("Show dialog to add location lat and long");
            } else {
                mDatabase.child(StaticConfig.UID).setValue(user).addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if (task.isSuccessful()) {
                            shR.saveUserInfo(user);
                            startActivity(new Intent(setProfile.this, MainActivity.class));
                            finish();
                        } else {
                            msg("Try Again Data not Added");
                        }
                    }
                });

            }
        }
        return super.onOptionsItemSelected(item);
    }

    void msg(String txt) {
        Toast.makeText(setProfile.this, txt, Toast.LENGTH_LONG).show();
    }


    public String getAddressByCoordinates(double latitude, double longitude) {
        String fullAddress = "";
        try {
            Geocoder geocoder = new Geocoder(this, Locale.ENGLISH);
            List<Address> addresses = geocoder.getFromLocation(latitude, longitude, 1);
            StringBuilder str = new StringBuilder();
            if (geocoder.isPresent()) {
                Toast.makeText(this, "waite ... geo coder present", Toast.LENGTH_SHORT).show();
                Address returnAddress = addresses.get(0);
                String streetName = returnAddress.getFeatureName();
                String state = returnAddress.getAdminArea();
                String localityString = returnAddress.getLocality();
                String city = returnAddress.getCountryName();
                String zipCode = returnAddress.getPostalCode();
                str.append(streetName + ", ");
                str.append(city + ", ");
                str.append(state + ", ");
                str.append(zipCode);
                EtAddress.setText(str.toString());
                fullAddress = str.toString();
            } else {
                Toast.makeText(this, "geo coder not present", Toast.LENGTH_SHORT).show();
            }
        } catch (IOException e) {
            Toast.makeText(this, "error in geo coder  " + e, Toast.LENGTH_SHORT).show();
        }
        return fullAddress;
    }


         ArrayList<String> findUnAskedPermissions (ArrayList < String > wanted) {
            ArrayList<String> result = new ArrayList<String>();
            for (String perm : wanted) {
                if (!hasPermission(perm)) {
                    result.add(perm);
                }
            }
            return result;
        }


        private boolean hasPermission (String permission){
            if (canMakeSmores()) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    return (checkSelfPermission(permission) == PackageManager.PERMISSION_GRANTED);
                }
            }
            return true;
        }
        private boolean canMakeSmores () {
            return (Build.VERSION.SDK_INT > Build.VERSION_CODES.LOLLIPOP_MR1);
        }


        @TargetApi(Build.VERSION_CODES.M)
        @Override
        public void onRequestPermissionsResult ( int requestCode, String[] permissions,
        int[] grantResults){
            switch (requestCode) {
                case ALL_PERMISSIONS_RESULT:
                    for (String perms : permissionsToRequest) {
                        if (!hasPermission(perms)) {
                            permissionsRejected.add(perms);
                        }
                    }
                    if (permissionsRejected.size() > 0) {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                            if (shouldShowRequestPermissionRationale(permissionsRejected.get(0))) {
                                showMessageOKCancel("These permissions are mandatory for the application. Please allow access.",
                                        new DialogInterface.OnClickListener() {
                                            @Override
                                            public void onClick(DialogInterface dialog, int which) {
                                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                                                    requestPermissions(permissionsRejected.toArray(new String[permissionsRejected.size()]), ALL_PERMISSIONS_RESULT);
                                                }
                                            }
                                        });
                                return;
                            }
                        }
                    }
                    break;
            }
        }

        private void showMessageOKCancel (String message, DialogInterface.OnClickListener okListener) {
            new AlertDialog.Builder(setProfile.this)
                    .setMessage(message)
                    .setPositiveButton("OK", okListener)
                    .setNegativeButton("Cancel", null)
                    .create()
                    .show();
        }
        @Override
        protected void onDestroy () {
            super.onDestroy();
            locationTrack.stopListener();
        }
    }
