package tech.siham.stock_management.Data;

import android.content.Context;
import android.content.SharedPreferences;
import tech.siham.stock_management.Model.User;

public class SharedPreferenceHelper {

  private static SharedPreferenceHelper instance = null;
  private static SharedPreferences preferences;
  private static SharedPreferences.Editor editor;

  private static String SHARE_USER_INFO = "UserInformation";

  private static String SHARE_KEY_NAME = "fullName";
  private static String SHARE_KEY_EMAIL = "email";
  private static String SHARE_KEY_AVATAR = "avatar";
  private static String SHARE_KEY_UID = "uid";
  private static String SHARE_KEY_PHONE_NUMBER = "phoneNumber";
  private static String SHARE_KEY_ADDRESS = "address";
  private static String SHARE_KEY_LOGO = "logo";
  private static String SHARE_KEY_LANGUAGE = "language";
  private static String SHARE_KEY_CURRENCY = "currency";
  private static String SHARE_KEY_FORMAT = "format";
  private static String SHARE_KEY_ADDRESS_STREET = "street";
  private static String SHARE_KEY_ADDRESS_CITY = "city";
  private static String SHARE_KEY_ADDRESS_STATE = "state";
  private static String SHARE_KEY_ADDRESS_ZIP_CODE = "zipCode";
  private static String SHARE_KEY_STAR = "star";
  private static String SHARE_KEY_ORDER_FROM = "orderFrom";
  private static String SHARE_KEY_COORDINATES = "coordinates";
  private static String SHARE_KEY_LATITUDE = "latitude";
  private static String SHARE_KEY_LONGITUDE = "longitude";
  private static String SHARE_KEY_BARCODE_SCANNER = "barCodeScanner";

  private static String SHARE_KEY_STORE_NAME = "storeName";
  private static String SHARE_KEY_ACCOUNT_STATUS = "accountStatus";

  private SharedPreferenceHelper() {
  }

  public static SharedPreferenceHelper getInstance(Context context) {
    if (instance == null) {
      instance = new SharedPreferenceHelper();
      preferences = context.getSharedPreferences(SHARE_USER_INFO, Context.MODE_PRIVATE);
      editor = preferences.edit();
    }
    return instance;
  }

  public void saveUserInfo(User user) {
    editor.putString(SHARE_KEY_NAME, user.fullName);
    editor.putString(SHARE_KEY_EMAIL, user.email);
    editor.putString(SHARE_KEY_AVATAR, user.avatar);
    editor.putFloat(SHARE_KEY_STAR, user.star);
    editor.putString(SHARE_KEY_LOGO, user.logo);
    editor.putString(SHARE_KEY_LANGUAGE, user.language);
    editor.putString(SHARE_KEY_CURRENCY, user.currency);
    editor.putString(SHARE_KEY_FORMAT, user.format);
    editor.putString(SHARE_KEY_ORDER_FROM, user.orderFrom);
    editor.putString(SHARE_KEY_ADDRESS, user.address);
    editor.putString(SHARE_KEY_ADDRESS_STREET, user.myAddress.street);
    editor.putString(SHARE_KEY_ADDRESS_CITY, user.myAddress.city);
    editor.putString(SHARE_KEY_ADDRESS_STATE, user.myAddress.state);
    editor.putString(SHARE_KEY_ADDRESS_ZIP_CODE, user.myAddress.zipCode);
    editor.putString(SHARE_KEY_STORE_NAME, user.storeName);
    editor.putString(SHARE_KEY_ACCOUNT_STATUS, user.accountStatus);
    editor.putString(SHARE_KEY_PHONE_NUMBER, user.phoneNumber);
    editor.putString(SHARE_KEY_LATITUDE, String.valueOf(user.coordinates.latitude));
    editor.putString(SHARE_KEY_LONGITUDE, String.valueOf(user.coordinates.longitude));
    editor.putString(SHARE_KEY_UID, StaticConfig.UID);
    editor.putBoolean(SHARE_KEY_BARCODE_SCANNER, user.useCamera);
    editor.commit();
  }

  public void saveUID(String UID) {
    editor.putString(SHARE_KEY_UID, UID);
    editor.commit();
  }

  public User getUserInfo() {
    User user = new User();

    user.fullName = preferences.getString(SHARE_KEY_NAME, "");
    user.email = preferences.getString(SHARE_KEY_EMAIL, "");
    user.orderFrom = preferences.getString(SHARE_KEY_ORDER_FROM, "");
    user.avatar = preferences.getString(SHARE_KEY_AVATAR, "");
    user.star = preferences.getFloat(SHARE_KEY_STAR, 0);
    user.coordinates.longitude = Double.parseDouble(preferences.getString(SHARE_KEY_LONGITUDE, "0"));
    user.coordinates.latitude = Double.parseDouble(preferences.getString(SHARE_KEY_LATITUDE, "0"));
    user.adminID = preferences.getString(SHARE_KEY_UID, "");
    user.accountStatus = preferences.getString(SHARE_KEY_ACCOUNT_STATUS, "");
    user.address = preferences.getString(SHARE_KEY_ADDRESS, "");
    user.logo = preferences.getString(SHARE_KEY_LOGO, "");
    user.language = preferences.getString(SHARE_KEY_LANGUAGE, "English");
    user.currency = preferences.getString(SHARE_KEY_CURRENCY, "$");
    user.format = preferences.getString(SHARE_KEY_FORMAT, "UK");
    user.myAddress.street = preferences.getString(SHARE_KEY_ADDRESS_STREET, "");
    user.myAddress.state = preferences.getString(SHARE_KEY_ADDRESS_STATE, "");
    user.myAddress.city = preferences.getString(SHARE_KEY_ADDRESS_CITY, "");
    user.myAddress.zipCode = preferences.getString(SHARE_KEY_ADDRESS_ZIP_CODE, "");

    user.storeName = preferences.getString(SHARE_KEY_STORE_NAME, "");
    user.phoneNumber = preferences.getString(SHARE_KEY_PHONE_NUMBER, "");
    user.useCamera = preferences.getBoolean(SHARE_KEY_BARCODE_SCANNER, true);
    return user;
  }

  public String getUID() {
    return preferences.getString(SHARE_KEY_UID, "");
  }

  public void useCamera(boolean status) {
    editor.putBoolean(SHARE_KEY_BARCODE_SCANNER,status);
    editor.apply();
  }

  public Boolean useCamera(){
    return preferences.getBoolean(SHARE_KEY_BARCODE_SCANNER, true);
  }
}