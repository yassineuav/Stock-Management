package tech.siham.stock_management.Model;

public class MySupplier {
    public MySupplier(){}
    public String myID;
    public String id;
    public String supplierID;
    public String status;
    public int ordersDone;
    public int ordersPending;
    public long timestamp;
}
