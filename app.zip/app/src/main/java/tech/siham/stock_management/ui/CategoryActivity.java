package tech.siham.stock_management.ui;

import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.annotation.RequiresApi;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.content.FileProvider;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.MimeTypeMap;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import tech.siham.stock_management.Data.SharedPreferenceHelper;
import tech.siham.stock_management.Data.StaticConfig;
import tech.siham.stock_management.Model.Category;
import tech.siham.stock_management.R;

import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class CategoryActivity extends AppCompatActivity {

    // show categories
    //recyclerview object
    private RecyclerView recyclerView;
    //adapter object
    private RecyclerView.Adapter adapter;
    //database reference
    private DatabaseReference mDatabase;
    //progress dialog
    private ProgressDialog progressDialog;
    //list to hold all the uploaded images
    private List<Category> categories  = new ArrayList<>();

    // add and edit category
    //constant to track image chooser intent
    private static final int PICK_IMAGE_REQUEST = 2340;
    static final int REQUEST_PICTURE_CAPTURE = 1829;
    private String pictureFilePath;
    private Uri filePath;
    public String ImageName = "";
    private StorageReference storageReference;
    public Category EditCategory;
    EditText CategoryName;
    FrameLayout addImageCategory;
    ImageView imageCategory;
    LinearLayout DialogSelectImage;
    Dialog dialog;
    ValueEventListener checkIfAlreadyExist = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_category);
        //getActionBar().setTitle("Categories");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle("My Categories");
        // provide compatibility to all the versions
        // setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        recyclerView = (RecyclerView) findViewById(R.id.recyclerView);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new GridLayoutManager(CategoryActivity.this, 4));

        progressDialog = new ProgressDialog(this);

        //displaying progress dialog while fetching images
        progressDialog.setMessage("Please wait...");
        progressDialog.show();
        mDatabase = FirebaseDatabase.getInstance().getReference("Categories");
        storageReference = FirebaseStorage.getInstance().getReference("Categories");

        //adding an event listener to fetch values
        mDatabase.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                //dismissing the progress dialog
                progressDialog.dismiss();
                categories.clear();
                if(snapshot.exists()){
                    //iterating through all the values in database
                    for (DataSnapshot postSnapshot : snapshot.getChildren()) {
                        Category upload = postSnapshot.getValue(Category.class);
                        if(upload.adminID.equals(StaticConfig.UID)){
                            upload.itemsNumber = postSnapshot.child("Products").getChildrenCount();
                            categories.add(upload);
                        }
                    }
                    //creating adapter
                    adapter = new MyAdapter(getApplicationContext(), categories);
                    adapter.notifyDataSetChanged();
                    recyclerView.setAdapter(adapter);
                }
                TextView noCategory = (TextView) findViewById(R.id.noCategoryFound);

                if(categories.isEmpty()){
                    noCategory.setVisibility(View.VISIBLE);
                    addEditCategory(null, null);
                }else{
                    noCategory.setVisibility(View.GONE);
                }
            }
            @Override
            public void onCancelled(DatabaseError databaseError) {
                progressDialog.dismiss();
            }
        });

        ((FloatingActionButton) findViewById(R.id.fab)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addEditCategory(null, null);
            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == android.R.id.home) {
            onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    public class MyAdapter extends RecyclerView.Adapter<MyAdapter.ViewHolder> {
        private Context context;
        private List<Category> categories;

        public MyAdapter(Context context, List<Category> categories) {
            this.categories = categories;
            this.context = context;
        }

        @Override
        public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_categories, parent, false);
            ViewHolder viewHolder = new ViewHolder(v);
            return viewHolder;
        }

        @Override
        public void onBindViewHolder(ViewHolder holder, int position) {
            Category category = categories.get(position);
            holder.DataDetails.setText(category.categoryName);
            try {
                Long items = category.itemsNumber;
                String product = " Product";
                if(items > 1){
                    product = " Products";
                }
                holder.itemsNumber.setText(String.valueOf(items)+ product);
            }catch (Exception e){
                Toast.makeText(CategoryActivity.this, "error 3421:"+e, Toast.LENGTH_SHORT).show();
            }
            Glide.with(context).load(category.imagePath).into(holder.imageViewCategory);
        }

        @Override
        public int getItemCount() {
            return categories.size();
        }

        class ViewHolder extends RecyclerView.ViewHolder {

            public TextView DataDetails, itemsNumber;
            public ImageView imageViewCategory, EditCategory, DeleteCategory;
            private final Context context;
            public ViewHolder(View itemView) {
                super(itemView);
                context = itemView.getContext();
                final Intent[] intent = new Intent[1];

                itemsNumber = (TextView) itemView.findViewById(R.id.itemsNumber);
                DataDetails = (TextView) itemView.findViewById(R.id.dataDetails);
                imageViewCategory = (ImageView) itemView.findViewById(R.id.imageViewCategory);
                EditCategory = (ImageView) itemView.findViewById(R.id.editCategory);
                DeleteCategory = (ImageView) itemView.findViewById(R.id.deleteCategory);

                EditCategory.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String CategoryID = categories.get(getAdapterPosition()).categoryID;
                        String CategoryName = categories.get(getAdapterPosition()).categoryName;
                        addEditCategory(CategoryID, CategoryName);
                    }
                });

                itemView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String CategoryName = categories.get(getAdapterPosition()).categoryName;
                        String CategoryID = categories.get(getAdapterPosition()).categoryID;
                        intent[0] = new Intent(context, ActivityItemsView.class);
                        intent[0].putExtra("categoryID", CategoryID);
                        intent[0].putExtra("categoryName", CategoryName);
                        context.startActivity(intent[0]);
                    }
                });

                DeleteCategory.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        final String CategoryKey = categories.get(getAdapterPosition()).categoryID;
                        final String CategoryImageName = categories.get(getAdapterPosition()).imageName;
                        String CategoryName = categories.get(getAdapterPosition()).categoryName;

                        new AlertDialog.Builder(CategoryActivity.this)
                                .setTitle("Delete Category!")
                                .setMessage("Are you sure do you want to delete "+ CategoryName+"?")
                                .setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialogInterface, int i) {
                                        try{
                                            mDatabase.child(CategoryKey).removeValue();
                                            storageReference.child(CategoryImageName).delete();
                                        }catch (Exception e){
                                            Toast.makeText(CategoryActivity.this, "Error :" + e, Toast.LENGTH_SHORT).show();
                                        }
                                        dialogInterface.dismiss();

                                    }
                                })
                                .setNegativeButton(android.R.string.cancel, new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialogInterface, int i) {
                                        dialogInterface.dismiss();
                                    }
                                }).show();
                    }
                });
            }
        }
    }

    // set dialog add edit category;
    private void addEditCategory(final String categoryID, final String categoryName){
        dialog = new Dialog(this);
        dialog.setContentView(R.layout.dialog_add_edit_category);
        Button btnCancel = (Button) dialog.findViewById(R.id.cancel_dialog);
        Button btnSave = (Button) dialog.findViewById(R.id.save);

        TextView myTitle = (TextView) dialog.findViewById(R.id.title);
        Button captureButton = dialog.findViewById(R.id.capture);
        captureButton.setOnClickListener(capture);
        Button GalleryButton = dialog.findViewById(R.id.gallery);
        GalleryButton.setOnClickListener(gallery);

        DialogSelectImage = (LinearLayout) dialog.findViewById(R.id.dialog_select_image);

        CategoryName = (EditText) dialog.findViewById(R.id.et_nameCategory);
        imageCategory = (ImageView) dialog.findViewById(R.id.imageCategory);
        addImageCategory = (FrameLayout) dialog.findViewById(R.id.addImage);

        if (categoryID != null) {
            mDatabase.child(categoryID).addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {
                    if (dataSnapshot.exists()) {
                        EditCategory = dataSnapshot.getValue(Category.class);
                        CategoryName.setText(EditCategory.categoryName);
                        Glide.with(CategoryActivity.this).load(EditCategory.imagePath).into(imageCategory);
                    } else {
                        msg("no Categories found!");
                    }
                }
                @Override
                public void onCancelled(DatabaseError databaseError) { }
            });
        }

        addImageCategory.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(DialogSelectImage.getVisibility() == View.GONE){
                    DialogSelectImage.setVisibility(View.VISIBLE);
                }else{
                    DialogSelectImage.setVisibility(View.GONE);
                }

            }
        });

        if(categoryID == null){
            myTitle.setText("Add New Category");
        }else{
            myTitle.setText("Edit Category "+categoryName);
        }

        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String ETCategoryName = CategoryName.getText().toString().trim();
                if(categoryID != null){
                    if(!EditCategory.categoryName.equals(ETCategoryName) && filePath == null){
                        // check if category name is already exist
                        checkIfAlreadyExist =  new ValueEventListener() {
                            @Override
                            public void onDataChange(DataSnapshot dataSnapshot) {
                                boolean alreadyExist = false;
                                if (dataSnapshot.exists()) {
                                    for (DataSnapshot postSnapshot : dataSnapshot.getChildren()) {
                                        Category upload = postSnapshot.getValue(Category.class);
                                        if (upload.adminID.equals(StaticConfig.UID) && upload.categoryName.equals(ETCategoryName)) {
                                            alreadyExist = true;
                                        }
                                    }
                                }

                                if (alreadyExist) {
                                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
                                        CategoryName.setBackground(getResources().getDrawable(R.drawable.bt_shape_red));
                                        CategoryName.setError("This Name is Already Existed!!\nTry another one :)");
                                    }
                                } else {
                                    mDatabase.child(categoryID).child("categoryName").setValue(ETCategoryName);
                                    dialog.dismiss();
                                }
                                mDatabase.removeEventListener(checkIfAlreadyExist);
                            }
                            @Override
                            public void onCancelled(DatabaseError databaseError) {
                                mDatabase.removeEventListener(checkIfAlreadyExist);
                            }
                        };
                        mDatabase.addValueEventListener(checkIfAlreadyExist);

                    }else if( !EditCategory.categoryName.equals(ETCategoryName) && (filePath != null) ) {
                        uploadFile(categoryID);
                        mDatabase.child(categoryID).child("categoryName").setValue(ETCategoryName);
                    }else if( EditCategory.categoryName.equals(ETCategoryName) && (filePath != null) ) {
                        uploadFile(categoryID);
                    }

                } else{

                    if (!TextUtils.isEmpty(ETCategoryName)){
                        checkIfAlreadyExist =  new ValueEventListener() {
                            @Override
                            public void onDataChange(DataSnapshot dataSnapshot) {
                                boolean alreadyExist = false;
                                if (dataSnapshot.exists()) {
                                    for (DataSnapshot postSnapshot : dataSnapshot.getChildren()) {
                                        Category upload = postSnapshot.getValue(Category.class);
                                        if (upload.adminID.equals(StaticConfig.UID) && upload.categoryName.equals(ETCategoryName)) {
                                            alreadyExist = true;
                                        }
                                    }
                                }

                                if (alreadyExist) {
                                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
                                        CategoryName.setBackground(getResources().getDrawable(R.drawable.bt_shape_red));
                                        CategoryName.setError("This Name is Already Existed!!\nTry another one :)");
                                    }
                                } else {
                                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
                                        CategoryName.setBackground(getResources().getDrawable(R.drawable.bt_shape_green));
                                    }
                                    uploadFile(null);
                                }
                                mDatabase.removeEventListener(checkIfAlreadyExist);
                            }
                            @Override
                            public void onCancelled(DatabaseError databaseError) {
                                mDatabase.removeEventListener(checkIfAlreadyExist);
                            }
                        };
                        mDatabase.addValueEventListener(checkIfAlreadyExist);
                    }else{
                        CategoryName.setError("Please! Set Category Name ");
                    }
                }
                // end of save data
            }
        });
        dialog.show();
    }


    private View.OnClickListener capture = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            if(getPackageManager().hasSystemFeature(PackageManager.FEATURE_CAMERA)){
                sendTakePictureIntent();
            }
        }
    };

    private View.OnClickListener gallery = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            showGallery();
        }
    };

    private void sendTakePictureIntent() {
        Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        cameraIntent.putExtra( MediaStore.EXTRA_FINISH_ON_COMPLETION, true);
        if (cameraIntent.resolveActivity(getPackageManager()) != null) {
            startActivityForResult(cameraIntent, REQUEST_PICTURE_CAPTURE);
            File pictureFile = null;
            try {
                pictureFile = getPictureFile();
            } catch (IOException ex) {
                Toast.makeText(this, "Photo file can't be created, please try again", Toast.LENGTH_SHORT).show();
                return;
            }
            if (pictureFile != null) {
                Uri photoURI = FileProvider.getUriForFile(this, "tech.siham.stock_management", pictureFile);
                cameraIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);
                startActivityForResult(cameraIntent, REQUEST_PICTURE_CAPTURE);
            }
        }
    }


    private File getPictureFile() throws IOException {
        String timeStamp = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
        String pictureFile = "CATEGORY_" + timeStamp;
        File storageDir = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        File image = File.createTempFile(pictureFile,  ".jpg", storageDir);
        pictureFilePath = image.getAbsolutePath();
        return image;
    }

    void msg(String text){
        Toast.makeText(this, text, Toast.LENGTH_SHORT).show();
    }

    private void showGallery() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(intent, "Select Picture"), PICK_IMAGE_REQUEST);
    }

    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_PICTURE_CAPTURE && resultCode == RESULT_OK) {
            File imgFile = new  File(pictureFilePath);
            filePath = Uri.fromFile(imgFile);
            if(imgFile.exists()){
                imageCategory.setImageURI(filePath);
            }
        }else if(requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK){

            try {
                filePath = data.getData();
                Bitmap bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), filePath);
                imageCategory.setImageBitmap(bitmap);
            } catch (IOException e) {
                msg("ERROR (get image from sd): " + e);
            }
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
            addImageCategory.setBackground(getResources().getDrawable(R.drawable.bt_shape_green));
        }
        DialogSelectImage.setVisibility(View.GONE);
    }

    public String getFileExtension(Uri uri) {
        ContentResolver cR = getContentResolver();
        MimeTypeMap mime = MimeTypeMap.getSingleton();
        return mime.getExtensionFromMimeType(cR.getType(uri));
    }

    private void uploadFile(final String categoryID) {
        //checking if file is available
        if (filePath != null) {
            //displaying progress dialog while image is uploading
            final ProgressDialog progressDialog = new ProgressDialog(this);
            progressDialog.setTitle("Uploading Data To Server");
            progressDialog.show();
            //ImageName = "Categories" + System.currentTimeMillis() + "." + getFileExtension(filePath);
            String SuffixFileExtension = "";
            if(getFileExtension(filePath) == null){
                SuffixFileExtension =  getFileExtension(filePath);
            }else{
                SuffixFileExtension = "jpg";
            }
            ImageName = "Categories" + System.currentTimeMillis() + "." + SuffixFileExtension;
            //getting the storage reference
            final StorageReference sRef = storageReference.child(ImageName);
            //adding the file to reference
            sRef.putFile(filePath)
                    .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                            //dismissing the progress dialog
                            progressDialog.dismiss();
                            //displaying success toast
                            if(categoryID == null) {
                                Date dNow = new Date();
                                SimpleDateFormat format = new SimpleDateFormat("dd-MM-yyyy HH:mm");
                                String current_datetime = format.format(dNow);
                                //adding an upload to firebase database
                                String uploadId = mDatabase.push().getKey();
                                //creating the upload Category object to store uploaded image details
                                final Category category = new Category();
                                //Upload(editTextName.getText().toString().trim(), taskSnapshot.getDownloadUrl().toString());
                                category.categoryID = uploadId;
                                category.adminID = SharedPreferenceHelper.getInstance(CategoryActivity.this).getUID();
                                category.imageName = ImageName;
                                category.categoryName = CategoryName.getText().toString().trim();
                                category.imagePath = taskSnapshot.getDownloadUrl().toString();

                                mDatabase.child(uploadId).setValue(category).addOnCompleteListener(new OnCompleteListener<Void>() {
                                    @Override
                                    public void onComplete(@NonNull Task<Void> task) {
                                        if(task.isSuccessful()){
                                            msg("Category "+category.categoryName+" Added Successfully");
                                            filePath = null;
                                            ImageName = null;
                                            dialog.dismiss();
                                        }else{
                                            msg("Category "+category.categoryName+" not added \nTry Again !!!");
                                        }
                                    }
                                });

                            }else{
                                mDatabase.child(categoryID).child("imagePath").setValue(taskSnapshot.getDownloadUrl().toString());
                                mDatabase.child(categoryID).child("imageName").setValue(ImageName);
                                sRef.child(EditCategory.imageName).delete();
                                filePath = null;
                                ImageName = null;
                                dialog.dismiss();
                            }

                        }
                    })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception exception) {
                            progressDialog.dismiss();
                            Toast.makeText(getApplicationContext(), exception.getMessage(), Toast.LENGTH_LONG).show();
                        }
                    })
                    .addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onProgress(UploadTask.TaskSnapshot taskSnapshot) {
                            // displaying the upload progress
                            double progress = (100.0 * taskSnapshot.getBytesTransferred()) / taskSnapshot.getTotalByteCount();
                            progressDialog.setMessage("Uploaded " + ((int) progress) + "%...");
                        }
                    });
        } else {
            // display an error if no file is selected
            msg("You Should select Image");
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
                addImageCategory.setBackground(getResources().getDrawable(R.drawable.bt_shape_red));
            }
        }
    }
}