package tech.siham.stock_management.utils;

import android.view.View;

/**
 * Created by root on 2/27/18.
 */

public interface ItemClickListener {
   void onClickItems(View view, int position);
}
