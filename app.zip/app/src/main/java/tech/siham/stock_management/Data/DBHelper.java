package tech.siham.stock_management.Data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;


import java.util.ArrayList;
import java.util.HashMap;

import tech.siham.stock_management.Model.MyBasket;

public class DBHelper extends SQLiteOpenHelper {


    public static final String DATABASE_NAME = "MyBasket.db";
    public static final String TABLE_NAME = "basket";
    private HashMap hp;

    public DBHelper(Context context) {
        super(context, DATABASE_NAME , null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // TODO Auto-generated method stub
        db.execSQL(
                "create table "+ TABLE_NAME+
                        "(id integer primary key," +
                        "basketID    text, " +
                        "productID   text, " +
                        "categoryID  text, " +
                        "imagePath   text, " +
                        "productName text, " +
                        "describe    text, " +
                        "packets     text, " +
                        "unities     text, " +
                        "position    text ," +
                        "price       text, " +
                        "normalPrice text," +
                        "total       text, " +
                        "status      text);"
        );
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // TODO Auto-generated method stub
        db.execSQL("DROP TABLE IF EXISTS "+TABLE_NAME);
        onCreate(db);
    }

    // todo DELETE all table
    public boolean deleteTable() {
        SQLiteDatabase database = this.getReadableDatabase();
        int affectedRows = database.delete(TABLE_NAME, null, null);
        return affectedRows > 0;
    }

    public boolean insertBasket(MyBasket basket) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("basketID", basket.basketID);
        contentValues.put("productID", basket.productID);
        contentValues.put("categoryID", basket.categoryID);
        contentValues.put("imagePath", basket.imagePath);
        contentValues.put("productName", basket.productName);
        contentValues.put("describe", basket.describe);
        contentValues.put("packets", basket.packets);
        contentValues.put("unities", basket.unities);
        contentValues.put("position", basket.position);
        contentValues.put("price", basket.price);
        contentValues.put("normalPrice", basket.normalPrice);
        contentValues.put("total", basket.total);
        contentValues.put("status", basket.status);
        db.insert(TABLE_NAME, null, contentValues);
        return true;
    }

    public Cursor getData(int id) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res =  db.rawQuery( "select * from contacts where id="+id+"", null );
        return res;
    }

    public int numberOfRows(){
        SQLiteDatabase db = this.getReadableDatabase();
        int numRows = (int) DatabaseUtils.queryNumEntries(db, "id");
        return numRows;
    }

    public boolean updateBasket(String basketID, int Packets, double total) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("packets", Packets);
        contentValues.put("total", total);
        db.update(TABLE_NAME, contentValues, "productID = ?", new String[] { basketID } );
        return true;
    }

    public Integer deleteBasket (String productId) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete(TABLE_NAME,
                "productID = ? ",
                new String[] { productId });
    }

    public ArrayList<MyBasket> getAllBaskets() {
        ArrayList<MyBasket> array_list = new ArrayList<>();
        //hp = new HashMap();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res =  db.rawQuery( "select * from "+TABLE_NAME, null );
        res.moveToFirst();
        while(res.isAfterLast() == false){
            MyBasket basket = new MyBasket();
            basket.basketID     = res.getString(res.getColumnIndex("basketID"));
            basket.productID    = res.getString(res.getColumnIndex("productID"));
            basket.categoryID   = res.getString(res.getColumnIndex("categoryID"));
            basket.imagePath    = res.getString(res.getColumnIndex("imagePath"));
            basket.productName  = res.getString(res.getColumnIndex("productName"));
            basket.describe     = res.getString(res.getColumnIndex("describe"));
            basket.packets      = Integer.parseInt(res.getString(res.getColumnIndex("packets")));
            basket.unities      = Integer.parseInt(res.getString(res.getColumnIndex("unities")));
            basket.position     = Integer.parseInt(res.getString(res.getColumnIndex("position")));
            basket.price        = Double.parseDouble(res.getString(res.getColumnIndex("price")));
            basket.normalPrice  = Double.parseDouble(res.getString(res.getColumnIndex("normalPrice")));
            basket.total        = Double.parseDouble(res.getString(res.getColumnIndex("total")));
            array_list.add(basket);
            res.moveToNext();
        }
        return array_list;
    }
}