package tech.siham.stock_management.ui;

import android.annotation.SuppressLint;
import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.DatePicker;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import tech.siham.stock_management.Data.SharedPreferenceHelper;
import tech.siham.stock_management.Model.MyBasket;
import tech.siham.stock_management.Model.Order;
import tech.siham.stock_management.Model.User;
import tech.siham.stock_management.Model.pdfIDs;
import tech.siham.stock_management.R;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.itextpdf.text.BadElementException;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.Image;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class OrdersActivity extends AppCompatActivity {

    RecyclerView recyclerview;
    List<Order> myOrders = new ArrayList<>();
    RecyclerviewAdapter recycler;

    SharedPreferenceHelper SHHelper ;
    // database reference
    private DatabaseReference mDatabase;
    // progress dialog
    private ProgressDialog progressDialog;
    // list to hold all the uploaded images

    List<pdfIDs> ID_Orders_to_PDF = new ArrayList<>();

    String returnDate ;
    String orderStatus = "pending";

    ArrayAdapter<String> dataAdapter_order_status ;
    List<String> categories_order_status;

    List<String> categories_time;
    ArrayAdapter<String> dataAdapter_Time;

    TextView SelectedOrders;
    Button PrintPDF_Button;

    CheckBox selectAll;
    public static boolean All_is_checked = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_orders);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle("Orders Management");

        recyclerview = (RecyclerView) findViewById(R.id.recycleListOrders);

        PrintPDF_Button = (Button) findViewById(R.id.printPDF);

        selectAll = (CheckBox) findViewById(R.id.selectAll);

        selectAll.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(All_is_checked){
                    All_is_checked = false;
                }else{
                    All_is_checked = true;
                }
                recycler.notifyDataSetChanged();
            }
        });


        SHHelper = SharedPreferenceHelper.getInstance(this);
        progressDialog = new ProgressDialog(this);
        mDatabase = FirebaseDatabase.getInstance().getReference("Orders");

        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(OrdersActivity.this);
        recyclerview.setLayoutManager(layoutManager);
        recyclerview.setItemAnimator(new DefaultItemAnimator());

        SelectedOrders = (TextView) findViewById(R.id.selectedOrders);

        //adding an event listener to fetch values
        PrintPDF_Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // print the invoices to pdf documents
                printTheInvoices();
            }
        });

        Spinner selectTime = (Spinner) findViewById(R.id.select_time);
        Spinner selectOrderStatus = (Spinner) findViewById(R.id.select_order_status);

        // Spinner Drop down elements
        categories_time = new ArrayList<>();
        categories_time.add("To Day");
        categories_time.add("Select a Day");
        categories_time.add("Select a Week");
        categories_time.add("Select a Month");
        categories_time.add("All");

        // Creating adapter for spinner
        dataAdapter_Time = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, categories_time);;
        // Drop down layout style - list view with radio button
        dataAdapter_Time.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        // attaching data adapter to spinner
        selectTime.setAdapter(dataAdapter_Time);

        selectTime.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                switch (position) {
                    case 0:
                        returnDate = new SimpleDateFormat("dd/MM/yyyy").format(new Date());
                        fetchOrderByDate(returnDate , orderStatus);

                        break;
                    case 1:
                        int mYear, mMonth, mDay;
                        // Get Current Date
                        final Calendar c = Calendar.getInstance();
                        mYear = c.get(Calendar.YEAR);
                        mMonth = c.get(Calendar.MONTH);
                        mDay = c.get(Calendar.DAY_OF_MONTH);

                        DatePickerDialog datePickerDialog = new DatePickerDialog(OrdersActivity.this,
                                new DatePickerDialog.OnDateSetListener() {
                                    @Override
                                    public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                                        returnDate = (dayOfMonth + "/" + (monthOfYear + 1) + "/" + year);
                                        fetchOrderByDate(returnDate , orderStatus);
                                        //Toast.makeText(OrdersActivity.this, returnDate, Toast.LENGTH_LONG).show();
                                    }
                                }, mYear, mMonth, mDay);
                        datePickerDialog.show();
                        break;
                    case 2:

                        break;
                    case 3:

                        break;
                    case 4:
                        returnDate = "all";
                        fetchOrderByDate(returnDate , orderStatus);
                        break;
                }
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) { }
        });

        // Spinner Drop down elements
        categories_order_status = new ArrayList<>();
        categories_order_status.clear();
        categories_order_status.add("Pending");
        categories_order_status.add("Done");
        categories_order_status.add("not complete");
        categories_order_status.add("canceled");
        categories_order_status.add("All Orders");

        // Creating adapter for spinner
        dataAdapter_order_status = new ArrayAdapter<String>(OrdersActivity.this, android.R.layout.simple_spinner_item, categories_order_status ){
            @Override
            public View getDropDownView(int position, View convertView, ViewGroup parent) {

                View view = super.getDropDownView(position, convertView, parent);

                int[] textBackgroundColor = {Color.BLUE, Color.GREEN, Color.YELLOW, Color.RED, Color.GRAY};
                int[] textColor = {Color.WHITE, Color.BLACK, Color.BLACK, Color.WHITE, Color.WHITE};

                TextView tv = (TextView) view;

                tv.setTypeface(null, Typeface.BOLD);
                tv.setBackgroundColor(textBackgroundColor[position]);
                tv.setTextColor(textColor[position]);

                // Set the item text color
                // tv.setTextColor(Color.parseColor("#FF7C7967"));
                // Set the item background color
                // tv.setBackgroundColor(Color.parseColor("#FFC3C0AA"));
                return view;
            }
        };

        // Drop down layout style - list view with radio button
        dataAdapter_order_status.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        // attaching data adapter to spinner
        selectOrderStatus.setAdapter(dataAdapter_order_status);

        selectOrderStatus.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                switch (position){
                    case 0:
                        orderStatus = "pending";
                        break;
                    case 1:
                        orderStatus = "done";
                        break;
                    case 2:
                        orderStatus = "not_complete";
                        break;
                    case 3:
                        orderStatus = "except";
                        break;
                    case 4:
                        orderStatus = "all";
                        break;
                }
                fetchOrderByDate(returnDate , orderStatus);
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) { }
        });
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == android.R.id.home) {
            onBackPressed();
            // overridePendingTransition(R.anim.slide_from_left, R.anim.slide_to_right);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }


    public void fetchOrderByDate(final String date_post, final String orderStatus){
        // displaying progress dialog while fetching images
        progressDialog.setMessage("Loading data\nPlease wait ...");
        progressDialog.show();

        mDatabase.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                // dismissing the progress dialog
                progressDialog.dismiss();
                myOrders.clear();
                ID_Orders_to_PDF.clear();
                if (snapshot.exists()) {
                    /*
                    fetch order :
                    - by click on show calendar
                    - on date return date
                    -- see if (return date day) equal ( order delivery date day)
                    --- add data to list view
                    */
                    try {
                        // set order details number
                        int pendingOrder = 0, doneOrder = 0, NotCompleteOrder = 0, canceledOrder = 0, AllOrder = 0, AllOrders = 0;
                        Date lookingForDate = null;
                        try {
                            lookingForDate = new SimpleDateFormat("dd/MM/yyyy").parse(date_post);
                        } catch (ParseException e) {
                            e.printStackTrace();
                        }

                        for (DataSnapshot postSnapshot : snapshot.getChildren()) {
                            Order upload = postSnapshot.getValue(Order.class);
                            Date OrderDate = null;
                            try {
                                OrderDate = new SimpleDateFormat("dd/MM/yyyy").parse(upload.dateTimeToPostOrder);
                            } catch (ParseException e) {
                                e.printStackTrace();
                            }
                            // upload.adminID.equals(StaticConfig.UID)
                            //if (OrderDate.equals(lookingForDate) && upload.status.equals(orderStatus)){
                            AllOrders += 1;

                            if (OrderDate.equals(lookingForDate) ) {
                                AllOrder += 1;
                                if (upload.status.equals("pending")) {
                                    pendingOrder += 1;
                                } else if (upload.status.equals("done")) {
                                    doneOrder += 1;
                                } else if (upload.status.equals("not_complete")) {
                                    NotCompleteOrder += 1;
                                } else if (upload.status.equals("except")) {
                                    canceledOrder += 1;
                                }
                                if (upload.status.equals(orderStatus)) {
                                    myOrders.add(upload);
                                } else if (orderStatus.equals("all")) {
                                    myOrders.add(upload);
                                }

                            }else if(date_post.equals("all") ){
                                AllOrder += 1;
                                if(upload.status.equals("pending")){
                                    pendingOrder += 1;
                                }else if(upload.status.equals("done")){
                                    doneOrder += 1;
                                }else if(upload.status.equals("not_complete")){
                                    NotCompleteOrder += 1;
                                }else if(upload.status.equals("except")){
                                    canceledOrder += 1;
                                }

                                if (upload.status.equals(orderStatus)) {
                                    myOrders.add(upload);
                                } else if (orderStatus.equals("all")) {
                                    myOrders.add(upload);
                                }
                            }
                            // count orders number details
                        }

                        // set details in spinner
                        // Spinner Drop down elements
                        categories_order_status.clear();
                        categories_order_status.add(pendingOrder + " Pending");
                        categories_order_status.add(doneOrder +" Done");
                        categories_order_status.add(NotCompleteOrder + " not complete");
                        categories_order_status.add(canceledOrder +" canceled");
                        categories_order_status.add(AllOrder + " All Orders");
                        dataAdapter_order_status.notifyDataSetChanged();


                        categories_time.set(4,AllOrders + " All Orders");
                        dataAdapter_Time.notifyDataSetChanged();

                        recycler = new RecyclerviewAdapter(OrdersActivity.this, myOrders);
                        recyclerview.setAdapter(recycler);
                        recycler.notifyDataSetChanged();


                    }catch (Exception e){
                        Toast.makeText(OrdersActivity.this, "Error : "+e, Toast.LENGTH_SHORT).show();
                    }


                } else{
                    Toast.makeText(OrdersActivity.this, "No Order exist", Toast.LENGTH_SHORT).show();
                }
            }
            @Override
            public void onCancelled(DatabaseError databaseError) { progressDialog.dismiss(); }
        });
    }


    class RecyclerviewAdapter extends RecyclerView.Adapter<RecyclerviewAdapter.MyHolder> {
        Context context;
        List<Order> myOrder;

        public RecyclerviewAdapter(Context context, List<Order> listOrder) {
            this.myOrder = listOrder;
            this.context = context;
        }

        @Override
        public RecyclerviewAdapter.MyHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_oders, parent, false);
            RecyclerviewAdapter.MyHolder myHolder = new RecyclerviewAdapter.MyHolder(view);
            return myHolder;
        }

        @SuppressLint("ResourceType")
        public void onBindViewHolder(RecyclerviewAdapter.MyHolder holder, int position) {
            Order data = myOrder.get(position);
            // Glide.with(context).load(data.avatar).into(holder.ContentProduct);

            holder.TextDetails.setText(
                    "Track Number: " + String.valueOf(data.trackNumber) +
                            "\nFull Name : " + data.fullName+
                            "\nStore Name : " + data.storeName+
                            "\nStore Address : " + data.storeAddress+
                            "\nStatus : " + data.status+
                            "\nPost Date Time : " + data.dateTimeToPostOrder+
                            "\nDelivery Day : " + data.DayToDeliveryOrder+
                            "\nPackets : " + data.packets+
                            " QTY\n"+
                            "Total Price : " + String.valueOf(data.totalPrice)+" Euro"
            );

            if(All_is_checked){
                holder.Pdf_Writer_id.setChecked(true);
            }else{
                holder.Pdf_Writer_id.setChecked(false);
            }

            /*
            if(holder.Pdf_Writer_id.isChecked()){
            }else{}
            */
            // pending done except not_complete

            int StatusColor = 0;
            switch (data.status){
                case "pending":
                    StatusColor = Color.BLUE;
                    break;
                case "done":
                    StatusColor = Color.GREEN;
                    break;
                case "except":
                    StatusColor = Color.RED;
                    break;
                case "not_complete":
                    StatusColor = Color.YELLOW;
                    break;
            }
            holder.StatusColor.setBackgroundColor(StatusColor);

        }

        @Override
        public int getItemCount() {
            return myOrder.size();
        }

        class MyHolder extends RecyclerView.ViewHolder {

            private final Context context;
            TextView TextDetails ;
            ImageView StatusColor;
            CheckBox Pdf_Writer_id;

            public MyHolder(final View itemView) {

                super(itemView);
                context = itemView.getContext();
                final Intent[] intent = new Intent[1];

                TextDetails = (TextView) itemView.findViewById(R.id.dataDetails);
                StatusColor = (ImageView) itemView.findViewById(R.id.statusColor);
                Pdf_Writer_id = (CheckBox) itemView.findViewById(R.id.checkPdf_Writer);

                /*
                try {
                    pdfIDs pdf_ids = new pdfIDs();
                    pdf_ids.ID_ORDER = myOrder.get(getAdapterPosition()).orderID;
                    pdf_ids.ID_ADMIN = myOrder.get(getAdapterPosition()).adminID;
                    pdf_ids.ID_USER = myOrder.get(getAdapterPosition()).userID;
                    ID_Orders_to_PDF.add(pdf_ids);
                }catch (Exception e){
                    Toast.makeText(OrdersActivity.this, "Error in check box :"+e, Toast.LENGTH_LONG).show();
                }
                */

                Pdf_Writer_id.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                    @Override
                    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                        try {
                            pdfIDs pdf_ids = new pdfIDs();
                            pdf_ids.ID_ORDER = myOrder.get(getAdapterPosition()).orderID;
                            pdf_ids.ID_ADMIN = myOrder.get(getAdapterPosition()).adminID;
                            pdf_ids.ID_USER = myOrder.get(getAdapterPosition()).userID;

                            if (isChecked) {
                                ID_Orders_to_PDF.add(pdf_ids);
                            } else {
                                ID_Orders_to_PDF.remove(pdf_ids);
                                selectAll.setChecked(false);
                            }

                        }catch (Exception e){
                            Toast.makeText(OrdersActivity.this, "Error in check/des check box :"+e, Toast.LENGTH_LONG).show();
                        }
                    }
                });

                itemView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        try {
                            intent[0] = new Intent(context, ScannerProducts.class);
                            intent[0].putExtra("orderID", myOrder.get(getAdapterPosition()).orderID);
                            //intent[0].putExtra("orderID", myOrder.get(getAdapterPosition()).orderID);
                            startActivity(intent[0]);
                        }catch (Exception e){Toast.makeText(OrdersActivity.this, "Error : "+e, Toast.LENGTH_LONG).show();}

                    }
                });

            /*
            itemView.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View v) {
                    //String productkey = listProducts.get(getAdapterPosition()).getPushkey();
                   // String producttitle = listProducts.get(getAdapterPosition()).getTitle();
                    new AlertDialog.Builder(context)
                            .setTitle("Delete Product ")
                            .setMessage("Are you sure want to delete ... ?")
                            .setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialogInterface, int i) {
                                    dialogInterface.dismiss();
                                    FirebaseDatabase.getInstance().getReference().child("Products").child(productkey).removeValue();
                                }
                            })
                            .setNegativeButton(android.R.string.cancel, new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialogInterface, int i) {
                                    dialogInterface.dismiss();
                                }
                            }).show();
                    return false;
                }
            });
            */
            }
        }
    }

    public void printTheInvoices(){

        for(final pdfIDs idOrder : ID_Orders_to_PDF){
            FirebaseDatabase.getInstance().getReference().addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {

                    Order order_data = dataSnapshot.child("Orders").child(idOrder.ID_ORDER).getValue(Order.class);
                    // order from : [Store | Stock | Home | Business| other > set name]

                    User admin_data = dataSnapshot.child("Stock").child(idOrder.ID_ADMIN).getValue(User.class);
                    User user_data = dataSnapshot.child(order_data.orderFrom).child(idOrder.ID_USER).getValue(User.class);

                    String current_datetime = (new SimpleDateFormat("EEEE dd/MM/yyyy")).format(new Date());

                    Font font1 = new Font(Font.FontFamily.COURIER, 14, Font.NORMAL);
                    Font font2 = new Font(Font.FontFamily.HELVETICA, 12, Font.BOLD);
                    Font font3 = new Font(Font.FontFamily.TIMES_ROMAN, 14, Font.NORMAL, BaseColor.WHITE);
                    Font font4 = new Font(Font.FontFamily.HELVETICA, 12, Font.NORMAL);
                    Font font5 = new Font(Font.FontFamily.HELVETICA, 18, Font.BOLD, BaseColor.WHITE);

                    String dataText_order =
                            "Invoice Number : " + order_data.trackNumber +
                            //"\nInvoice ID: " + order_data.orderID +
                            // "\nUser ID: " + order_data.userID +
                            "\nPost Date Time : " + order_data.dateTimeToPostOrder +
                            "\nDelivery Day : " + order_data.DayToDeliveryOrder +
                            "\nCurrent date time : " + current_datetime+
                            "\nStatus : " + order_data.status ;

                    String dataText_from =
                            admin_data.fullName +
                            "\n" + admin_data.address +
                            "\n" + admin_data.phoneNumber+
                            "\n" + admin_data.email ;
                    //+"\nID: " + admin_data.adminID  ;

                    String dataText_to =
                            "Shop Name : " + user_data.storeName +
                            "\nName : " + user_data.fullName +
                            "\nPhone : " + user_data.phoneNumber +
                            "\nEmail : " + user_data.email +
                            "\nAddress : " + user_data.address ;
                    //+ "\nID : " + user_data.userID ;

                    try {

                        String directory_path = Environment.getExternalStorageDirectory().getPath() + "/TADA_Admin/Orders/"+(new SimpleDateFormat("EEEE_dd-MM-yyyy")).format(new Date())+"/";
                        File file = new File(directory_path);
                        if (!file.exists()) {
                            file.mkdirs();
                        }
                        // name of pdf :  datetime, order day, user name,
                        String targetPdf = directory_path + "/"+order_data.DayToDeliveryOrder+"_"+ user_data.fullName+"_"+ order_data.trackNumber +".pdf";
                        File filePath = new File(targetPdf);
                        Document document = new Document();

                        try {
                            PdfWriter.getInstance(document, new FileOutputStream(filePath));
                            Toast.makeText(OrdersActivity.this, "PDF created successfully in\n" + targetPdf, Toast.LENGTH_LONG).show();

                        } catch (DocumentException e) {
                            e.printStackTrace();
                            Toast.makeText(OrdersActivity.this, "Something wrong 1: " + e.toString(), Toast.LENGTH_LONG).show();
                        } catch (FileNotFoundException e) {
                            e.printStackTrace();
                            Toast.makeText(OrdersActivity.this, "Something wrong 2: " + e.toString(), Toast.LENGTH_LONG).show();
                        }

                        document.open();


                        // set image from db
                        Bitmap bm = BitmapFactory.decodeResource(getResources(), R.drawable.logo_invoice);
                        ByteArrayOutputStream stream = new ByteArrayOutputStream();
                        bm.compress(Bitmap.CompressFormat.PNG, 100, stream);
                        Image img = null;
                        byte[] byteArray = stream.toByteArray();
                        try {
                            img = Image.getInstance(byteArray);
                            img.scaleToFit(300, 80);
                            //img.setAbsolutePosition(10, 10);
                            //document.add(img);

                        } catch (BadElementException e) {
                            e.printStackTrace();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }

                        // first head logo + admin information
                        try {

                            PdfPTable table = new PdfPTable(2);
                            table.setWidthPercentage(100);

                            PdfPCell cell1 = new PdfPCell(new PdfPCell(img, true));
                            PdfPCell cell2 = new PdfPCell(new Paragraph(dataText_from, font1));

                            cell1.setBorder(PdfPCell.NO_BORDER);
                            cell2.setBorder(PdfPCell.NO_BORDER);
                            cell2.setHorizontalAlignment(Element.ALIGN_RIGHT);

                            table.addCell(cell1);
                            table.addCell(cell2);
                            document.add(table);

                        } catch (DocumentException e) {
                            e.printStackTrace();
                        }
                        // second table head 2 : ship to + order info
                        try {

                            PdfPTable table = new PdfPTable(2);

                            table.setWidthPercentage(100);

                            PdfPCell cell1 = new PdfPCell(new Phrase("Deliver To ", font5));
                            PdfPCell cell2 = new PdfPCell(new Phrase("Order Information ", font5));

                            cell1.setBorderColor(BaseColor.WHITE);
                            cell2.setBorderColor(BaseColor.WHITE);
                            //cell1.setBorder(PdfPCell.NO_BORDER);
                            //cell2.setBorder(PdfPCell.NO_BORDER);

                            cell1.setBackgroundColor(BaseColor.GRAY);
                            cell2.setBackgroundColor(BaseColor.GRAY);
                            cell1.setBorderWidthRight(15);

                            PdfPCell cell3 = new PdfPCell(new Paragraph(dataText_to, font4));
                            PdfPCell cell4 = new PdfPCell(new Paragraph(dataText_order, font4));
                            cell3.setPadding(10);
                            cell4.setPadding(10);

                            //cell1.setBorder(PdfPCell.NO_BORDER);
                            //cell2.setBorder(PdfPCell.NO_BORDER);
                            cell3.setBorder(PdfPCell.NO_BORDER);
                            cell4.setBorder(PdfPCell.NO_BORDER);

                            table.addCell(cell1);
                            table.addCell(cell2);

                            table.addCell(cell3);
                            table.addCell(cell4);

                            document.add(table);

                        } catch (DocumentException e) {
                            e.printStackTrace();
                        }

                        PdfPTable ItemTable = new PdfPTable(1);
                        ItemTable.setWidthPercentage(100);

                        PdfPCell cellItem = new PdfPCell(new Phrase("Items", font3));
                        cellItem.setHorizontalAlignment(Element.ALIGN_LEFT);
                        cellItem.setBackgroundColor(BaseColor.LIGHT_GRAY);
                        cellItem.setBorderColor(BaseColor.GRAY);
                        ItemTable.addCell(cellItem);
                        ItemTable.getDefaultCell().setPadding(4);
                        // fetch products data and price ...
                        PdfPTable table = new PdfPTable(new float[]{3, 2, 3, 2, 3, 2});
                        table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
                        table.getDefaultCell().setPadding(3);

                        table.addCell(new Phrase("products name",font3));
                        // table.addCell("products id",font3));
                        table.addCell(new Phrase("unity price",font3));
                        table.addCell(new Phrase("unities \nin a packet",font3));
                        table.addCell(new Phrase("packets\nQTY",font3));
                        table.addCell(new Phrase("total",font3));
                        table.addCell(new Phrase("status",font3));
                        table.setHeaderRows(1);
                        PdfPCell[] cells = table.getRow(0).getCells();

                        for (int j = 0; j < cells.length; j++) {
                            cells[j].setBackgroundColor(BaseColor.GRAY);
                        }

                        for (DataSnapshot postSnapshot : dataSnapshot.child("Orders").child(idOrder.ID_ORDER).child("myBasket").getChildren()) {
                            MyBasket myBasket = postSnapshot.getValue(MyBasket.class);

                            table.addCell(myBasket.productName);
                            //table.addCell(myBasket.productID);
                            table.addCell(String.valueOf(myBasket.price));
                            table.addCell(String.valueOf(myBasket.unities));
                            table.addCell(String.valueOf(myBasket.packets));
                            table.addCell(String.valueOf(myBasket.total) + " €");
                            table.addCell(myBasket.status);
                        }

                        ItemTable.addCell(table);
                        document.add(ItemTable);

                        // PdfWriter.getInstance(document, new FileOutputStream(filePath));
                        // document.open();

                        try {

                            PdfPTable footerTable = new PdfPTable(2);
                            footerTable.setWidthPercentage(100);
                            footerTable.getDefaultCell().setBorder(PdfPCell.NO_BORDER);

                            PdfPCell cell5 = new PdfPCell(new Paragraph(current_datetime+"\n\n\nSignature _______________________"));
                            cell5.setHorizontalAlignment(Element.ALIGN_BOTTOM);
                            cell5.setBorder(PdfPCell.NO_BORDER);
                            footerTable.addCell(cell5);

                           /*
                        PdfPCell emptyCell = new PdfPCell(new Paragraph(""));
                        emptyCell.setBorder(PdfPCell.NO_BORDER);
                        table.addCell(emptyCell); //
                        // table.addCell("products id");
                        table.addCell(emptyCell); //
                        // table.addCell(emptyCell); //
                        table.addCell(new Paragraph("TOTAL ", font2));
                        table.addCell(new Paragraph(String.valueOf(order_data.packets), font2)); // Total price
                        table.addCell(new Paragraph(order_data.totalPrice+" €", font2)); // Total price
                        table.addCell(emptyCell); //
                        */

                            /*
                            table 2
                            1 table :
                                         subtotal  :  xxx$
                                         tax       :  xxx%
                                         total due :  xxx$
                            3 tables :

                            pages  | Pieces Count |  Total
                            -------+--------------+-------
                            x of x |    xxxx     +   xxx.xx$
                            --------------------------------
                             */

                            PdfPTable resultTable = new PdfPTable(1);
                            resultTable.setWidthPercentage(100);
                            resultTable.getDefaultCell().setBorder(PdfPCell.NO_BORDER);

                            PdfPTable subResultTable = new PdfPTable(2);
                            subResultTable.setWidthPercentage(100);
                            subResultTable.getDefaultCell().setBorder(PdfPCell.NO_BORDER);

                            PdfPTable subResultTable2 = new PdfPTable(2);
                            subResultTable2.setWidthPercentage(100);

                            PdfPCell subTotal = new PdfPCell(new Paragraph("SubTotal\nTax\nTotal"));
                            PdfPCell ValuesTotal = new PdfPCell(new Paragraph(order_data.totalPrice+" €"+"\n"+"00.0%"+"\n"+order_data.totalPrice+" €",font2));
                            subTotal.setHorizontalAlignment(Element.ALIGN_LEFT);
                            ValuesTotal.setHorizontalAlignment(Element.ALIGN_RIGHT);
                            subResultTable2.getDefaultCell().setBorder(PdfPCell.NO_BORDER);

                            subTotal.setBorder(PdfPCell.NO_BORDER);
                            ValuesTotal.setBorder(PdfPCell.NO_BORDER);
                            subResultTable2.addCell(subTotal);
                            subResultTable2.addCell(ValuesTotal);

                            subResultTable.addCell(new Phrase(""));
                            subResultTable.addCell(subResultTable2);

                            resultTable.addCell(subResultTable);

                            // summary invoice

                            PdfPTable summaryInvoice = new PdfPTable(3);
                            summaryInvoice.setWidthPercentage(100);
                            summaryInvoice.getDefaultCell().setBorder(PdfPCell.NO_BORDER);

                            PdfPTable summaryPages = new PdfPTable(1);
                            PdfPTable summaryPieces = new PdfPTable(1);
                            PdfPTable summaryPrice = new PdfPTable(1);


                            PdfPCell pages = new PdfPCell(new Paragraph("Pages",font3));
                            pages.setBackgroundColor(BaseColor.GRAY);
                            pages.setHorizontalAlignment(Element.ALIGN_CENTER);
                            // get number of pages


                            PdfPCell pagesValue = new PdfPCell(new Paragraph(("1 of 1")));
                            pagesValue.setHorizontalAlignment(Element.ALIGN_CENTER);
                            summaryPages.addCell(pages);
                            summaryPages.addCell(pagesValue);

                            PdfPCell pieces = new PdfPCell(new Paragraph("Pieces Count",font3));
                            pieces.setBackgroundColor(BaseColor.GRAY);
                            pieces.setHorizontalAlignment(Element.ALIGN_CENTER);
                            PdfPCell piecesValue = new PdfPCell(new Paragraph(String.valueOf(order_data.packets)));
                            piecesValue.setHorizontalAlignment(Element.ALIGN_CENTER);
                            summaryPieces.addCell(pieces);
                            summaryPieces.addCell(piecesValue);

                            PdfPCell price = new PdfPCell(new Paragraph("Total",font5));
                            price.setBackgroundColor(BaseColor.BLACK);
                            price.setHorizontalAlignment(Element.ALIGN_CENTER);
                            PdfPCell priceValue = new PdfPCell(new Paragraph(order_data.totalPrice+" €", font2));
                            priceValue.setHorizontalAlignment(Element.ALIGN_CENTER);
                            summaryPrice.addCell(price);
                            summaryPrice.addCell(priceValue);

                            summaryInvoice.addCell(summaryPages);
                            summaryInvoice.addCell(summaryPieces);
                            summaryInvoice.addCell(summaryPrice);

                            resultTable.addCell(summaryInvoice);

                            footerTable.addCell(resultTable);

                            document.add(footerTable);

                        } catch (DocumentException e) {
                            e.printStackTrace();
                        }


                        document.close();

                    }catch (Exception e){
                        Toast.makeText(OrdersActivity.this, "error in : " + e.toString(), Toast.LENGTH_LONG).show();
                    }

                }
                @Override
                public void onCancelled(DatabaseError databaseError){}
            });

        }

    }

    /*
                    if(DaysOfWeek_Buttons[finalI].getText().toString().equals(TomorrowDay)){
                        // current order day
                        DaysOfWeek_Buttons[finalI].setBackgroundColor(Color.GREEN);
                        DaysOfWeek_Buttons[finalI].setTextColor(Color.WHITE);
                    }else if(NumberDayOfWeek > finalI ){
                        // before order day
                        DaysOfWeek_Buttons[finalI].setBackgroundColor(Color.GRAY);
                        DaysOfWeek_Buttons[finalI].setTextColor(Color.WHITE);

                    }else if(NumberDayOfWeek < finalI){
                        // after order day

                        DaysOfWeek_Buttons[finalI].setBackgroundColor(Color.WHITE);
                        DaysOfWeek_Buttons[finalI].setTextColor(Color.BLACK);
                    }

     */

}