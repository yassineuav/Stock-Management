package tech.siham.stock_management.Fragments;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.LocationListener;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.io.IOException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import de.hdodenhof.circleimageview.CircleImageView;
import tech.siham.stock_management.Data.StaticConfig;
import tech.siham.stock_management.Model.User;
import tech.siham.stock_management.R;
import tech.siham.stock_management.utils.CustomInfoWindowGoogleMap;
import tech.siham.stock_management.utils.ItemClickListener;

import static android.content.Context.LOCATION_SERVICE;

public class FragmentMap extends Fragment implements
        LocationListener,
        GoogleApiClient.ConnectionCallbacks,
        GoogleApiClient.OnConnectionFailedListener ,
        OnMapReadyCallback {

    GoogleMap mGoogleMap;
    SupportMapFragment mapFrag;

    ProgressDialog progressDialog;
    FloatingActionButton FAB;

    public double x = 0;
    public double y = 0;
    String myAddress = "";
    Geocoder geocoder;
    List<Address> addresses;
    LocationManager locationManager;

    DatabaseReference mDatabase;

    viewAdapter recycler;
    RecyclerView recyclerview;
    EditText Search;
    LinearLayout LinearLayout_Search;

    List<User> user = new ArrayList<>();
    List<User> user_list = new ArrayList<>();
    List<User> usersRcyc = new ArrayList<>();

    LocationRequest mLocationRequest;
    GoogleApiClient mGoogleApiClient;

    private static final long INTERVAL = 1000 * 2;
    private static final long FASTEST_INTERVAL = 1000 * 1;

    void createLocationRequest() {
        mLocationRequest = new LocationRequest();
        mLocationRequest.setInterval(INTERVAL);
        mLocationRequest.setFastestInterval(FASTEST_INTERVAL);
        mLocationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
    }

    public FragmentMap(){}

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View rootView =  inflater.inflate(R.layout.fragment_map, container, false);

        try {

            mDatabase = FirebaseDatabase.getInstance().getReference("Stock");

            // progressBar = (ProgressBar) rootView.findViewById(R.id.progressBar);
            recyclerview = (RecyclerView) rootView.findViewById(R.id.recycleList);
            Search = (EditText) rootView.findViewById(R.id.search);
            LinearLayout_Search = (LinearLayout) rootView.findViewById(R.id.linear_layout_top);

            mapFrag = (SupportMapFragment) getChildFragmentManager().findFragmentById(R.id.map);
            mapFrag.getMapAsync(this);

            FAB = (FloatingActionButton) rootView.findViewById(R.id.my_location);
            //  Check gps
            // SetUsersOnMap();

            locationManager = (LocationManager) (getContext()).getSystemService(LOCATION_SERVICE);
            if (!locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                // showGPSDisabledAlertToUser();
                // showSettingsAlert();
                //FAB.setVisibility(View.GONE);
            } else {
                if (x == 0 && y == 0) {
                    progressDialog = new ProgressDialog(getContext());
                    progressDialog.setIndeterminate(true);
                    progressDialog.setCancelable(false);
                    progressDialog.setMessage("Getting Location...");
                    progressDialog.show();
                    GetLocation();
                } else {
                    getmylocation();
                }
            }

        FAB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // FAB.setEnabled(false);
                // GetLocation();
                    LatLng latLng = new LatLng(x,y);
                    MarkerOptions markerOptions = new MarkerOptions();
                    markerOptions.position(latLng)
                        .snippet(myAddress)
                        .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_BLUE));
                    CameraUpdate cameraUpdate = CameraUpdateFactory.newLatLngZoom(latLng, 12);
                    mGoogleMap.animateCamera(cameraUpdate);
                    mGoogleMap.addMarker(markerOptions);
            }
        });
        }catch (Exception e){msg("error 4444: "+e);}

        /*
        Search.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {}
            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {}
            @Override
            public void afterTextChanged(Editable editable) {
                String text = Search.getText().toString();
                if (text.length() > 0) {
                    Query query = mDatabase.orderByChild("Stock").startAt(text).endAt("~");
                    query.addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(DataSnapshot dataSnapshot) {
                            usersRcyc.clear();
                            if (dataSnapshot.exists()) {
                                for (DataSnapshot postSnapshot : dataSnapshot.getChildren()) {
                                    try {
                                        User user_data = postSnapshot.getValue(User.class);
                                        usersRcyc.add(user_data);
                                    } catch (Exception e) { msg("error 6723 : " + e);}
                                }
                                recyclerview.setVisibility(View.VISIBLE);
                            } else {
                                msg("no items found");
                            }

                            recycler = new viewAdapter(getContext(), usersRcyc);
                            RecyclerView.LayoutManager layoutmanager = new LinearLayoutManager(getContext(), LinearLayoutManager.HORIZONTAL, false);
                            recyclerview.setLayoutManager(layoutmanager);
                            recyclerview.setItemAnimator(new DefaultItemAnimator());
                            recyclerview.setAdapter(recycler);
                            recycler.setClickListener(new ItemClickListener() {
                                @Override
                                public void onClickItems(View view, int position) {
                                    String idpost = usersRcyc.get(position).userID;
                                    //SetUsersOnMap(get id );
                                    recyclerview.setVisibility(View.GONE);
                                }
                            });}
                        @Override
                        public void onCancelled(DatabaseError databaseError) {}});

                } else {

                    recyclerview.setVisibility(View.GONE);
                    usersRcyc.clear();
                    recycler = new viewAdapter(getContext(), usersRcyc);
                    RecyclerView.LayoutManager layoutmanager = new LinearLayoutManager(getContext());
                    recyclerview.setLayoutManager(layoutmanager);
                    recyclerview.setItemAnimator(new DefaultItemAnimator());
                    recyclerview.setAdapter(recycler);
                }
            }
        });

         */
        return  rootView;
    }

    @Override
    public void onConnected(Bundle bundle) {
        try {
            LocationServices.FusedLocationApi.requestLocationUpdates(mGoogleApiClient, mLocationRequest, this);
        } catch (SecurityException e) {}
    }
    protected void stopLocationUpdates() {
        LocationServices.FusedLocationApi.removeLocationUpdates(mGoogleApiClient, this);
    }

    @Override
    public void onConnectionSuspended(int i) {}

    @Override
    public void onLocationChanged(Location location) {
        // StopTime = System.currentTimeMillis();
        //  long diff = StopTime - StartTime;
        // diff = TimeUnit.MILLISECONDS.toSeconds(diff);
        // msg("delay Time : " + diff + " seconds");
        x = location.getLatitude();
        y = location.getLongitude();
        progressDialog.dismiss();
        stopLocationUpdates();
        getmylocation();
        FAB.setEnabled(true);
        if (mGoogleApiClient.isConnected())
            mGoogleApiClient.disconnect();
    }

    @Override
    public void onConnectionFailed(ConnectionResult connectionResult) {}

    void GetLocation() {
        try {
            createLocationRequest();
            mGoogleApiClient = new GoogleApiClient.Builder(getContext())
                    .addApi(LocationServices.API)
                    .addConnectionCallbacks(this)
                    .addOnConnectionFailedListener(this)
                    .build();
            mGoogleApiClient.connect();
        }catch(Exception e){}
    }

    void msg(String text) {
        Toast.makeText(getContext(), text, Toast.LENGTH_LONG).show();
    }

    private float getDistance(double lat1, double lon1, double lat2, double lon2) {
        float[] distance = new float[2];
        Location.distanceBetween(lat1, lon1, lat2, lon2, distance);
        return distance[0] / 1000;
    }

    void getmylocation(){
        try {

            geocoder = new Geocoder(getContext(), Locale.ENGLISH);
            addresses = geocoder.getFromLocation(x, y, 1);
            StringBuilder str = new StringBuilder();
            if (geocoder.isPresent()) {
                Address returnAddress = addresses.get(0);
                String cc = returnAddress.getFeatureName();
                String localityString = returnAddress.getLocality();
                String city = returnAddress.getCountryName();
                str.append(cc + ", ");
                str.append(localityString + ", ");
                str.append(city + "");
                myAddress = str.toString();
            } else {}
        } catch (IOException e) {}

        LatLng latLng = new LatLng(x, y);
        MarkerOptions markerOptions = new MarkerOptions();
        markerOptions.position(latLng)
                .snippet(myAddress)
                .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_BLUE));

        // .icon(BitmapDescriptorFactory.fromResource(R.drawable.edit_icon));
        SetUsersOnMap();
        CameraUpdate cameraUpdate = CameraUpdateFactory.newLatLngZoom(latLng, 12);
        mGoogleMap.animateCamera(cameraUpdate);
        mGoogleMap.addMarker(markerOptions);
    }

    public void SetUsersOnMap() {
        try {
            mDatabase.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {
                    if (dataSnapshot.exists()){
                        try {
                            user.clear();
                            user_list.clear();
                            for (DataSnapshot postSnapshot : dataSnapshot.getChildren()) {
                                User userData = postSnapshot.getValue(User.class);
                                user.add(userData);
                                user_list.add(userData);
                                // if(getDistance(petsdata.coordinates.latitude, petsdata.coordinates.longitude, x, y) <= 50){
                            }

                            MarkerOptions markerOptions = new MarkerOptions();
                            int i = 0;
                            for (User user_data : user) {

                                LatLng latLng = new LatLng(user_data.coordinates.latitude, user_data.coordinates.longitude);
                                markerOptions
                                            .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_GREEN))
                                            .position(latLng)
                                            .snippet(String.valueOf(i));

                                user.get(i).distance = getDistance(user_data.coordinates.latitude, user_data.coordinates.longitude, x, y);
                                mGoogleMap.addMarker(markerOptions);

                                if (StaticConfig.UID.equals(user_data.userID)) {
                                    markerOptions
                                            .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_BLUE))
                                            .position(latLng)
                                            .snippet(String.valueOf(i));
                                        Marker m = mGoogleMap.addMarker(markerOptions);
                                        CameraUpdate cameraUpdate = CameraUpdateFactory.newLatLngZoom(latLng, 16);
                                        mGoogleMap.animateCamera(cameraUpdate);
                                        user.get(i).distance = getDistance(user_data.coordinates.latitude, user_data.coordinates.longitude, x, y);
                                        m.showInfoWindow();
                                        i++;
                                    } else {
                                        //.icon(BitmapDescriptorFactory.fromResource(TypeMarker[p]))
                                        markerOptions
                                                .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_RED))
                                                .position(latLng)
                                                .snippet(String.valueOf(i));
                                        user.get(i).distance = getDistance(user_data.coordinates.latitude, user_data.coordinates.longitude, x, y);
                                        i++;
                                        mGoogleMap.addMarker(markerOptions);
                                    }

                                }

                                CustomInfoWindowGoogleMap customInfoWindow = new CustomInfoWindowGoogleMap(getContext(), user);
                                mGoogleMap.setInfoWindowAdapter(customInfoWindow);


                        }catch (Exception e){printToast("Error to set users mark on map  : "+e); }
                    } else {msg("no items found");}
                }
                @Override
                public void onCancelled(DatabaseError databaseError) {}
            });
        }catch (Exception e){printToast("Error 234 : "+e);}}


    @Override
    public void onMapReady(GoogleMap googleMap) {
        mGoogleMap = googleMap;
        if (ActivityCompat.checkSelfPermission(getContext(), Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(getContext(), Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            return;
        }

        mGoogleMap.setOnInfoWindowClickListener(new GoogleMap.OnInfoWindowClickListener(){
            @Override
            public void onInfoWindowClick(Marker marker) {
                try {

                    // show details on dialog
                    // invite button if available
                    /*

                    final int i = Integer.parseInt(marker.getSnippet());
                    startActivity(new Intent(getContext(), ShowDetails.class)
                            .putExtra("distance", new DecimalFormat("###.#").format(pets.get(i).distance))
                            .putExtra("iduser",pets.get(i).adminID)
                            .putExtra("idpost",pets.get(i).userID));
                    */
                }catch(Exception e){}
            }
        });
    }

    private void printToast(String message) {
        Toast.makeText(getContext(), message, Toast.LENGTH_LONG).show();
    }

    class viewAdapter extends RecyclerView.Adapter<viewAdapter.MyHolder> {
        private Context context;
        List<User> pet;
        private ItemClickListener clickListener;
        public viewAdapter(Context context, List<User> pet) {this.pet = pet;this.context = context;}
        public void setClickListener(ItemClickListener itemClickListener){this.clickListener = itemClickListener;}
        @Override
        public MyHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.rc_item_store_image_name, parent, false);
            MyHolder myHolder = new MyHolder(view);
            return myHolder;
        }

        public void onBindViewHolder(MyHolder holder, int position) {
            User data = pet.get(position);
            holder.name.setText(data.fullName);
        }

        @Override
        public int getItemCount() {
            return pet.size();
        }
        class MyHolder extends RecyclerView.ViewHolder {
            TextView name;
            CircleImageView imgAvatar;
            private final Context context;
            public MyHolder(final View itemView) {
                super(itemView);
                context = itemView.getContext();
                final Intent[] intent = new Intent[1];
                name = (TextView) itemView.findViewById(R.id.shopName);
                imgAvatar = (CircleImageView) itemView.findViewById(R.id.img_avatar);
                itemView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        try {
                            //if (clickListener != null) clickListener.onClickItems(v, getAdapterPosition());
                            //String idpost = pet.get(getAdapterPosition()).getIdPost();
                            //msg(idpost);
                        } catch (Exception e) {
                            msg("error 3345 : " + e);
                        }
                    }

                });
            }
            void msg(String text){
                Toast.makeText(context, text, Toast.LENGTH_SHORT).show();
            }
        }
    }
}
