package tech.siham.stock_management.Model;

import com.google.firebase.database.IgnoreExtraProperties;

import java.util.ArrayList;
import java.util.List;

@IgnoreExtraProperties
public class Category {
  public Category(){
    productsList = new ArrayList<>();
  }

  public String categoryName;
  public String categoryID;
  public String productID;
  public String adminID;
  public String imagePath;
  public String imageName;
  public Long itemsNumber;
  /*
  management stock
  POS
   */
  public List<ListProducts> productsList;

}
