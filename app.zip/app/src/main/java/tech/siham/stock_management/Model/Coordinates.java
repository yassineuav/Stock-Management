package tech.siham.stock_management.Model;

public class Coordinates {
    public  double latitude;
    public double longitude;
    public Coordinates(){}
}
