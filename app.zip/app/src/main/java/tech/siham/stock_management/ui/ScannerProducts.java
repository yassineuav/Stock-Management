package tech.siham.stock_management.ui;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import tech.siham.stock_management.Model.MyBasket;
import tech.siham.stock_management.R;

import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class ScannerProducts extends AppCompatActivity {

    //recyclerview object
    private RecyclerView recyclerView;
    //adapter object
    private MyAdapter adapterView;
    //database reference
    private DatabaseReference mDatabase;
    private DatabaseReference mDatabase2;
    //progress dialog
    private ProgressDialog progressDialog;
    //list to hold all the uploaded images
    private List<MyBasket> basketList = new ArrayList<>();
    // TextView toolbarDetails;
    String IdOrder ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scanner_products);

            // Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
            // setSupportActionBar(toolbar);
            // Get a support ActionBar corresponding to this toolbar
            // ActionBar ab = getSupportActionBar();
            // Enable the Up button
            // ab.setDisplayHomeAsUpEnabled(true);
            // ab.setTitle("Scanning Products");

            // getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            // getSupportActionBar().setTitle("Scanning Products");
            // provide compatibility to all the versions

            /// toolbarDetails = (TextView) findViewById(R.id.toolbarDetails);

            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("Scan Products");

            recyclerView = (RecyclerView) findViewById(R.id.recyclerView);

            recyclerView.setLayoutManager(new LinearLayoutManager(this));

            progressDialog = new ProgressDialog(this);
            //displaying progress dialog while fetching images
            progressDialog.setMessage("Please wait...");
            progressDialog.show();

            IdOrder = getIntent().getStringExtra("orderID");
            if (IdOrder == null) {
                msg("no order id found!!\ntry again");
                return;
            }


            mDatabase = FirebaseDatabase.getInstance().getReference("Orders").child(IdOrder).child("myBasket");
            mDatabase2 = FirebaseDatabase.getInstance().getReference("Orders").child(IdOrder);
            //adding an event listener to fetch values

            mDatabase.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot snapshot) {
                    progressDialog.dismiss();

                    try {
                        // dismissing the progress dialog
                        basketList.clear();

                    if (snapshot.exists()) {

                        int itemsNumber = 0, ScannedItemsNumber = 0, QuantityPackets = 0, scannedPackets = 0;

                        for (DataSnapshot postSnapshot : snapshot.getChildren()) {
                            MyBasket upload = postSnapshot.getValue(MyBasket.class);
                            upload.basketID = postSnapshot.getKey();

                            QuantityPackets += upload.packets;
                            itemsNumber += 1;
                            if(upload.status == "done") {
                                scannedPackets += upload.packets;
                                ScannedItemsNumber += 1;
                            }

                            basketList.add(upload);
                        }

                        if (itemsNumber > ScannedItemsNumber) {
                            // order not complete
                            mDatabase2.child("status").setValue("not_complete");
                        } else if (itemsNumber == ScannedItemsNumber) {
                            // order complete -> done
                            mDatabase2.child("status").setValue("done");
                        } else {
                            // something wrong
                            mDatabase2.child("status").setValue("except");
                        }

                        // toolbarDetails.setText("All Items Number : " + itemsNumber + " / Scanned Items Number : " + ScannedItemsNumber + "\t\t\t\t\t\t\t\tPackets Orders : " + QuantityPackets + "/ Scanned Packets : " + scannedPackets);
                        // creating adapter
                        adapterView = new MyAdapter(ScannerProducts.this, basketList);
                        //adding adapter to recyclerview
                        recyclerView.setAdapter(adapterView);
                        adapterView.notifyDataSetChanged();

                    } else {
                        // show message add new Category
                    }

                    }catch (Exception e){ msg("Error 2254: "+e);}

                }
                @Override
                public void onCancelled(DatabaseError databaseError) {
                    progressDialog.dismiss();
                }
            });




        }

    void msg(String text){
        Toast.makeText(ScannerProducts.this, text, Toast.LENGTH_LONG).show();
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if(id == android.R.id.home) {
            onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }


    private class MyAdapter extends RecyclerView.Adapter<MyAdapter.ViewHolder> {
        private Context context;
        private List<MyBasket> myBasketList ;

        public MyAdapter(Context context, List<MyBasket> myBasketList ) {
            this.myBasketList = myBasketList;
            this.context = context;
        }

        @Override
        public MyAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_product_scanner, parent, false);
            MyAdapter.ViewHolder viewHolder = new MyAdapter.ViewHolder(v);
            return viewHolder;
        }

        @Override
        public void onBindViewHolder(MyAdapter.ViewHolder holder, int position) {
            MyBasket myBasket = myBasketList.get(position);

            try{
                holder.DataDetails.setText(
                    "Product Name : " + myBasket.productName +
                            "\nStatus : "+myBasket.status +
                            "\nBarCode : "+ myBasket.barCode +
                            "\n"+ Integer.toString(myBasket.unities) +" Unities at One Packet"+
                            "\nOrders Quantity  : "+ Integer.toString(myBasket.packets) +" packets "+
                            "\nPrice of one Unity : "+ Double.toString(myBasket.price) +" Euro"+
                            "\nTotal Price : " + Double.toString(myBasket.total) + " Euro" );

                Glide.with(context).load(myBasket.imagePath).into(holder.imageViewCategory);

                int StatusColor = 0;
                switch (myBasket.status){
                    case "pending":
                        StatusColor = Color.BLUE;
                        break;
                    case "done":
                        StatusColor = Color.GREEN;
                        holder.ScannerProductStatus.setBackgroundColor(Color.GREEN);
                        holder.ScannerProductStatus.setImageResource(R.drawable.ic_accept_cr_group);
                        break;
                    case "except":
                        StatusColor = Color.RED;
                        break;
                    case "not_complete":
                        StatusColor = Color.YELLOW;
                        break;
                }
                holder.StatusColor.setBackgroundColor(StatusColor);

            /*
             - ic_float_button
             - ic_accept_cr_group

             */
            }catch (Exception e){ msg("Error 3354: "+e);}

        }

        @Override
        public int getItemCount() {
            return myBasketList.size();
        }

        class ViewHolder extends RecyclerView.ViewHolder {

            public TextView DataDetails;
            public ImageView imageViewCategory, ScannerProductStatus ;
            public Button Save, Cancel;
            EditText NumberOfPackets;
            Dialog dialog;
            ImageView StatusColor;
            private final Context context;


            public ViewHolder(View itemView) {

                super(itemView);
                context = itemView.getContext();
                final Intent[] intent = new Intent[1];

                DataDetails = (TextView) itemView.findViewById(R.id.dataDetails);
                imageViewCategory = (ImageView) itemView.findViewById(R.id.imageViewCategory);
                ScannerProductStatus = (ImageView) itemView.findViewById(R.id.scannerProduct);
                StatusColor = (ImageView) itemView.findViewById(R.id.statusColor);

                // dialog items

                ScannerProductStatus.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        /*
                        show dialog to add number
                        number of quantity orders packets -equal to- added number
                        change status of product name id to "done"
                         */

                        View viewInflater = LayoutInflater.from(ScannerProducts.this).inflate(R.layout.set_number_of_packets, null, false);
                        Save = (Button) viewInflater.findViewById(R.id.save);
                        Cancel = (Button) viewInflater.findViewById(R.id.cancel);
                        NumberOfPackets = (EditText) viewInflater.findViewById(R.id.numberOfPackets);

                        dialog = new Dialog(ScannerProducts.this);
                        dialog.setContentView(viewInflater);
                        dialog.show();
                        NumberOfPackets.setText(String.valueOf(myBasketList.get(getAdapterPosition()).packets));

                        Save.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                if(!TextUtils.isEmpty(NumberOfPackets.getText())){

                                    int QuantityNumber = Integer.parseInt(NumberOfPackets.getText().toString().trim());

                                    if( QuantityNumber == myBasketList.get(getAdapterPosition()).packets){

                                        mDatabase.child(myBasketList.get(getAdapterPosition()).basketID).child("status").setValue("done").addOnCompleteListener(new OnCompleteListener<Void>() {
                                            @Override
                                            public void onComplete(@NonNull Task<Void> task) {
                                                if (task.isSuccessful()) {
                                                    // show dialog for
                                                    // Toast.makeText(ScannerProducts.this, "Product "+myBasketList.get(getAdapterPosition()).productName+ " Scanned Successfully", Toast.LENGTH_LONG).show();
                                                }else {
                                                    // Toast.makeText(ScannerProducts.this, "Failed to Add "+myBasketList.get(getAdapterPosition()).productName+"\nPlease try again", Toast.LENGTH_LONG).show();
                                                }
                                            }
                                        });

                                    }else {
                                        Toast.makeText(ScannerProducts.this, "Number of Orders Packets not matched with Current number \nPlease make sure ...!", Toast.LENGTH_LONG).show();
                                    }
                                }else {
                                    NumberOfPackets.setError("Your Should put number of Quantity Already Ordered ");
                                }
                                dialog.dismiss();
                            }
                        });

                        Cancel.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                dialog.dismiss();
                            }
                        });
                    }
                });

                itemView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        /*
                        String CategoryName = categories.get(getAdapterPosition()).categoryName;
                        String CategoryID = categories.get(getAdapterPosition()).categoryID;
                        intent[0] = new Intent(context, ActivityItemsView.class);
                        intent[0].putExtra("CategoryID", CategoryID);
                        intent[0].putExtra("CategoryName", CategoryName);
                        context.startActivity(intent[0]);
                       */
                    }
                });
            }
        }
    }
}