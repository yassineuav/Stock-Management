package tech.siham.stock_management.ui;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Random;

import tech.siham.stock_management.Data.DBHelper;
import tech.siham.stock_management.Data.SharedPreferenceHelper;
import tech.siham.stock_management.Data.StaticConfig;
import tech.siham.stock_management.Model.Category;
import tech.siham.stock_management.Model.ListProducts;
import tech.siham.stock_management.Model.MyBasket;
import tech.siham.stock_management.Model.Order;
import tech.siham.stock_management.Model.User;
import tech.siham.stock_management.R;

import static tech.siham.stock_management.ui.orderProductsActivity.mySupplierData;

public class addToCardActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private RecyclerView.Adapter adapter;
    private DatabaseReference mDatabase;
    private ProgressDialog progressDialog;
    private List<Category> categories = new ArrayList<>();

    String mySupplierID = "";
    String currency = "$";

    TextView DetailsSubTotalPrice ;
    Button ConfirmOrder, CancelOrder ;
    TextView describeTxt;

    Order myOrder = new Order();

    Dialog dialog = null;
    DBHelper db;
    SharedPreferenceHelper sharedPreference;
    User userData = new User();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_to_card);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle("Order Products");
        // provide compatibility to all the versions
        // setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);

        mySupplierID = getIntent().getStringExtra("supplierID");
        sharedPreference = SharedPreferenceHelper.getInstance(this);
        userData = sharedPreference.getUserInfo();

        if(mySupplierID == null){
            msg("try again something is wrong\nsupplier id is null");
            return;
        }

        db = new DBHelper(this);

        currency = mySupplierData.currency;

        progressDialog = new ProgressDialog(this);
        //displaying progress dialog while fetching images
        progressDialog.setMessage("Please wait...");
        progressDialog.show();
        mDatabase = FirebaseDatabase.getInstance().getReference();

        DetailsSubTotalPrice = (TextView) findViewById(R.id.detailsSubTotalPrice);

        ConfirmOrder = (Button) findViewById(R.id.confirmOrder);
        CancelOrder = (Button)  findViewById(R.id.cancelOrder);

        dialog = new Dialog(this);
        View viewInflater = LayoutInflater.from(this).inflate(R.layout.confirm_order_dialog, null, false);
        Button confirmBtn = (Button) viewInflater.findViewById(R.id.confirm);
        Button cancelBtn = (Button) viewInflater.findViewById(R.id.cancel);
        describeTxt = (TextView) viewInflater.findViewById(R.id.describe);
        dialog.setContentView(viewInflater);

        ConfirmOrder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.show();
                // if user wanna add new order in same range time
                // go to old order between range time 7 days
                // edit order add products
            }
        });

        confirmBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                    setOrder();
            }
        });
        cancelBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });

        CancelOrder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // clear basket
                // refresh page
                // categories.clear();

                dialog.dismiss();
                db.deleteTable();
                // SetDetailsToolBar();
                // fetchDataByCategories();
            }
        });

        ConfirmOrder.setVisibility(View.GONE);
        CancelOrder.setVisibility(View.GONE);


        recyclerView = (RecyclerView) findViewById(R.id.recyclerView);
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());

        //adding an event listener to fetch values
        mDatabase.child("Categories").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                //dismissing the progress dialog
                progressDialog.dismiss();
                categories.clear();
                if(snapshot.exists()){
                    //iterating through all the values in database
                    for (DataSnapshot postSnapshot : snapshot.getChildren()) {
                        Category upload = postSnapshot.getValue(Category.class);
                        if(upload.adminID.equals(mySupplierID) && postSnapshot.child("Products").exists()){
                            // display if category has products
                            categories.add(upload);
                        }
                    }
                    //creating adapter
                    adapter = new MyAdapter(addToCardActivity.this, categories);
                    adapter.notifyDataSetChanged();
                    recyclerView.setAdapter(adapter);
                }else{
                    // show message add new Category
                    msg("no category exist!!!");
                }
            }
            @Override
            public void onCancelled(DatabaseError databaseError) {
                progressDialog.dismiss();
            }
        });
    }

    void msg(String text){
        Toast.makeText(addToCardActivity.this, text, Toast.LENGTH_SHORT).show();
    }


    public void SetDetailsToolBar(){
        // get basket get total price and number of items
        int unities = 0;
        int packets = 0;
        double SubTotal = 0;
        for(MyBasket my_Basket : db.getAllBaskets()){
            unities += (my_Basket.unities * my_Basket.packets);
            packets += my_Basket.packets;
            SubTotal += my_Basket.total;
        }
        boolean confirm = false;
        if(SubTotal >= StaticConfig.StartPrice){
            confirm = true;
            ConfirmOrder.setVisibility(View.VISIBLE);
            CancelOrder.setVisibility(View.VISIBLE);
        }else {
            ConfirmOrder.setVisibility(View.GONE);
            CancelOrder.setVisibility(View.GONE);
        }

        // updateAlertIcon(packets, confirm);
        ConfirmOrder.setText("Check Out\t"+String.format("%.2f", SubTotal)+ currency +"\t\t");
        DetailsSubTotalPrice.setText(
                "Packets : "+packets+
                        " QTY\t\t" +unities+
                        " Unities\t\tTotal Price : "+String.format("%.2f", SubTotal)+ currency);

        describeTxt.setText(Html.fromHtml("<h1>Confirm your Order</h1>" +
                "<h2>Total Price "+ String.format("%.2f", SubTotal)+" "+currency +
                "</h2><h3>Delivery Day is "+StaticConfig.DayToDelivery+"</h3>"
        ));

    }

    private void setOrder(){
        Date date = new Date();
        DateFormat sdf_us = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
        DateFormat sdf_uk = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");

        // Order myOrder = new Order();
        // IDs Order

        myOrder.adminID = mySupplierID;
        myOrder.fullName = userData.fullName;
        myOrder.storeAddress = userData.address;
        myOrder.storeName = userData.storeName;
        myOrder.userID = StaticConfig.UID;
        myOrder.orderID = mDatabase.push().getKey();

        // set random track number
        // create instance of Random class
        Random rand = new Random();
        // Generate random integers in range 0 to 999
        // ThreadLocalRandom.current().nextInt();
        myOrder.trackNumber = rand.nextInt(10000);
        // date time to delivery order
        // day at week work
        myOrder.DayToDeliveryOrder = StaticConfig.DayToDelivery;
        myOrder.dateTimeToPostOrder = sdf_uk.format(date);
        myOrder.status = "pending";
        myOrder.description = "";
        myOrder.orderFrom = "Stock";

        int unities = 0;
        int packets = 0;
        double Total = 0;

        for(MyBasket my_Basket : db.getAllBaskets()){
            unities += (my_Basket.unities * my_Basket.packets);
            packets += my_Basket.packets;
            Total += my_Basket.total;
        }
        myOrder.packets = packets;
        myOrder.totalPrice = Total;
        // myOrder.myBasket = db.getAllBaskets();
        mDatabase.child("Orders").child(myOrder.orderID).setValue(myOrder).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if(task.isSuccessful()){
                    for(MyBasket my_basket : db.getAllBaskets()){
                        mDatabase.child("Orders").child(myOrder.orderID).child("myBasket").child(my_basket.basketID).setValue(my_basket);
                    }
                    msg("Successful");
                    db.deleteTable();
                    SetDetailsToolBar();
                    dialog.dismiss();

                    ConfirmOrder.setVisibility(View.GONE);
                    CancelOrder.setVisibility(View.GONE);
                    // go to histories order
                }else{
                    msg("try again data not saved!!!");
                }
            }
        });
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == android.R.id.home) {
            onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }


    private class MyAdapter extends RecyclerView.Adapter<MyAdapter.ViewHolder> {
        private Context context;
        private List<Category> categories;

        public MyAdapter(Context context, List<Category> categories) {
            this.categories = categories;
            this.context = context;
        }

        @Override
        public MyAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_add_to_card, parent, false);
            MyAdapter.ViewHolder viewHolder = new MyAdapter.ViewHolder(v);
            return viewHolder;
        }

        @Override
        public void onBindViewHolder(MyAdapter.ViewHolder holder, int position) {

            Category category = categories.get(position);
            holder.DataDetails.setText(category.categoryName);
            Glide.with(context).load(category.imagePath).into(holder.imageViewCategory);

            fetchDataByCategories(category.categoryID, holder);
         }
        @Override
        public int getItemCount() { return categories.size(); }
        class ViewHolder extends RecyclerView.ViewHolder {
            public RecyclerView recyclerViewProducts;

            public TextView DataDetails;
            public EditText searchText;
            public ImageView imageViewCategory, searchProduct;

            private final Context context;
            public ViewHolder(View itemView) {

                super(itemView);
                context = itemView.getContext();
                final Intent[] intent = new Intent[1];

                recyclerViewProducts = (RecyclerView) itemView.findViewById(R.id.recyclerViewProducts);
                recyclerViewProducts.setLayoutManager(new LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false));
                recyclerViewProducts.setItemAnimator(new DefaultItemAnimator());

                DataDetails = (TextView) itemView.findViewById(R.id.dataDetails);
                imageViewCategory = (ImageView) itemView.findViewById(R.id.imageViewCategory);
                searchProduct = (ImageView) itemView.findViewById(R.id.search_image);
                searchText = (EditText) itemView.findViewById(R.id.search_text);
                searchProduct.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) { }
                });
            }
        }
    }

    public void fetchDataByCategories(String categoryID, final MyAdapter.ViewHolder holder){
        mDatabase.child("Categories").child(categoryID).child("Products").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                try {
                    // dismissing the progress dialog
                    progressDialog.dismiss();
                    if(dataSnapshot.exists()) {
                        List<ListProducts> MyListProducts = new ArrayList<>();
                        // MyListProducts.clear();
                        for (DataSnapshot postSnapshot1 : dataSnapshot.getChildren()) {
                            ListProducts listProducts = postSnapshot1.getValue(ListProducts.class);
                            MyListProducts.add(listProducts);
                        }
                        // ProductsViewAdapter recycler = new ProductsViewAdapter(addToCardActivity.this, MyListProducts);
                        // holder.recyclerViewProducts.setAdapter(recycler);
                        holder.recyclerViewProducts.setAdapter(new ProductsViewAdapter(addToCardActivity.this, MyListProducts));
                        // recycler.notifyDataSetChanged();
                    }
                }catch (Exception e){msg("Error in fetch data by categories : "+e);}
            }
            @Override
            public void onCancelled(DatabaseError databaseError){}
        });
    }

    public class ProductsViewAdapter extends RecyclerView.Adapter<ProductsViewAdapter.MyHolder> {
        private Context context;
        List<ListProducts> listProducts;
        public ProductsViewAdapter(Context context, List<ListProducts> listProducts) {
            this.listProducts = listProducts;
            this.context = context;
        }
        @Override
        public ProductsViewAdapter.MyHolder onCreateViewHolder(ViewGroup parent, int viewType){
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_basket_product, parent, false);
            ProductsViewAdapter.MyHolder myHolder = new ProductsViewAdapter.MyHolder(view);
            return myHolder;
        }
        public void onBindViewHolder(ProductsViewAdapter.MyHolder holder, int position) {
            ListProducts data = listProducts.get(position);
            Glide.with(context).load(data.imagePath).into(holder.ProductImage);
            double[] Prices = {data.sellPriceStock,
                    data.sellPriceStore,
                    data.sellPriceDeliverer,
                    data.sellPriceCustomer};
            int i = 0;
            switch (userData.orderFrom){
                case "Stock":
                    i = 0;
                case "Store":
                    i = 1;
                    break;
                case "Deliver":
                    i = 2;
                    break;
                case "Customer":
                    i = 3;
                    break;
            }

            holder.ItemName.setText(data.productName);
            holder.ItemDescribe.setText(data.description);
            holder.NormalPrice.setText(Html.fromHtml("<strike>"+data.discountPrice+"</strike> "+ currency));
            holder.NewPrice.setText(Prices[i]+ currency); //"€"

            for(MyBasket my_basket : db.getAllBaskets()) {
                if (my_basket.productID.equals(data.productID)) {
                    if (my_basket.packets == 0) {
                        // show dialog
                        holder.AddToCart.setVisibility(View.VISIBLE);
                        holder.AddToCartDialog.setVisibility(View.GONE);
                        holder.CartProductDetails.setVisibility(View.GONE);
                    } else {
                        holder.AddToCart.setVisibility(View.GONE);
                        holder.AddToCartDialog.setVisibility(View.VISIBLE);
                        holder.CartProductDetails.setVisibility(View.VISIBLE);
                        if (my_basket.packets == 1) {
                            // change subtraction icon to ( x )
                            holder.SubtractItem.setImageDrawable(getResources().getDrawable(R.drawable.delete_item));
                        } else {
                            // change subtraction icon to ( - )
                            holder.SubtractItem.setImageDrawable(getResources().getDrawable(R.drawable.subtract_item));
                        }
                    }

                    SetDetailsToolBar();
                    holder.ItemsNumber.setText(Integer.toString(my_basket.packets * my_basket.unities));
                    //SetDetailsCart(Unities, Packets, Price);
                    holder.CartProductDetails.setText(my_basket.packets + "x" + my_basket.unities + "x" +
                            my_basket.price + "=" + String.format("%.2f", (my_basket.packets * my_basket.unities * my_basket.price)) + currency);

                }
            }
        }

        @Override
        public int getItemCount() {
            return listProducts.size();
        }

        class MyHolder extends RecyclerView.ViewHolder {

            private Context context;
            ImageView ProductImage;
            TextView ItemDescribe, ItemName, AddToCart, CartProductDetails, NewPrice, NormalPrice;
            RelativeLayout AddToCartDialog;
            ImageView AddItem, SubtractItem;
            TextView ItemsNumber;
            LinearLayout rootView;

            void SetDetailsCart(int unities,int packets, double price){
                CartProductDetails.setText(packets +"x"+unities +"x"+
                        price+"="+ String.format("%.2f", (packets * unities * price))+currency);
            }

            void setCart(String type){
                try {
                    int packets = 0;
                    int unities = 0;
                    double price = 0.00;
                    switch (type){
                        case "new":
                            //add barCode
                            AddToCart.setVisibility(View.GONE);
                            AddToCartDialog.setVisibility(View.VISIBLE);
                            CartProductDetails.setVisibility(View.VISIBLE);
                            // add one item to my basket
                            // get basket position add one
                            MyBasket myCart = new MyBasket();
                            // myCart.listProducts = listProducts.get(getAdapterPosition());
                            double[] Prices = {
                                    listProducts.get(getAdapterPosition()).sellPriceStock,
                                    listProducts.get(getAdapterPosition()).sellPriceStore,
                                    listProducts.get(getAdapterPosition()).sellPriceDeliverer,
                                    listProducts.get(getAdapterPosition()).sellPriceCustomer};
                            int i = 0;
                            switch (userData.orderFrom){
                                case "Stock":
                                    i = 0;
                                case "Store":
                                    i = 1;
                                    break;
                                case "Deliver":
                                    i = 2;
                                    break;
                                case "Customer":
                                    i = 3;
                                    break;
                            }

                            myCart.price = Prices[i];
                            price = myCart.price;
                            myCart.unities = listProducts.get(getAdapterPosition()).unities;
                            myCart.imagePath = listProducts.get(getAdapterPosition()).imagePath;
                            myCart.productName = listProducts.get(getAdapterPosition()).productName;
                            myCart.productID = listProducts.get(getAdapterPosition()).productID;
                            myCart.describe = listProducts.get(getAdapterPosition()).description;
                            myCart.categoryID = listProducts.get(getAdapterPosition()).categoryID;
                            myCart.barCode = listProducts.get(getAdapterPosition()).barCode;
                            myCart.status = "pending";
                            myCart.position = 0;

                            myCart.packets = 1;
                            packets = myCart.packets;
                            unities = myCart.unities;

                            myCart.basketID = mDatabase.push().getKey();
                            myCart.total = (myCart.packets * myCart.unities * myCart.price);
                            db.insertBasket(myCart);
                            //myBasket.add(myCart.position, myCart);
                            //myBasket.add(myCart);

                            break;
                        case "add":

                            for(MyBasket myBasketID : db.getAllBaskets()){
                                String productID = myBasketID.productID;
                                if(productID.equals(listProducts.get(getAdapterPosition()).productID)){
                                    packets = myBasketID.packets + 1;
                                    unities = myBasketID.unities;
                                    price = myBasketID.price;
                                    double total = (packets * myBasketID.unities * myBasketID.price);
                                    db.updateBasket(productID, packets, total);
                                }
                            }
                            break;
                        case "sub":
                            for(MyBasket myBasketID : db.getAllBaskets()){
                                String productID = myBasketID.productID;
                                if(productID.equals(listProducts.get(getAdapterPosition()).productID)){
                                    packets = myBasketID.packets - 1;
                                    unities = myBasketID.unities;
                                    price = myBasketID.price;
                                    double total = (packets * myBasketID.unities * myBasketID.price);
                                    if (packets == 0) {
                                        // show dialog
                                        AddToCart.setVisibility(View.VISIBLE);
                                        AddToCartDialog.setVisibility(View.GONE);
                                        CartProductDetails.setVisibility(View.GONE);
                                        db.deleteBasket(productID);
                                    }else {
                                        db.updateBasket(productID, packets, total);
                                    }
                                }
                            }
                            break;
                    }

                    if(packets < 2) {
                        // change subtraction icon to ( x )
                        SubtractItem.setImageDrawable(getResources().getDrawable(R.drawable.delete_item));
                    } else {
                        // change subtraction icon to ( - )
                        SubtractItem.setImageDrawable(getResources().getDrawable(R.drawable.subtract_item));
                    }

                    ItemsNumber.setText(Integer.toString(packets * unities));
                    //Toast.makeText(context, "position : " + myCart.position, Toast.LENGTH_SHORT).show();
                    SetDetailsCart(unities, packets, price);
                    SetDetailsToolBar();

                }catch (Exception e){
                    Toast.makeText(context, "error in "+type+" :\n" + e, Toast.LENGTH_LONG).show();
                }
            }

            public MyHolder(final View itemView){
                super(itemView);
                context = itemView.getContext();
                final Intent[] intent = new Intent[1];
                ProductImage = (ImageView) itemView.findViewById(R.id.productImage);
                ItemDescribe = (TextView) itemView.findViewById(R.id.itemDescribe);
                ItemName = (TextView) itemView.findViewById(R.id.itemName);
                rootView = (LinearLayout) itemView.findViewById(R.id.rootView);
                AddToCart = (TextView) itemView.findViewById(R.id.addToCart);
                CartProductDetails = (TextView) itemView.findViewById(R.id.cartProductDetails);
                AddItem = (ImageView) itemView.findViewById(R.id.addItem);
                SubtractItem = (ImageView) itemView.findViewById(R.id.subtractItem);
                AddToCartDialog = (RelativeLayout) itemView.findViewById(R.id.addToCartDialog);
                ItemsNumber = (TextView) itemView.findViewById(R.id.itemsNumber);
                NewPrice = (TextView) itemView.findViewById(R.id.rightPrice);
                NormalPrice = (TextView) itemView.findViewById(R.id.normalPrice);
                AddToCart.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        setCart("new");
                    }
                });
                AddItem.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        setCart("add");
                    }
                });
                SubtractItem.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        setCart("sub");
                    }
                });
            }
        }
    }
}