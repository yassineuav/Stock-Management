package tech.siham.stock_management;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

import tech.siham.stock_management.Model.ListProducts;
import tech.siham.stock_management.R;

public class ActivityFindBarcode extends AppCompatActivity {

    Button scannBtn;
    TextView detailsTxt;

    List<ListProducts> listProducts = new ArrayList<>();
    //database reference
    private DatabaseReference mDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_find_barcode);

        scannBtn = (Button) findViewById(R.id.scan_item);
        detailsTxt = (TextView) findViewById(R.id.detailsTxt);
        // find bar code exist

        mDatabase = FirebaseDatabase.getInstance().getReference();

        scannBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // scanBarcode("123123");
            }
        });



    }
    public void scanBarcode(final String barcode){

        mDatabase.child("Categories").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    try{

                    listProducts.clear();
                    for (DataSnapshot postSnapshot : snapshot.getChildren()) {
                        for (DataSnapshot pos_Snapshot : postSnapshot.child("Products").getChildren()) {

                            ListProducts upload = pos_Snapshot.getValue(ListProducts.class);
                            if (upload.barCode.equals(barcode)) {
                                listProducts.add(upload);
                                detailsTxt.setText(
                                        "item name:" + upload.productName +
                                                "\nitem barCode:" + upload.barCode +
                                                "\nitem category:" + upload.categoryName +
                                                "\nitem describe:" + upload.description +
                                                "\nitem price:" + upload.sellPrice +
                                                "\nitem unities:" + upload.unities);
                            } else {
                                msg("No Product Matched!");
                            }
                        }
                        }
                    }catch(Exception e){msg("error 54:"+e);}


                } else {
                    msg("No Product Found!");
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) { }
        });

    }

    public void msg(String text){
        //Snackbar.make(view, text, Snackbar.LENGTH_LONG).setAction("Action", null).show();
        Toast.makeText(ActivityFindBarcode.this, text, Toast.LENGTH_SHORT).show();
    }

}
