package tech.siham.stock_management.ui;

import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.annotation.RequiresApi;
import android.support.v4.content.FileProvider;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.webkit.MimeTypeMap;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

import tech.siham.stock_management.Data.SharedPreferenceHelper;
import tech.siham.stock_management.Data.StaticConfig;
import tech.siham.stock_management.Model.Category;
import tech.siham.stock_management.R;

import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class AddCategories extends AppCompatActivity  {

  //constant to track image chooser intent
  private static final int PICK_IMAGE_REQUEST = 2340;
  static final int REQUEST_PICTURE_CAPTURE = 1829;

  private String pictureFilePath;

  //uri to store file
  private Uri filePath;
  public String ImageName = "";

  //firebase objects
  private StorageReference storageReference;
  private DatabaseReference mDatabase;

  public Category EditCategory;
  EditText CategoryName;
  //  FloatingActionButton AddItem;
  FrameLayout addImageCategory;
  ImageView imageCategory;
  String categoryID = "";
  LinearLayout DialogSelectImage;


  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_add_categories);
    //getActionBar().setTitle("Add new Category");

    getSupportActionBar().setDisplayHomeAsUpEnabled(true);

    categoryID = getIntent().getStringExtra("categoryID");

    String categoryName = getIntent().getStringExtra("categoryName");

    if (categoryName != null) {
      getSupportActionBar().setTitle("Edit " + categoryName + " Category");
    } else {
      getSupportActionBar().setTitle("Add New Category");
    }


    Button captureButton = findViewById(R.id.capture);
    captureButton.setOnClickListener(capture);

    Button GalleryButton = findViewById(R.id.gallery);
    GalleryButton.setOnClickListener(gallery);

    DialogSelectImage = (LinearLayout) findViewById(R.id.dialog_select_image);
    mDatabase = FirebaseDatabase.getInstance().getReference("Categories");
    mDatabase.keepSynced(false);
    storageReference = FirebaseStorage.getInstance().getReference("Categories");
    //    AddItem = (FloatingActionButton) findViewById(R.id.add_new_item);

    // AddItem.setVisibility(View.GONE);

    CategoryName = (EditText) findViewById(R.id.et_nameCategory);
    imageCategory = (ImageView) findViewById(R.id.imageCategory);
    addImageCategory = (FrameLayout) findViewById(R.id.addImage);

    if (categoryID != null) {
      mDatabase.child(categoryID).addValueEventListener(new ValueEventListener() {
        @Override
        public void onDataChange(DataSnapshot dataSnapshot) {
          if (dataSnapshot.exists()) {
            EditCategory = dataSnapshot.getValue(Category.class);
            CategoryName.setText(EditCategory.categoryName);
            Glide.with(AddCategories.this).load(EditCategory.imagePath).into(imageCategory);
          } else {
            msg("no Categories found!");
            // set background image for no categories exist
          }
        }
        @Override
        public void onCancelled(DatabaseError databaseError) { }
      });
    }

    addImageCategory.setOnClickListener(new View.OnClickListener() {
      @Override
      public void onClick(View v) {
        //showFileChooser();
        DialogSelectImage.setVisibility(View.VISIBLE);
      }
    });

/*
        AddItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // IF ITEM NAME FOUND SHOW MSG ("this name Already exist")
                if(categoryID != null){
                    if(!EditCategory.categoryName.equals(CategoryName.getText().toString().trim()) && filePath == null){
                        mDatabase.child(categoryID).child("categoryName").setValue(CategoryName.getText().toString().trim());
                    }else if( !EditCategory.categoryName.equals(CategoryName.getText().toString().trim()) && (filePath != null) ) {
                        uploadFile();
                        mDatabase.child(categoryID).child("categoryName").setValue(CategoryName.getText().toString().trim());
                    }else if( EditCategory.categoryName.equals(CategoryName.getText().toString().trim()) && (filePath != null) ) {
                        uploadFile();
                    }
                }else {
                    if (!TextUtils.isEmpty(CategoryName.getText().toString().trim()))
                        uploadFile();
                }
            }
        });
    */

  }

  private View.OnClickListener capture = new View.OnClickListener() {
    @Override
    public void onClick(View view) {
      if(getPackageManager().hasSystemFeature(PackageManager.FEATURE_CAMERA)){
        sendTakePictureIntent();
      }
    }
  };

  private View.OnClickListener gallery = new View.OnClickListener() {
    @Override
    public void onClick(View view) {
      showGallery();
    }
  };

  private void sendTakePictureIntent() {
    Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
    cameraIntent.putExtra( MediaStore.EXTRA_FINISH_ON_COMPLETION, true);
    if (cameraIntent.resolveActivity(getPackageManager()) != null) {
      startActivityForResult(cameraIntent, REQUEST_PICTURE_CAPTURE);
      File pictureFile = null;
      try {
        pictureFile = getPictureFile();
      } catch (IOException ex) {
        Toast.makeText(this, "Photo file can't be created, please try again", Toast.LENGTH_SHORT).show();
        return;
      }
      if (pictureFile != null) {
        Uri photoURI = FileProvider.getUriForFile(this, "com.YassineDeveloper.mercadofikri", pictureFile);
        cameraIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);
        startActivityForResult(cameraIntent, REQUEST_PICTURE_CAPTURE);
      }
    }
  }


  private File getPictureFile() throws IOException {
    String timeStamp = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
    String pictureFile = "CATEGORY_" + timeStamp;
    File storageDir = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
    File image = File.createTempFile(pictureFile,  ".jpg", storageDir);
    pictureFilePath = image.getAbsolutePath();
    return image;
  }


  void msg(String text){
    Toast.makeText(this, text, Toast.LENGTH_SHORT).show();
  }

  private void showGallery() {
    Intent intent = new Intent();
    intent.setType("image/*");
    intent.setAction(Intent.ACTION_GET_CONTENT);
    startActivityForResult(Intent.createChooser(intent, "Select Picture"), PICK_IMAGE_REQUEST);
  }
    /*
    getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    getSupportActionBar().setTitle("Add new Adoption");
     */

  @Override
  public boolean onCreateOptionsMenu(Menu menu) {
    getMenuInflater().inflate(R.menu.menu_add_category, menu);
    return true;
  }


  @Override
  public boolean onOptionsItemSelected(MenuItem item) {
    int id = item.getItemId();
    if (id == android.R.id.home) {
      onBackPressed();
      // overridePendingTransition(R.anim.slide_from_left, R.anim.slide_to_right);
      return true;
    }else if(id == R.id.save_category){
      // IF ITEM NAME FOUND SHOW MSG ("this name Already exist")

      final String EditTextCategoryName = CategoryName.getText().toString().trim();

      if(categoryID != null){

        if(!EditCategory.categoryName.equals(EditTextCategoryName) && filePath == null){
          mDatabase.child(categoryID).child("categoryName").setValue(EditTextCategoryName);
          finish();
        }else if( !EditCategory.categoryName.equals(EditTextCategoryName) && (filePath != null) ) {
          uploadFile();
          mDatabase.child(categoryID).child("categoryName").setValue(EditTextCategoryName);
        }else if( EditCategory.categoryName.equals(EditTextCategoryName) && (filePath != null) ) {
          uploadFile();
        }

      } else {

        if (!TextUtils.isEmpty(EditTextCategoryName)){
          final String ETcategoryName = EditTextCategoryName;
          // .orderByChild("categoryName").equalTo(EditTextCategoryName).
          mDatabase.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
              boolean categoryNameAlreadyExists = false;

              if (dataSnapshot.exists()) {
                for (DataSnapshot postSnapshot : dataSnapshot.getChildren()) {
                  Category upload = postSnapshot.getValue(Category.class);
                  if (upload.adminID.equals(StaticConfig.UID) && upload.categoryName.equals(ETcategoryName)) {
                    categoryNameAlreadyExists = true;
                  }
                }

              }

              if (categoryNameAlreadyExists) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
                  CategoryName.setBackground(getResources().getDrawable(R.drawable.bt_shape_red));
                }
                // msg(ETcategoryName + " is already exists !");
              } else {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
                  CategoryName.setBackground(getResources().getDrawable(R.drawable.bt_shape_green));
                }
                uploadFile();
              }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) { }
          });

        }else{
          CategoryName.setError("Please! Set Category Name ");
        }
      }
      return true;
    }
    return super.onOptionsItemSelected(item);
  }

  @RequiresApi(api = Build.VERSION_CODES.KITKAT)
  @Override
  protected void onActivityResult(int requestCode, int resultCode, Intent data) {
    super.onActivityResult(requestCode, resultCode, data);
    if (requestCode == REQUEST_PICTURE_CAPTURE && resultCode == RESULT_OK) {
      File imgFile = new  File(pictureFilePath);
      filePath = Uri.fromFile(imgFile);
      if(imgFile.exists()){
        imageCategory.setImageURI(filePath);
      }
    }else if(requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK){

      try {
        filePath = data.getData();
        Bitmap bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), filePath);
        imageCategory.setImageBitmap(bitmap);
      } catch (IOException e) {
        msg("ERROR (get image from sd): " + e);
      }
    }
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
      addImageCategory.setBackground(getResources().getDrawable(R.drawable.bt_shape_green));
    }
    DialogSelectImage.setVisibility(View.GONE);
  }

  public String getFileExtension(Uri uri) {
    ContentResolver cR = getContentResolver();
    MimeTypeMap mime = MimeTypeMap.getSingleton();
    return mime.getExtensionFromMimeType(cR.getType(uri));
  }

  public boolean CategoryNameAlreadyExist(String categoryName){
    final boolean[] alreadyExists = {false};
    mDatabase.orderByChild("categoryName").equalTo(categoryName).addValueEventListener(new ValueEventListener() {
      @Override
      public void onDataChange(DataSnapshot dataSnapshot) {
        if(dataSnapshot.exists()){
          alreadyExists[0] = true;
        }else{
          alreadyExists[0] = false;
        }
      }
      @Override
      public void onCancelled(DatabaseError databaseError) {

      }
    });
    return alreadyExists[0];
  }
  public  boolean IfNameExist(String ChildID, String ChildName){
    final boolean[] AlreadyExist = {false};
    mDatabase.child(ChildID).child("categoryName").addValueEventListener(new ValueEventListener() {
      @Override
      public void onDataChange(DataSnapshot dataSnapshot) {
        if(dataSnapshot.exists()){
          String categoryName = dataSnapshot.getValue(String.class);
          if(categoryName.equals(CategoryName.getText().toString().trim())){
            AlreadyExist[0] = true;
          }else{
            AlreadyExist[0] = false;
          }
        }else{

          AlreadyExist[0] = false;
        }
      }

      @Override
      public void onCancelled(DatabaseError databaseError) { }
    });
    return AlreadyExist[0];
  }

  private void uploadFile() {
    //checking if file is available
    if (filePath != null) {
      //displaying progress dialog while image is uploading
      final ProgressDialog progressDialog = new ProgressDialog(this);
      progressDialog.setTitle("Uploading");
      progressDialog.show();
      //ImageName = "Categories" + System.currentTimeMillis() + "." + getFileExtension(filePath);
      String SuffixFileExtension = "";
      if(getFileExtension(filePath) == null){
        SuffixFileExtension =  getFileExtension(filePath);
      }else{
        SuffixFileExtension = "jpg";
      }
      ImageName = "Categories" + System.currentTimeMillis() + "." + SuffixFileExtension;

      //getting the storage reference
      final StorageReference sRef = storageReference.child(ImageName);

      //adding the file to reference
      sRef.putFile(filePath)
              .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                @Override
                public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                  //dismissing the progress dialog
                  progressDialog.dismiss();
                  //displaying success toast
                  //Toast.makeText(getApplicationContext(), "File Uploaded ", Toast.LENGTH_LONG).show();
                  if(categoryID == null) {
                    Date dNow = new Date();
                    SimpleDateFormat format = new SimpleDateFormat("dd-MM-yyyy HH:mm");
                    String current_datetime = format.format(dNow);
                    //adding an upload to firebase database
                    String uploadId = mDatabase.push().getKey();
                    //creating the upload Category object to store uploaded image details
                    final Category category = new Category();//Upload(editTextName.getText().toString().trim(), taskSnapshot.getDownloadUrl().toString());
                    category.categoryID = uploadId;
                    category.adminID = SharedPreferenceHelper.getInstance(AddCategories.this).getUID();
                    category.imageName = ImageName;
                    category.categoryName = CategoryName.getText().toString().trim();
                    category.imagePath = taskSnapshot.getDownloadUrl().toString();

                    mDatabase.child(uploadId).setValue(category).addOnCompleteListener(new OnCompleteListener<Void>() {
                      @Override
                      public void onComplete(@NonNull Task<Void> task) {
                        if(task.isSuccessful()){
                          msg("Category "+category.categoryName+" Added Successfully");
                          finish();
                        }else{
                          msg("Category "+category.categoryName+" not added \nTry Again !!!");
                        }
                      }
                    });

                  }else{

                    mDatabase.child(categoryID).child("imagePath").setValue(taskSnapshot.getDownloadUrl().toString());
                    mDatabase.child(categoryID).child("imageName").setValue(ImageName);
                    sRef.child(EditCategory.imageName).delete();
                                /*.addOnCompleteListener(new OnCompleteListener<Void>() {
                                    @Override
                                    public void onComplete(@NonNull Task<Void> task) {
                                        if(task.isSuccessful()){
                                            msg("Category "+category.categoryName+" Added Successfully");
                                        }else{
                                            msg("Category "+category.categoryName+" not added \nTry Again !!!");
                                        }
                                    }
                                });
                                */

                  }

                }
              })
              .addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception exception) {
                  progressDialog.dismiss();
                  Toast.makeText(getApplicationContext(), exception.getMessage(), Toast.LENGTH_LONG).show();
                }
              })
              .addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
                @Override
                public void onProgress(UploadTask.TaskSnapshot taskSnapshot) {
                  //displaying the upload progress
                  double progress = (100.0 * taskSnapshot.getBytesTransferred()) / taskSnapshot.getTotalByteCount();
                  progressDialog.setMessage("Uploaded " + ((int) progress) + "%...");
                }
              });
    } else {
      //display an error if no file is selected
      msg("You Should select Image");
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
        addImageCategory.setBackground(getResources().getDrawable(R.drawable.bt_shape_red));
      }
    }
  }
}
