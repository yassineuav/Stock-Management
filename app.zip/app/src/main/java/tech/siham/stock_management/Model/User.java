package tech.siham.stock_management.Model;

import com.google.firebase.database.IgnoreExtraProperties;

@IgnoreExtraProperties
public class User {

  public Coordinates coordinates;
  // public OperationHours operationHours;
  public String fullName;
  public String userID;
  public String adminID;
  public String email;
  public String orderFrom; // [store| stock| customer| deliver]
  public String phoneNumber;
  public String address;
  public String storeName;
  public String shopName;
  public String customerName;
  public String avatar;
  public String logo;
  public String accountStatus;  // status : [new| profilePending| closeByUser| closeByAdmin| paymentPending| expire | done ]
  public String stockStatus;
  public float star;
  public float distance;
  public String currency; // $ ...
  public String format; // US or UK System || Imperial vs. Metric System
  public String language; // English, Arabic, France, Spanish

  public boolean useCamera; // camera or gun BarCode Scanner
  public String availableForOrders; // [on | off]
  public String availableForDelivery; // if AvailableForOrder is on then Delivery can set on
  public float ordersAvailableArea; // order area km/mil
  public float DeliveryAvailableArea; // // order area km/mil
  public double orderPriceMin = 0; // check out >= 200$
  // date / currency / invoice logo /

  public MyAddress myAddress;

  public User(){
    coordinates = new Coordinates();
    myAddress = new MyAddress();
    // operationHours = new OperationHours();
  }
}

/*
class OperationHours{
  public String workdays;
  public OperationHours(){}
}
*/