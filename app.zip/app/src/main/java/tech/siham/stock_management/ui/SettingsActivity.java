package tech.siham.stock_management.ui;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import tech.siham.stock_management.FragmentsSettings.AccountInfoFragment;
import tech.siham.stock_management.FragmentsSettings.BluetoothBarcodeScanner;
import tech.siham.stock_management.FragmentsSettings.LanguageFragment;
import tech.siham.stock_management.FragmentsSettings.availableForDelivery;
import tech.siham.stock_management.FragmentsSettings.availableForOrder;
import tech.siham.stock_management.FragmentsSettings.invoiceSettings;
import tech.siham.stock_management.R;

public class SettingsActivity extends AppCompatActivity {

    int[] setting_image =  {
            R.drawable.orderes_icon,
            R.drawable.delivery_icon,
            R.drawable.barcode_scanner,
            R.drawable.invoice_setting_icon,
            R.drawable.language_icon,
            R.drawable.account_info_icon,
            R.drawable.account_close_icon };
    String[] setting_name = {
            "Available for orders",
            "Available for delivery",
            "Barcode Scanner",
            "Set up invoice settings",
            "Language",
            "My Account info",
            "Close Account"};

    Fragment[] fragments = {
            new availableForOrder(),
            new availableForDelivery(),
            new BluetoothBarcodeScanner(),
            new invoiceSettings(),
            new LanguageFragment(),
            new AccountInfoFragment(),
            new AccountInfoFragment()
    };

    ListView listView;
    ListAdapter myAdapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle("My Settings");

        listView = (ListView) findViewById(R.id.list_item);
        myAdapter = new ListAdapter(setting_name, setting_image);
        listView.setAdapter(myAdapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                // Toast.makeText(SettingsActivity.this," >> "+ setting_name[i], Toast.LENGTH_SHORT).show();
                getSupportActionBar().setTitle("My Settings -> "+ setting_name[i]);
                fragmentSettingsView(fragments[i]);
            }
        });
        fragmentSettingsView(fragments[0]);

    }

    /*
     *    getSupportActionBar().setDisplayHomeAsUpEnabled(true);
     *    getSupportActionBar().setTitle("Categories");  // provide compatibility to all the versions
     */
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == android.R.id.home) {
            onBackPressed();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }



    void fragmentSettingsView(Fragment fragment){
        FragmentManager fm = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fm.beginTransaction();
        fragmentTransaction.replace(R.id.settings_view, fragment);
        fragmentTransaction.commit();
    }


    private class ListAdapter extends BaseAdapter {

        private final String [] settingName;
        private final int [] settingImage;

        public ListAdapter(String [] settingName, int [] settingImage){
            //super(context, R.layout.single_list_app_item, utilsArrayList);
            this.settingName = settingName;
            this.settingImage = settingImage;
        }

        @Override
        public int getCount() {
            return settingName.length;
        }

        @Override
        public Object getItem(int i) {
            return i;
        }

        @Override
        public long getItemId(int i) {
            return i;
        }

        @NonNull
        @Override
        public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {

            ViewHolder viewHolder;
            final View result;

            if (convertView == null) {
                viewHolder = new ViewHolder();
                LayoutInflater inflater = LayoutInflater.from(SettingsActivity.this);
                convertView = inflater.inflate(R.layout.list_item_settings, parent, false);
                viewHolder.txtName = (TextView) convertView.findViewById(R.id.setting_name);
                viewHolder.icon = (ImageView) convertView.findViewById(R.id.setting_icon);
                result = convertView;
                convertView.setTag(viewHolder);
            } else {
                viewHolder = (ViewHolder) convertView.getTag();
                result = convertView;
            }

            viewHolder.txtName.setText(settingName[position]);
            viewHolder.icon.setImageResource(settingImage[position]);

            return convertView;
        }

        private class ViewHolder {
            TextView txtName;
            ImageView icon;
        }
    }
}
